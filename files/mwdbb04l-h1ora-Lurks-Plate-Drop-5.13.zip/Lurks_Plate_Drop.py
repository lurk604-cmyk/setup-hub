"""Plate movement plus HUD turnover monitoring.

Settings live in Lurks_Plate_Drop/module.json and gui.ui.
At the limit, click NETX's enabled Quit Game button once.
Keep NETX open on its Shooting tab.
The integrated visual walker returns through the Theater. L3 + Down pauses automation.
Optional random shots (Square / X) join the movement during confirmed gameplay.
An end-of-game OVR PERFORMANCE bar with no blue left stops the script until reload,
after it backs out of the next Theater queue (Continue, Exit, Yes).
"""
import atexit
import importlib.util
import json
import os
import re
import random
import sys
from pathlib import Path
from time import monotonic, time

from creative_helper import Combo
from helios import controls

NAME = "Lurks Plate Drop"
VERSION = "5.13 Back Out + Black Plate ETA"
CONFIG = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                      "Lurks_Plate_Drop", "module.json")
STATUS = os.path.join(os.path.dirname(CONFIG), "status.json")
combo = Combo()
_started_at = None
_last_frame_at = None
_settings = dict(movement_enabled=True, shooting_enabled=True, monitor_enabled=False, to_limit=5,
                 pause_at_limit=True, preview=True, quit_enabled=True, detection_box=True,
                 recovery_enabled=True, theater_enabled=True, theater_guides=True, theater_boxes=True, auto_reset=True)
_checked_at = -10.0
_stamp = None
_engine = None
_retry_at = 0.0
_last_digit_sequence = None
_last_label_sequence = None
_label_at = -10.0
_candidate = None
_candidate_hits = 0
_candidate_at = -10.0
_count = None
_count_at = -10.0
_limit_reached = False
_quit_deadline = 0.0
_trigger_limit = None
_reset_held = False
_message = "TO monitoring off"
_netx = None
_netx_error = None
_status_at = -10.0
_status_history = []
_last_status_message = None
_raw_ocr = {}
_exit_sequence = None
_exit_hits = 0
_exit_click_at = None
_recovery = _walker = _scenes = _recovery_module = None
_last_video_at = -10.0
_route_ready_at = None
_zero_since = None
_hud_missing_since = None
_hud_absence_confirmed = False
_completed_cycles = 0
_last_auto_reset_at = None
_return_in_progress = False
_queue_reached = False
_spawn_checked_at = -10.0
_unrecognized_since = None
_diagnostic_at = -100.0
_diagnostic = {}
_gameplay_hud = dict(pair=None, hits=0, since=None, at=-10, label=None, seen=-10)
_return_menu_seen = False
_return_counter_cleared = False
_cycle_pending = False
_recovery_retry_at = None
_retry_video_since = None
_retry_video_last = None
_ovr = None
_ovr_error = None
_stopped = None
_backout = None
_backout_error = None
_plate = None
_plate_error = None
_set_value = None
_gui_pending = {}
_gui_prefix = 'gui.lurks_plate_drop'
AUTOMATIC_SETTINGS = ('monitor_enabled', 'pause_at_limit', 'preview', 'quit_enabled',
                      'detection_box', 'recovery_enabled', 'theater_enabled',
                      'theater_guides', 'theater_boxes', 'auto_reset')
for _key in AUTOMATIC_SETTINGS:
    _settings[_key] = True


class RandomMovement:
    """Independent left-stick steps, short right-stick flick/release cycles and optional shots."""
    DIRECTIONS = ((1,0),(-1,0),(0,1),(0,-1),(.707,.707),(.707,-.707),(-.707,.707),(-.707,-.707))
    SHOT = 'BUTTON_17'  # Square / X

    def __init__(self):
        self.rng = random.Random()
        self.shots = 0
        self.reset()

    def reset(self):
        self.last_at = None
        self.left_until = 0
        self.right_until = 0
        self.next_flick = None
        self.left = self.right = (0,0)
        self.previous_left = self.previous_right = None
        self.shot_down = False
        self.shot_until = 0
        self.next_shot = None

    def output(self, now, shooting=False, start=True):
        if self.last_at is not None and now-self.last_at > .3:
            held = self.shot_down
            self.reset()
            self.last_at = now
            self.next_flick = now + .3
            values = dict(STICK_1_X=0, STICK_1_Y=0, STICK_2_X=0, STICK_2_Y=0)
            if held:
                values[self.SHOT] = 0
            return values
        self.last_at = now
        if now >= self.left_until:
            options = [d for d in self.DIRECTIONS if d != self.previous_left]
            direction = self.rng.choice(options)
            self.previous_left = direction
            power = 0 if self.rng.random() < .15 else self.rng.uniform(45,100)
            self.left = tuple(round(v*power) for v in direction)
            self.left_until = now + self.rng.uniform(.35,1.1)
        shot = self._shot(now, shooting, start)
        if self.next_flick is None:
            self.next_flick = now + self.rng.uniform(.25,.6)
        if now >= self.next_flick and not self.shot_down:
            direction = self.rng.choice([d for d in self.DIRECTIONS if d != self.previous_right])
            self.previous_right = direction
            self.right = tuple(round(v*self.rng.uniform(85,100)) for v in direction)
            self.right_until = now + self.rng.uniform(.07,.14)
            self.next_flick = self.right_until + self.rng.uniform(.35,.95)
        right = self.right if now < self.right_until else (0,0)
        values = dict(STICK_1_X=right[0], STICK_1_Y=right[1],
                      STICK_2_X=self.left[0], STICK_2_Y=self.left[1])
        if shot is not None:
            values[self.SHOT] = shot
        return values

    def _shot(self, now, shooting, start):
        """Hold Square / X for a random jumper; 100 held, 0 on release, else untouched."""
        if not shooting:
            self.next_shot = None
            if self.shot_down:
                self.shot_down = False
                return 0
            return None
        if self.next_shot is None:
            self.next_shot = now + self.rng.uniform(1.5,4)
        if self.shot_down and now >= self.shot_until:
            self.shot_down = False
            self.next_shot = now + self.rng.uniform(3,8)
            return 0
        # Never start a shot in the middle of a right-stick flick.
        if not self.shot_down and start and now >= self.next_shot and now >= self.right_until:
            self.shot_down = True
            self.shot_until = now + self.rng.uniform(.4,.9)
            self.shots += 1
        return 100 if self.shot_down else None


_gameplay_movement = RandomMovement()


def _release_gameplay_sticks():
    names = ('STICK_1_X', 'STICK_1_Y', 'STICK_2_X', 'STICK_2_Y')
    if _gameplay_movement.shot_down:
        names += (RandomMovement.SHOT,)
    for name in names:
        if not _write_control(name, 0):
            _release_controls()
            break
    _gameplay_movement.reset()


def _reset():
    global _candidate, _candidate_hits, _count, _limit_reached
    global _last_digit_sequence, _last_label_sequence, _label_at, _count_at
    global _netx_error
    global _quit_deadline, _trigger_limit
    global _route_ready_at, _zero_since, _started_at
    global _hud_missing_since, _hud_absence_confirmed
    global _return_in_progress, _queue_reached, _spawn_checked_at
    global _release_pending
    global _return_menu_seen, _return_counter_cleared, _cycle_pending
    _gameplay_movement.reset()
    _return_menu_seen = False
    _return_counter_cleared = _cycle_pending = False
    _gameplay_hud.update(pair=None, hits=0, since=None, at=-10, label=None)
    _release_pending = True
    _return_in_progress, _queue_reached, _spawn_checked_at = False, False, -10.0
    _route_ready_at = _zero_since = _started_at = None
    _hud_missing_since, _hud_absence_confirmed = None, False
    _quit_deadline, _trigger_limit = 0.0, None
    _netx_error = None
    _candidate = _count = None
    _candidate_hits = 0
    _limit_reached = False
    _last_digit_sequence = _last_label_sequence = None
    _label_at = _count_at = -10.0
    if _netx is not None:
        _netx.reset()
    if _recovery is not None:
        _recovery.reset()
    if _walker is not None:
        _walker.nav.stop('Reset')


def _close():
    global _engine
    engine, _engine = _engine, None
    if _netx is not None:
        _netx.reset()
    if engine is not None:
        try:
            engine.destroy()
        except Exception:
            pass


atexit.register(_close)


def _refresh(now):
    global _checked_at, _stamp, _settings, _netx_error, _manual_pause, _release_pending, _gui_prefix
    if now - _checked_at < .25:
        return
    _checked_at = now
    try:
        stamp = os.stat(CONFIG).st_mtime_ns
        if stamp == _stamp:
            return
        with open(CONFIG, encoding="utf-8") as source:
            raw = json.load(source)
        new = dict(_settings)
        for key in ("movement_enabled", "shooting_enabled", "monitor_enabled", "pause_at_limit", "preview", "quit_enabled", "detection_box",
                    "recovery_enabled", "theater_enabled", "theater_guides", "theater_boxes", "auto_reset"):
            if isinstance(raw.get(key), bool):
                new[key] = raw[key]
        for key in AUTOMATIC_SETTINGS:
            new[key] = True
        limit = raw.get("to_limit")
        if type(limit) is int and 1 <= limit <= 99:
            new["to_limit"] = limit
        prefix = (raw.get('gui') or {}).get('settings_prefix')
        if isinstance(prefix, str) and prefix:
            _gui_prefix = prefix
        if new["monitor_enabled"] != _settings["monitor_enabled"]:
            _close()
            _reset()
        if not new["quit_enabled"] and _netx is not None:
            _netx.reset()
        if new['recovery_enabled'] != _settings['recovery_enabled']:
            _manual_pause = False
            _release_pending = True
            if _recovery is not None:
                _recovery.reset()
            if _walker is not None:
                _walker.nav.stop('Recovery settings changed')
        if not new['theater_enabled'] and _walker is not None and _walker.nav.active:
            _walker.nav.stop('Theater walking disabled')
            _release_pending = True
            _recovery.state = 'wait_game'
            _recovery.message = 'Walking disabled; waiting for the next game'
        if new['theater_enabled'] and not _settings['theater_enabled'] and _recovery is not None:
            _recovery.reset()
        if not new['movement_enabled'] and _settings['movement_enabled']:
            _release_pending = True
        _settings, _stamp = new, stamp
    except (OSError, ValueError, TypeError, AttributeError):
        pass  # Keep the previous settings while the UI is saving.


def _start_ocr(now):
    global _engine, _retry_at, _message
    if _engine is not None:
        return True
    if now < _retry_at:
        return False
    _retry_at = now + 5.0
    try:
        from helios import inference
        _engine = inference.create_inference_engine()
        # Screenshot calibration at 1920x1080; normalized for other resolutions.
        # Separate single-line regions prevent mixing REB/AST with TO.
        _engine.set_ocr_region_normalized(100, 1828/1920, 40/1080,
                                         1868/1920, 66/1080)
        _engine.set_ocr_region_normalized(101, 1833/1920, 67/1080,
                                         1863/1920, 84/1080)
        # Connection-error line shown in the user's game-exit screenshot.
        _engine.set_ocr_region_normalized(102, 610/1920, 566/1080,
                                         1010/1920, 600/1080)
        _engine.set_ocr_skip_when_detections(False)
        _engine.set_draw_ocr_region(False)
        _engine.set_ocr_enabled(True)
        _engine.start()
        _message = "Waiting for TO counter"
        return True
    except Exception as exc:
        _close()
        _message = "TO reader unavailable: " + str(exc)[:100]
        return False


def _read_counter(now):
    global _last_digit_sequence, _last_label_sequence, _label_at
    global _candidate, _candidate_hits, _candidate_at, _count, _count_at, _message
    from helios import inference
    label = _engine.get_ocr_result(101)
    if label:
        _raw_ocr['label'] = dict(text=label.get('text'), confidence=label.get('confidence'),
                                 sequence=label.get('frame_sequence'), status=label.get('status'))
    if label and label["frame_sequence"] != _last_label_sequence:
        _last_label_sequence = label["frame_sequence"]
        text = re.sub(r"\s+", "", label.get("text", "")).upper()
        if (label["status"] == inference.OCR_STATUS_READY
                and label.get("confidence", 0) >= .85 and text in ("TO", "T0")
                and not label.get("flags", 0)):
            _label_at = now
        else:
            _label_at = -10.0
            _candidate_hits = 0
    result = _engine.get_ocr_result(100)
    if result:
        _raw_ocr['number'] = dict(text=result.get('text'), confidence=result.get('confidence'),
                                  sequence=result.get('frame_sequence'), status=result.get('status'))
    if not result or result["frame_sequence"] == _last_digit_sequence:
        if now - _count_at > 1.0:
            _message = "Waiting for TO counter"
        return
    _last_digit_sequence = result["frame_sequence"]
    text = result.get("text", "").strip()
    if (result["status"] != inference.OCR_STATUS_READY
            or result.get("confidence", 0) < .90 or result.get("flags", 0)
            or now - _label_at > .5 or not re.fullmatch(r"[0-9]{1,2}", text)):
        _candidate_hits = 0
        if now - _count_at > 1.0:
            _message = "Waiting for clear TO counter"
        return
    value = int(text)
    if value != _candidate or now - _candidate_at > .5:
        _candidate, _candidate_hits = value, 0
    _candidate_at = now
    _candidate_hits += 1
    if _candidate_hits >= 3:
        _count, _count_at = value, now
        _message = "TO: %d / %d" % (_count, _settings["to_limit"])


def _quit_still_valid():
    # A confirmed threshold is an intent to quit. Brief OCR gaps after that
    # must not consume the one-shot request before NETX can receive its click.
    # Expiry, user settings/reset, or a confirmed lower counter cancels it.
    return (_settings["monitor_enabled"] and _settings["quit_enabled"]
            and _limit_reached and monotonic() < _quit_deadline
            and _settings['to_limit'] == _trigger_limit
            and not (_count is not None and monotonic() - _count_at < 1.5
                     and _count < _trigger_limit))


def _status_message():
    if _control_fault:
        return _control_fault
    if _manual_pause:
        return 'Paused by L3 + Down; reload the script to resume'
    if _stopped:
        detail = _backout.message if _backout is not None else _backout_error
        return _stopped + (' | ' + detail if detail else '')
    if _settings['recovery_enabled'] and _recovery is not None and _recovery.active:
        return _recovery.message
    if (_settings['recovery_enabled'] and _return_in_progress and _recovery is not None
            and getattr(_netx, 'exit_confirmed', False)):
        return 'Waiting to recognize News / MyCAREER; menu detection has not confirmed a screen'
    if _limit_reached:
        return (_netx_error or (_netx.message if _netx is not None else 'TO limit reached; waiting for NETX'))
    return _netx_error or _message


def _draw_detection(now):
    from helios import overlay
    fresh = (_count is not None and now - _count_at < .75
             and now - _label_at < .75 and _candidate_hits >= 3
             and _candidate == _count)
    color = ((255, 70, 70) if _limit_reached else
             (70, 230, 100) if fresh else (255, 190, 30))
    if not _settings['monitor_enabled']:
        color = (150, 150, 150)
    # The border stays outside both OCR crops, so it cannot pollute the text.
    overlay.rect(1823, 35, 1874, 89, color=color, thickness=2,
                 space=overlay.DESIGN_1080P, target=overlay.FRAME)
    label = 'TO %s / %d' % (str(_count) if fresh else '0' if _return_counter_cleared else '--', _settings['to_limit'])
    overlay.text(label, 1880, 96, color=color, scale=2,
                 anchor=overlay.TOP_RIGHT, space=overlay.DESIGN_1080P,
                 target=overlay.FRAME)


def _check_exit(now):
    global _exit_sequence, _exit_hits, _exit_click_at
    click_at = getattr(_netx, 'click_sent_at', None)
    if click_at is None or _engine is None or getattr(_netx, 'exit_confirmed', False):
        return
    result = _engine.get_ocr_result(102)
    if _exit_click_at != click_at:
        _exit_click_at, _exit_hits = click_at, 0
        _exit_sequence = result.get('frame_sequence') if result else None
        return  # Discard a cached pre-click result.
    if now - click_at > 30:
        _netx.mark_unconfirmed()
        return
    if result and result.get('frame_sequence') != _exit_sequence:
        from helios import inference
        _exit_sequence = result['frame_sequence']
        _raw_ocr['exit'] = dict(text=result.get('text'), confidence=result.get('confidence'))
        text = re.sub(r'\s+', '', result.get('text', '')).upper()
        match = re.search(r'ERRORCODE[:\uff1a]?([0-9A-F]{8})', text)
        if (result.get('status') == inference.OCR_STATUS_READY and match
                and result.get('confidence', 0) >= .85 and not result.get('flags', 0)):
            _exit_hits += 1
            if _exit_hits >= 2:
                _netx.confirm_exit(match.group(1))
        else:
            _exit_hits = 0
    if now - click_at > 12 and not getattr(_netx, 'exit_confirmed', False):
        _netx.mark_unconfirmed()


def _save_status(now):
    global _status_at, _last_status_message
    if now - _status_at < .5:
        return
    _status_at = now
    message = _status_message()
    if message != _last_status_message:
        _status_history.append(dict(at=time(), message=message))
        del _status_history[:-40]
        _last_status_message = message
    data = dict(version=VERSION, updated_at=time(), message=message,
                reader_message=_message, count=_count, limit=_settings['to_limit'],
                limit_reached=_limit_reached, quit_request_valid=_quit_still_valid(),
                settings=dict(_settings), ocr=dict(_raw_ocr), history=list(_status_history))
    data['netx_click_sent'] = getattr(_netx, 'click_sent_at', None) is not None
    data['connection_error_observed'] = getattr(_netx, 'exit_confirmed', False)
    data['recovery_state'] = _recovery.state if _recovery is not None else 'idle'
    data['court_door_locked'] = bool(_walker and _walker.nav.threshold.locked)
    data['navigation_vision_ms'] = _walker.nav.vision_ms if _walker else 0
    data['navigation_max_vision_hz'] = 4
    data['entrance_door_position'] = _walker.nav.queue_anchor if _walker else None
    data['theater_state'] = _walker.nav.state if _walker else 'idle'
    data['theater_message'] = _walker.nav.message if _walker else ''
    data['theater_detections'] = _walker.nav.detector.matches if _walker else {}
    data['theater_guide'] = _walker.nav.guide if _walker else None
    data['door_alignment_error_px'] = _walker.nav.entry_error if _walker else None
    data['control_fault'] = _control_fault
    data['rejected_controls'] = sorted(_rejected_controls)
    data['commanded'] = dict(_commanded)
    data['manual_pause'] = _manual_pause
    data['scene_scores'] = dict(_scenes.scores) if _scenes is not None else {}
    data['scene_matches'] = dict(_scenes.matches) if _scenes is not None else {}
    data['video_shape'] = _scenes.frame_shape if _scenes is not None else None
    data['menu_diagnostic'] = dict(_diagnostic)
    data['gameplay_hud'] = dict(_gameplay_hud)
    data['return_menu_seen'] = _return_menu_seen
    data['turnovers_reset_for_return'] = _return_counter_cleared
    data['cycle_pending'] = _cycle_pending
    data['completed_cycles'] = _completed_cycles
    data['last_auto_reset_at'] = _last_auto_reset_at
    data['returning_to_queue'] = _return_in_progress
    data['queue_reached'] = _queue_reached
    data['stopped'] = _stopped
    data['ovr_bar'] = (dict(_ovr.reading, seen_at=_ovr.seen_at, empty_reads=_ovr.empty_reads,
                            last_gauge=_ovr.last_gauge) if _ovr is not None else None)
    data['ovr_bar_error'] = _ovr_error
    data['shooting'] = dict(allowed=_shooting_allowed(now), held=_gameplay_movement.shot_down,
                            shots=_gameplay_movement.shots)
    data['backout'] = _backout.status() if _backout is not None else None
    data['backout_error'] = _backout_error
    data['black_plate'] = _plate.estimate if _plate is not None else None
    data['black_plate_error'] = _plate_error
    data['movement_mode'] = ('stopped' if _stopped else
                             'recovery' if _recovery and _recovery.active and _recovery.state != 'wait_game' and _settings['recovery_enabled'] else
                             'off' if not _settings['movement_enabled'] else
                             'return_hold' if _hold_until_queue() else
                             'quit_pending' if _pause_movement_at_limit() else
                             'menu_wait' if _known_menu_visible(now) else
                             'gameplay_wait' if _waiting_for_game() else 'gameplay')
    try:
        with open(STATUS + '.tmp', 'w', encoding='utf-8') as target:
            json.dump(data, target, indent=2)
        os.replace(STATUS + '.tmp', STATUS)
    except OSError:
        pass


def _load_quit_module():
    spec = importlib.util.spec_from_file_location(
        'lurks_plate_netx', os.path.join(os.path.dirname(CONFIG), 'netx_quit.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _request_quit():
    global _netx, _netx_error
    if not _quit_still_valid() or _netx_error:
        return
    if _netx is None:
        try:
            _netx = _load_quit_module().NetxQuit()
        except Exception as exc:
            _netx_error = 'NETX helper unavailable: ' + str(exc)[:100]
            return
    _netx.request(_quit_still_valid)


def _ensure_recovery():
    global _recovery, _walker, _scenes, _recovery_module
    if _recovery is None:
        root = Path(CONFIG).parent
        spec = importlib.util.spec_from_file_location('lurks_plate_recovery', root / 'recovery.py')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        package_name = '_lurks_plate_theater_v5'
        # Clear only this script's private package when Creative reloads it.
        for key in list(sys.modules):
            if key == package_name or key.startswith(package_name + '.'):
                del sys.modules[key]
        spec = importlib.util.spec_from_file_location(package_name, root / 'theater' / '__init__.py',
                    submodule_search_locations=[str(root / 'theater')])
        theater = importlib.util.module_from_spec(spec)
        sys.modules[package_name] = theater
        spec.loader.exec_module(theater)
        walker = theater.Walker(root / 'theater')
        _recovery_module, _walker = module, walker
        _scenes, _recovery = module.Scenes(root), module.Recovery()


def _check_auto_reset(now):
    global _hud_missing_since, _hud_absence_confirmed, _zero_since
    global _completed_cycles, _last_auto_reset_at, _message
    fresh_hud = (_count is not None and now-_count_at < .5 and now-_label_at < .5
                 and _candidate == _count and _candidate_hits >= 3)
    if not fresh_hud:
        if _hud_missing_since is None:
            _hud_missing_since = now
        if now-_hud_missing_since >= 3:
            _hud_absence_confirmed = True
    else:
        _hud_missing_since = None
    if not _settings['auto_reset']:
        _zero_since = None
        return False
    waiting = bool(_recovery and _recovery.state == 'wait_game')
    # Recover even from a stopped menu/route stage once a real next game is seen.
    previous_quit = (_limit_reached and _hud_absence_confirmed
                     and getattr(_netx, 'click_sent_at', None) is not None)
    in_menu = bool(_scenes and _scenes.visible)
    if not ((waiting or previous_quit) and fresh_hud and _count == 0 and not in_menu):
        _zero_since = None
        return False
    if _zero_since is None:
        _zero_since = now
    if now-_zero_since < 1:
        return False
    if _limit_reached or _cycle_pending:
        _completed_cycles += 1
    _reset()
    _last_auto_reset_at = time()
    _message = 'New game detected; quit limit reset automatically (cycles: %d)' % _completed_cycles
    return True


def _neutral_recovery_controls():
    for name in RECOVERY_CONTROLS:
        if not _write_control(name, 0):
            _release_controls()
            return False
    return True


def _known_menu_visible(now):
    # Recovery is an armed permission, not a requirement for continuous HUD OCR.
    # A confirmed menu can hold movement; a missing TO reading cannot.
    return bool(_settings['recovery_enabled'] and _scenes is not None
                and now-_scenes.checked < .5 and _scenes.visible.intersection({'news', 'career', 'saves', 'city_menu'}))


def _waiting_for_game():
    return bool(_settings['recovery_enabled'] and _recovery is not None
                and _recovery.state == 'wait_game')


def _hold_until_queue():
    return bool(_settings['recovery_enabled'] and _return_in_progress and not _queue_reached)


def _begin_return():
    global _return_in_progress, _queue_reached
    _return_in_progress, _queue_reached = True, False


def _arrived_at_queue():
    global _return_in_progress, _queue_reached
    _return_in_progress, _queue_reached = False, True


def _start_walker(now):
    _walker.nav.start(now)
    _recovery.state = 'walking'
    _recovery.message = 'Looking for the Theater; plate movement paused'


def _pause_movement_at_limit():
    # wait_game owns neutral output until TO 0 confirms the next match.
    return bool(_limit_reached and _settings['pause_at_limit'] and not _waiting_for_game())


def _retry_recovery(now, scenes):
    """Keep recoverable failures armed; never retry without fresh video."""
    global _recovery_retry_at, _retry_video_since, _retry_video_last, _route_ready_at
    if (_control_fault or _manual_pause or not _settings['movement_enabled']
            or not _settings['recovery_enabled'] or _recovery is None
            or _recovery.state != 'failed'):
        _recovery_retry_at = _retry_video_since = _retry_video_last = None
        return
    if _recovery_retry_at is None:
        _recovery_retry_at = now + 30
    if _retry_video_last is None or now-_retry_video_last > .4:
        _retry_video_since = now
    _retry_video_last = now
    if now < _recovery_retry_at or now-_retry_video_since < 2:
        return
    known = bool(scenes.intersection({'news','career','saves','city_menu','city'}))
    error = _recovery.error_hits >= 2 and now-_recovery.error_at < .5
    stopped_walk = _walker is not None and _walker.nav.state == 'stopped'
    # A failed menu remains armed until a menu/error is actually recognized.
    # A failed walk starts with visual localization, never a blind forward push.
    if not (known or error or stopped_walk):
        return
    _recovery.reset()
    _route_ready_at = None
    if stopped_walk and not known and not error:
        _start_walker(now)
    _recovery_retry_at = _retry_video_since = _retry_video_last = None


def _recovery_output(now, frame):
    global _route_ready_at
    if _recovery is None or not _settings['recovery_enabled'] or not _recovery.active:
        return False
    # Even when movement is switched off, release every channel held by walking.
    if not _neutral_recovery_controls():
        return True
    if now-_last_video_at > .4:
        if _recovery.state == 'walking' or now-_last_video_at > 5:
            if _recovery.state == 'walking':
                _walker.nav.stop('Video interrupted; waiting to retry')
            _recovery.state = 'failed'
            _recovery.message = 'Video interrupted; waiting for video to return automatically'
        return True
    if _recovery.state in ('wait_game', 'failed'):
        return True
    button = _recovery.tick(now)
    if button:
        _write_control({'A': 'BUTTON_16', 'RB': 'BUTTON_4', 'B': 'BUTTON_15'}[button], 100)
        return True
    if _recovery.state == 'route_ready':
        _begin_return()
        if _route_ready_at is None:
            _route_ready_at = now
        if now-_route_ready_at >= 1:
            if _settings['theater_enabled']:
                _start_walker(now)
            else:
                _recovery.state = 'wait_game'
                _recovery.message = 'Park reached; waiting for manual entry into the next game'
    else:
        _route_ready_at = None
    if _recovery.state == 'walking':
        values = _walker.nav.output(now)
        _recovery.message = _walker.nav.message
        if _walker.nav.active:
            output = dict(STICK_1_X=max(-35, min(35, values.get('STICK_1_X', 0))),
                          STICK_2_X=max(-40, min(40, values.get('STICK_2_X', 0))),
                          STICK_2_Y=-100 if values.get('STICK_2_Y', 0) < 0 else 0)
            for name, value in output.items():
                if not _write_control(name, value):
                    _release_controls()
                    break
        elif _walker.nav.state == 'done':
            _arrived_at_queue()
            _recovery.state = 'wait_game'
            _recovery.message = 'Door transition detected; waiting for next-game TO 0 before plate movement'
        else:
            _recovery.state = 'failed'
            _recovery.message += '; automatic retry after 30 seconds of recovery checks'
    return True


def scan(button_bytes, stick_bytes, **kwargs):
    global _message, _limit_reached, _quit_deadline, _trigger_limit, _last_video_at
    global _return_menu_seen
    now = monotonic()
    _refresh(now)
    if _control_fault or _manual_pause:
        return None
    if _stopped:
        _observe_backout(kwargs.get('frame'), now)
        return None
    if not (_settings['monitor_enabled'] or _settings['recovery_enabled']):
        _message = 'TO monitoring off'
        return None
    frame = kwargs.get('frame')
    if frame is None:
        _message = 'Waiting for video'
        return None
    _last_video_at = now
    if _check_ovr_bar(frame, now):
        return None
    if _start_ocr(now):
        try:
            _read_counter(now)
            _read_gameplay_hud(now)
        except Exception as exc:
            _close()
            _message = 'TO reader error: ' + str(exc)[:100]
    if _settings['recovery_enabled'] and hasattr(frame, 'shape'):
        try:
            _ensure_recovery()
            if _walker.nav.active:
                # The return phase already owns navigation. Do not also scan
                # every main-menu reference while walking through the city.
                scenes = set()
                _scenes.visible = set()
                _scenes.checked = now
            else:
                scenes = _scenes.read(frame, now)
            if scenes.intersection({'news', 'career', 'saves', 'city_menu', 'city'}):
                _return_menu_seen = True
                _reset_turnovers_for_return()
            error = _engine.get_ocr_result(102) if _engine is not None else None
            from helios import inference
            _recovery.observe(now, error, scenes, inference.OCR_STATUS_READY)
            _retry_recovery(now, scenes)
            _capture_unrecognized_menu(frame, now, scenes)
            if _recovery.active:
                _quit_deadline = 0
                if _recovery.state != 'wait_game':
                    _begin_return()
            if scenes.intersection({'news', 'career', 'saves', 'city_menu', 'city'}):
                if _recovery.state != 'wait_game':
                    _begin_return()
            if _walker.nav.active:
                # Analyze the borrowed frame now; never retain the host's buffer.
                _walker.nav.observe(frame, now)
        except Exception as exc:
            _fail('Recovery stopped: ' + str(exc)[:130])
    _check_gameplay_handoff(now)
    _check_auto_reset(now)
    recovering = bool(_settings['recovery_enabled'] and _recovery and _recovery.active)
    if (_settings['monitor_enabled'] and not recovering and not _limit_reached
            and _count is not None and now-_count_at < .5 and _candidate == _count
            and _candidate_hits >= 3 and _count >= _settings['to_limit']):
        _limit_reached = True
        if _settings['recovery_enabled']:
            _begin_return()
        _quit_deadline, _trigger_limit = now + 30, _settings['to_limit']
    if _limit_reached:
        _request_quit()
    _check_exit(now)
    return None


def iterate(button_bytes, stick_bytes, **kwargs):
    global _started_at, _last_frame_at, _reset_held, _manual_pause, _release_pending, _set_value
    combo.buttons, combo.sticks = button_bytes, stick_bytes
    _commanded.clear()
    now = monotonic()
    _refresh(now)
    if callable(kwargs.get('set_value')):
        _set_value = kwargs['set_value']
    _flush_gui()
    try:
        reset = controls.get_actual(controls.BUTTON_9) > 0 and controls.get_actual(controls.BUTTON_11) > 0
        if reset and not _reset_held:
            _reset()
            _manual_pause, _release_pending = True, True
            if _backout is not None and _backout.active:
                _backout.fail('Cancelled by L3 + Down', now)
        _reset_held = reset
        if _release_pending:
            _release_controls()
        if not _control_fault and not _manual_pause and not _stopped:
            if _recovery_output(now, kwargs.get('frame')):
                _started_at = None
                if _gameplay_movement.shot_down:
                    _write_control(RandomMovement.SHOT, 0)
                _gameplay_movement.reset()
            elif _settings['movement_enabled']:
                if now-_last_video_at > .4 or _hold_until_queue() or _pause_movement_at_limit() or _known_menu_visible(now):
                    _release_gameplay_sticks()
                    _started_at = None
                else:
                    # A shot may finish within 1.5 s of the last HUD read; new ones need 0.5 s.
                    for name, value in _gameplay_movement.output(
                            now, _shooting_allowed(now), now-_gameplay_hud['seen'] < .5).items():
                        if not _write_control(name, value):
                            _release_controls()
                            break
            else:
                if _gameplay_movement.last_at is not None:
                    _release_gameplay_sticks()
                _started_at = None
        if _backout is not None and not _control_fault and not _manual_pause:
            # After the OVR stop only the back-out presses (and releases) a button.
            for name, value in _backout.tick(now).items():
                if not _write_control(name, value):
                    _release_controls()
                    break
    except Exception as exc:
        _fail('Automatic controls stopped: ' + str(exc)[:130])
    if _release_pending:
        _release_controls()
    if kwargs.get('frame') is not None:
        try:
            if _settings['detection_box']:
                _draw_detection(now)
                _draw_ovr(now)
            if _settings['preview']:
                from helios import overlay
                # One status line: a second line would cross the 'city' scene reference area.
                ovr = _ovr_text(now)
                overlay.text('Plate Drop ' + VERSION + ' | ' + _status_message() + (' | ' + ovr if ovr else ''),
                             16, 24, color=(255, 255, 255), scale=1, target=overlay.FRAME)
            _draw_theater(now)
        except Exception:
            pass  # An unavailable overlay must never interrupt controller release.
    _save_status(now)
    return None


# Own only supported Creative channels. Never enumerate every controller ID.
RECOVERY_CONTROLS = ('BUTTON_5', 'STICK_1_X', 'STICK_1_Y', 'STICK_2_X', 'STICK_2_Y',
                     'BUTTON_4', 'BUTTON_15', 'BUTTON_16')
_owned_controls = set()
_rejected_controls = set()
_control_fault = None
_commanded = {}
_release_pending = False
_manual_pause = False


def _fail(message):
    global _control_fault, _release_pending
    if _control_fault is None:
        _control_fault = message
    _release_pending = True
    if _walker is not None:
        _walker.nav.stop(_control_fault)
    if _recovery is not None:
        _recovery.state, _recovery.message = 'failed', _control_fault


def _write_control(name, value):
    if name in _rejected_controls:
        return False
    try:
        combo.set_val(getattr(controls, name), float(value))
        _owned_controls.add(name)
        _commanded[name] = value
        return True
    except Exception as exc:
        _rejected_controls.add(name)
        _fail('Controller stopped at %s: %s. Reload after correcting this.' % (name, str(exc)[:110]))
        return False


def _release_controls():
    global _release_pending
    for name in tuple(_owned_controls):
        if name not in _rejected_controls:
            _write_control(name, 0)
    _owned_controls.clear()
    _release_pending = False


def _draw_theater(now):
    if _walker is not None and _walker.nav.active:
        _walker.settings.update(show_guides=_settings['theater_guides'],
                                show_detections=_settings['theater_boxes'])
        _walker.commanded = _commanded
        _walker.draw(now)


def _capture_unrecognized_menu(frame, now, scenes):
    """Keep one bounded game-frame diagnostic when a return cannot find a menu."""
    global _unrecognized_since, _diagnostic_at, _diagnostic
    waiting = (_recovery.state in ('wait_news', 'wait_career', 'wait_saves', 'wait_city',
                                   'wait_city_world', 'resume_menu')
               or (_return_in_progress and _recovery.state == 'idle'
                   and getattr(_netx, 'exit_confirmed', False)))
    if not waiting or scenes:
        _unrecognized_since = None
        return
    if _unrecognized_since is None:
        _unrecognized_since = now
    if now-_unrecognized_since < 4 or now-_diagnostic_at < 30:
        return
    _diagnostic_at = now
    try:
        import cv2
        h, w = frame.shape[:2]
        owned = cv2.resize(frame[:, :, :3], (960, max(1, round(h*960/w))))
        path = Path(CONFIG).parent / 'last_unrecognized_menu.png'
        saved = cv2.imwrite(str(path), owned)
        _diagnostic = dict(at=time(), state=_recovery.state, frame_shape=list(frame.shape),
                           image=str(path) if saved else None, scores=dict(_scenes.scores),
                           matches=dict(_scenes.matches))
    except Exception as exc:
        _diagnostic = dict(at=time(), error=str(exc)[:120])


def _read_gameplay_hud(now):
    """FG% confirms a gameplay HUD, but never counts as a turnover reading."""
    from helios import inference
    label = _engine.get_ocr_result(101)
    number = _engine.get_ocr_result(100)
    if not label or not number:
        return
    pair = (label.get('frame_sequence'), number.get('frame_sequence'))
    previous = _gameplay_hud['pair']
    if None in pair or (previous and (pair[0] == previous[0] or pair[1] == previous[1])):
        return
    _gameplay_hud['pair'] = pair
    text = re.sub(r'\s+', '', label.get('text', '')).upper()
    digit = re.sub(r'\s+', '', number.get('text', ''))
    valid = all(r.get('status') == inference.OCR_STATUS_READY and r.get('confidence', 0) >= .90
                and not r.get('flags', 0) for r in (label, number))
    valid = valid and ((text == 'FG%' and re.fullmatch(r'(?:100|[0-9]{1,2})%', digit))
                       or (text in ('TO', 'T0') and re.fullmatch(r'[0-9]{1,2}', digit)))
    if not valid:
        _gameplay_hud.update(hits=0, since=None, at=-10, label=None)
        return
    if now-_gameplay_hud['at'] > .5:
        _gameplay_hud.update(hits=0, since=now)
    _gameplay_hud['hits'] += 1
    # 'seen' survives single unclear reads; random shots use it, not 'at'.
    _gameplay_hud.update(at=now, label=text, seen=now)


def _check_gameplay_handoff(now):
    global _completed_cycles, _last_auto_reset_at, _message, _release_pending
    if not _settings['recovery_enabled'] or _recovery is None:
        return False
    if _recovery.state not in ('walking', 'route_ready', 'wait_game', 'failed'):
        return False
    hud = _gameplay_hud
    if (hud['hits'] < 3 or hud['since'] is None or now-hud['since'] < 1
            or now-hud['at'] > .5 or (_scenes and _scenes.visible)):
        return False
    # A prior quit latch may only be cleared after actually seeing the return
    # menus/city. An FG% display in the original match is not a new game.
    if _limit_reached and not _return_menu_seen:
        return False
    if _settings['auto_reset']:
        if _limit_reached or _cycle_pending:
            _completed_cycles += 1
        _reset()
        _last_auto_reset_at = time()
    else:
        _recovery.reset()
        _walker.nav.stop('Gameplay detected')
        _arrived_at_queue()
        _release_pending = True
    _message = 'Gameplay HUD confirmed; Theater controls released; plate movement resumed'
    return True


def _reset_turnovers_for_return():
    """Reset the displayed count after leaving the game, without stopping recovery."""
    global _return_counter_cleared, _cycle_pending, _limit_reached, _count, _candidate
    global _candidate_hits, _count_at, _label_at, _quit_deadline, _trigger_limit
    if _return_counter_cleared or not _limit_reached:
        return
    _cycle_pending = True
    _return_counter_cleared = True
    _limit_reached = False
    _count = _candidate = None
    _candidate_hits = 0
    _count_at = _label_at = -10
    _quit_deadline = 0
    _trigger_limit = None


def _shooting_allowed(now):
    """Random shots only while the in-game stat HUD (TO / FG%) is being read."""
    return bool(_settings['shooting_enabled'] and now-_gameplay_hud['seen'] < 1.5)


def _check_ovr_bar(frame, now):
    """Stop everything once the end-of-game OVR PERFORMANCE bar has no blue left."""
    global _ovr, _ovr_error, _stopped
    if _ovr_error or not hasattr(frame, 'shape'):
        return False
    try:
        if _ovr is None:
            _ovr = _load_helper('ovr_bar').OvrBar(os.path.dirname(CONFIG))
            _load_backout()
            _load_plate()
        empty = _ovr.observe(frame, now)
        _record_game(_ovr.pop_game(now, force=empty))
        if not empty:
            return False
    except Exception as exc:
        _ovr_error = 'OVR bar check unavailable: ' + str(exc)[:100]
        return False
    _reset()
    _close()
    _stopped = 'Stopped: OVR PERFORMANCE blue bar is gone (reload to run again)'
    if _backout is not None:
        _backout.start(now)
    return True


def _load_helper(name):
    spec = importlib.util.spec_from_file_location(
        'lurks_plate_' + name, os.path.join(os.path.dirname(CONFIG), name + '.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _load_backout():
    """A missing back-out helper must not cost the OVR stop itself."""
    global _backout, _backout_error
    try:
        _backout = _load_helper('backout').BackOut(os.path.dirname(CONFIG), _ovr)
    except Exception as exc:
        _backout_error = 'Back-out unavailable: ' + str(exc)[:100]


def _observe_backout(frame, now):
    if _backout is None or not hasattr(frame, 'shape'):
        return
    try:
        _backout.observe(frame, now)
    except Exception as exc:
        _backout.fail('Back-out error: ' + str(exc)[:100], now)


def _load_plate():
    """The black plate estimate is optional; the OVR stop works without it."""
    global _plate, _plate_error
    try:
        _plate = _load_helper('black_plate').BlackPlate(
            os.path.join(os.path.dirname(CONFIG), 'ovr_history.json'))
        _queue_gui()
    except Exception as exc:
        _plate_error = 'Black plate estimate unavailable: ' + str(exc)[:100]


def _record_game(pct):
    """One finished recap: add its bar to the history and refresh the GUI text."""
    if pct is None or _plate is None:
        return
    _plate.add(pct)
    _queue_gui()


def _queue_gui():
    global _gui_pending
    if _plate is not None:
        _gui_pending = _plate.gui_values()


def _flush_gui():
    """Hand the Black plate tab its text through the host's set_value, as Helios modules do."""
    global _gui_pending, _plate_error
    if not _gui_pending or _set_value is None:
        return
    pending, _gui_pending = _gui_pending, {}
    try:
        for key, value in pending.items():
            _set_value(_gui_prefix + '.' + key, value)
    except Exception as exc:
        _plate_error = 'GUI update failed: ' + str(exc)[:100]


def _ovr_text(now):
    if _ovr_error:
        return _ovr_error
    if _stopped or _ovr is None:
        return None
    plate = ' | black plate ' + _plate.estimate['short'] if _plate is not None and _plate.estimate['short'] else ''
    if now-_ovr.seen_at > 1 or not _ovr.reading.get('gauge'):
        return 'OVR check: watching for the recap' + plate
    if _ovr.empty_reads:
        return 'OVR PERFORMANCE bar: no blue left, confirming'
    return 'OVR PERFORMANCE bar: %.1f%%' % _ovr.reading['pct'] + plate


def _draw_ovr(now):
    """Recap and back-out overlays: what the checks see and what they decided."""
    from helios import overlay
    # The recap panel steps aside once the back-out is past the recap.
    if _ovr is not None and (_backout is None or _backout.state in ('idle', 'recap')):
        _ovr.draw(overlay, now, 'OVR BAR EMPTY - BACKING OUT' if _backout is not None and _backout.active
                  else 'OVR BAR EMPTY - SCRIPT STOPPED' if _stopped else None,
                  _plate.estimate['text'] if _plate is not None else None)
    if _backout is not None:
        _backout.draw(overlay, now)
