"""Black plate estimate from how fast the OVR PERFORMANCE bar drops.

One reading per end-of-game recap is kept in ovr_history.json so the trend
survives reloads. Black plate = the bar empty (0%). The bar is one bar
across ranks; its tick marks (measured) are where the rank changes.
The drop per game comes from recaps about one game apart; a pair a few games
apart counts as that many games, and longer gaps (breaks, testing) are skipped.
"""
import json
import math
import os
import statistics
from time import time

TICKS = (17.9, 33.8, 50.0, 66.2, 82.1)
SINGLE_GAME = (1.0, 12.0)  # minutes between two recaps that are one game apart
WINDOW = 12                # most recent recap pairs used for the rate
MIN_DROP = .05             # % per game below which the bar counts as not dropping


def _clock(minutes):
    minutes = max(0, round(minutes))
    return '%dh %02dm' % divmod(minutes, 60) if minutes >= 60 else '%dm' % minutes


class BlackPlate:
    def __init__(self, path):
        self.path = path
        self.games = []
        try:
            with open(path, encoding='utf-8') as source:
                games = json.load(source).get('games', [])
            self.games = [dict(at=float(g['at']), pct=float(g['pct'])) for g in games]
        except (OSError, ValueError, TypeError, KeyError, AttributeError):
            pass
        self.estimate = self._estimate()

    def add(self, pct, at=None):
        self.games.append(dict(at=round(at if at is not None else time(), 1), pct=round(pct, 2)))
        del self.games[:-200]
        try:
            with open(self.path + '.tmp', 'w', encoding='utf-8') as target:
                json.dump(dict(games=self.games), target, indent=1)
            os.replace(self.path + '.tmp', self.path)
        except OSError:
            pass
        self.estimate = self._estimate()
        return self.estimate

    def _estimate(self):
        if not self.games:
            return dict(text='Black plate: waiting for the first recap', short='')
        pct = self.games[-1]['pct']
        history = ' > '.join('%.1f' % g['pct'] for g in self.games[-6:])
        result = dict(pct=pct, games_used=0, history=history, short='')
        if pct <= 0:
            result.update(text='Black plate: bar empty', short='bar empty')
            return result
        pairs = [(a['pct'] - b['pct'], (b['at'] - a['at']) / 60) for a, b in zip(self.games, self.games[1:])]
        single = [gap for _, gap in pairs if SINGLE_GAME[0] <= gap <= SINGLE_GAME[1]]
        if not single:
            result.update(text='Black plate: bar %.1f%%, needs two recaps one game apart' % pct)
            return result
        game_minutes = statistics.median(single[-WINDOW:])
        dropped = games = used = 0
        for drop, gap in reversed(pairs):
            # Skip breaks and testing gaps (over 3 games), and jumps up (a reset).
            if used == WINDOW or gap < SINGLE_GAME[0] or gap > 3 * game_minutes or drop < -10:
                continue
            dropped += drop
            games += max(1, round(gap / game_minutes))
            used += 1
        if not games:
            result.update(text='Black plate: bar %.1f%%, needs two recaps one game apart' % pct)
            return result
        per_game = dropped / games
        result.update(per_game=round(per_game, 2), game_minutes=round(game_minutes, 1), games_used=used)
        if per_game < MIN_DROP:
            result.update(text='Black plate: bar %.1f%% is not dropping (%+.2f%% per game)' % (pct, -per_game))
            return result
        games = pct / per_game
        result.update(games=math.ceil(games), minutes=round(games * game_minutes))
        result['short'] = '~%d games (~%s)' % (result['games'], _clock(result['minutes']))
        result['text'] = 'Black plate in %s at -%.2f%% per game' % (result['short'], per_game)
        below = [tick for tick in TICKS if tick < pct - .05]
        if below:
            result['next_tick'] = below[-1]
            result['next_games'] = math.ceil((pct - below[-1]) / per_game)
        return result

    def gui_values(self):
        """Text for the Black plate tab, keyed by widget name."""
        e = self.estimate
        values = dict(black_plate_eta=e['text'],
                      black_plate_rate=('-%.2f%% per game, %.1f min per game (%d recap pair%s)' % (
                          e['per_game'], e['game_minutes'], e['games_used'], '' if e['games_used'] == 1 else 's'))
                      if 'per_game' in e else 'Not enough recaps yet',
                      black_plate_next=('Next rank tick %.1f%% in ~%d games' % (e['next_tick'], e['next_games'])
                                        if 'next_tick' in e else 'No rank tick left above black plate'),
                      black_plate_history='Bar now %.2f%% | last recaps: %s' % (e['pct'], e['history'])
                      if 'pct' in e else 'No recap read yet')
        return values
