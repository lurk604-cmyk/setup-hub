"""Stable visual menu detection and automatic return to the city."""
import json
import math
from pathlib import Path
import re

SCENES = {
    'news': (60, 174, 195, 229),
    'career': (201, 174, 403, 229),
    'saves': (65, 127, 285, 160),
    'city': (48, 28, 225, 66),
    'city_menu': (298, 136, 700, 204),
}



class Scenes:
    def __init__(self, root):
        self.root = Path(root)
        self.templates = {}
        self.checked = -10
        self.visible = set()
        self.scores = {}
        self.matches = {}
        self.frame_shape = None

    @staticmethod
    def crop(frame, box):
        import cv2
        h, w = frame.shape[:2]
        x1, y1, x2, y2 = box
        crop = frame[round(y1*h/1080):round(y2*h/1080), round(x1*w/1920):round(x2*w/1920), :3]
        if not crop.size:
            return None
        crop = cv2.resize(crop, (x2-x1, y2-y1), interpolation=cv2.INTER_AREA)
        return cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)

    def read(self, frame, now):
        import cv2
        if now - self.checked < .25:
            return self.visible
        self.checked = now
        self.frame_shape = list(frame.shape)
        visible = set()
        for name, box in SCENES.items():
            if name not in self.templates:
                template = cv2.imread(str(self.root / ('scene_' + name + '.png')), cv2.IMREAD_GRAYSCALE)
                if template is None:
                    raise RuntimeError('Missing menu reference: ' + name)
                self.templates[name] = template
            template = self.templates[name]
            # Small safe-area/capture offsets must not move the reference
            # glyph mask onto the background. Locate the text before testing
            # whether that tab is selected. Search remains local to this label.
            x1, y1, x2, y2 = box
            search_box = (max(0, x1-32), max(0, y1-22), min(1920, x2+32), min(1080, y2+22))
            crop = self.crop(frame, search_box)
            score = -1
            details = {}
            if crop is not None:
                for scale in (1., .95, 1.05):
                    ref = cv2.resize(template, None, fx=scale, fy=scale, interpolation=cv2.INTER_LINEAR)
                    if ref.shape[0] > crop.shape[0] or ref.shape[1] > crop.shape[1]:
                        continue
                    result = cv2.matchTemplate(crop, ref, cv2.TM_CCOEFF_NORMED)
                    _, candidate, _, location = cv2.minMaxLoc(result)
                    if not math.isfinite(candidate) or candidate <= score:
                        continue
                    x, y = location
                    aligned = crop[y:y+ref.shape[0], x:x+ref.shape[1]]
                    mask = ref > 220
                    luminance = float(aligned[mask].mean()) if mask.any() else 0
                    selected = name not in ('news', 'career') or luminance >= 185
                    details = dict(correlation=candidate, luminance=luminance, selected=selected,
                                   scale=scale, position=[search_box[0]+x, search_box[1]+y])
                    if selected:
                        score = candidate
            self.matches[name] = details
            self.scores[name] = score
            if math.isfinite(score) and score >= .88:
                visible.add(name)
        self.visible = visible
        return visible



class Recovery:
    """Advance only on stable screens; resume from an already open main menu."""
    ORDER = ('news', 'career', 'saves', 'city_menu', 'city')
    ACTIONS = {'news': ('RB', 'wait_career'), 'career': ('A', 'wait_saves'),
               'saves': ('A', 'wait_city'), 'city_menu': ('B', 'wait_city_world')}

    def __init__(self):
        self.reset()

    def reset(self):
        self.state = 'idle'
        self.message = ''
        self.error_sequence = None
        self.error_hits = 0
        self.error_at = -10
        self.scene = None
        self.scene_since = 0
        self.scene_at = -10
        self.seen = set()
        self.deadline = 0
        self.pulse_started = None
        self.button = self.next_state = None
        self.last_source = None
        self.attempts = 0
        self.retry_at = 0

    @property
    def active(self):
        return self.state != 'idle'

    def observe(self, now, error, scenes, ready_status=1):
        self.seen = set(scenes)
        if error and error.get('frame_sequence') != self.error_sequence:
            self.error_sequence = error.get('frame_sequence')
            text = re.sub(r'\s+', '', error.get('text', '')).upper()
            valid = (error.get('status') == ready_status and error.get('confidence', 0) >= .85
                     and not error.get('flags', 0) and re.search(r'ERRORCODE[:ï¼š]?56D85BB8', text))
            self.error_hits = self.error_hits + 1 if valid and now-self.error_at < 1 else int(bool(valid))
            if valid:
                self.error_at = now
        if self.state in ('idle', 'wait_game') and self.error_hits >= 2 and now-self.error_at < .5:
            self.press('A', 'wait_news', now, 'Dismissing connection error: A / Cross')
        # The city HUD can remain visible behind its menu. Menu takes priority.
        current = next((s for s in ('city_menu', 'saves', 'career', 'news', 'city') if s in scenes), None)
        if current:
            if self.scene != current or now-self.scene_at > .4:
                self.scene_since = now
            self.scene, self.scene_at = current, now
        else:
            self.scene = None
        # Enter an owning state in the vision callback. Idle does not send input.
        if (self.state == 'idle' or (self.state == 'wait_game' and current != 'city')):
            if current and now-self.scene_since >= .5:
                self.state = 'resume_menu'
                self.deadline = now + 90
                self.message = 'Recognized %s; resuming automatic return' % current

    def press(self, button, next_state, now, message, source=None, retry=False):
        self.state = 'press'
        self.button, self.next_state = button, next_state
        # The pulse clock starts on the first controller callback, not during
        # vision processing. A slow frame cannot consume the entire press.
        self.pulse_started = None
        self.last_source = source
        self.attempts = self.attempts + 1 if retry else 1
        self.message = message

    def tick(self, now):
        if self.state == 'press':
            if self.pulse_started is None:
                self.pulse_started = now
            if now-self.pulse_started < .18:
                return self.button
            if now-self.pulse_started >= 1:
                self.state = self.next_state
                self.button = None
                self.deadline = now + 90
                self.retry_at = now + 2
                self.message = {'wait_news': 'Waiting for News or MyCAREER',
                                'wait_career': 'Waiting for MyCAREER',
                                'wait_saves': 'Waiting for File Save Manager',
                                'wait_city': 'Waiting for the park to load',
                                'wait_city_world': 'Waiting for the city menu to close'}.get(self.state, '')
            return None
        if self.state not in ('resume_menu', 'wait_news', 'wait_career', 'wait_saves', 'wait_city', 'wait_city_world'):
            return None
        if now >= self.deadline:
            self.state = 'failed'
            self.message = 'Menu not recognized for 90 seconds; waiting for automatic recovery'
            return None
        if not self.scene or now-self.scene_at >= .4 or now-self.scene_since < .5:
            return None
        # Retry only if the same selected source screen is still confirmed.
        # No blind A/RB/B sequence runs over loading or unrelated screens.
        if self.last_source and self.scene == self.last_source:
            if now < self.retry_at:
                return None
            if self.attempts >= 3:
                self.state = 'failed'
                self.message = 'No response on %s after 3 presses; waiting for automatic recovery' % self.scene
                return None
            action = self.ACTIONS[self.scene]
            self.press(*action, now, 'Retrying %s on confirmed %s' % (action[0], self.scene), source=self.scene, retry=True)
            return self.tick(now)
        minimum = {'resume_menu': 0, 'wait_news': 0, 'wait_career': 1,
                   'wait_saves': 2, 'wait_city': 3, 'wait_city_world': 4}[self.state]
        if self.ORDER.index(self.scene) < minimum:
            return None
        if self.scene == 'city':
            self.state = 'route_ready'
            self.message = 'Park ready; preparing visual Theater walk'
            return None
        action = self.ACTIONS[self.scene]
        self.press(*action, now, 'Menu recovery: %s on %s' % (action[0], self.scene), source=self.scene)
        return self.tick(now)
