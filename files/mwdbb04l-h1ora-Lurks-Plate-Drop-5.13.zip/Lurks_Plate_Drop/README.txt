Lurk's Plate Drop 5.12 - OVR Bar Stop / Random Shots

Reload Lurks_Plate_Drop.py in Creative. Load only this combined script.
Keep its matching Lurks_Plate_Drop folder beside it. Keep NETX on Shooting
with Quit Game enabled. No network-adapter manipulation is used.

FINAL DOOR APPROACH
After the entrance-relative court is selected, a close, centered doorframe
is checked twice, half a second apart. This corrects optical-flow drift at the
threshold. The final approach holds left stick fully forward for up to four
seconds with camera and lateral movement neutral. It releases immediately for
loading or lost video. If the opening remains confirmed, it releases briefly
and retries once before waiting for loading. No separate entry button is needed.
Geometric checks run at most twice per second only during selected-door entry.

GAMEPLAY MOVEMENT
Random left-stick directions and strengths change every 0.35-1.1 seconds,
with occasional neutral pauses. Short right-stick flicks last 0.07-0.14 seconds,
with release between flicks. Pauses during quitting, menus and Theater walking.
The continuous recovery improvements remain enabled. Changing movement does
not guarantee that Xbox power management or Remote Play stays connected.

SETTINGS
Plate Drop retains its movement switch. Turnovers contains only Turnover Limit
and the box-color explanation. The Recovery / Theater tab is removed.
Turnover monitoring, pause at the limit, NETX quit, automatic reset, the TO box,
status, menu recovery, Theater walking, guide lines and detection outlines are
always on. Legacy saved false values for these options are ignored.

AUTOMATIC RESET
After the turnover limit triggers NETX quit, a confirmed return menu/city clears
the old counter and red box automatically. Yellow TO 0 means ready/waiting for
fresh gameplay readings. It does not invent an OCR result. The recovery walk
continues uninterrupted. Confirmed gameplay (TO or FG%) releases the walker and
rearms the next cycle. FG% is not interpreted as a turnover count. No L3 + Down
reset is required between games. That shortcut is an emergency pause; reload
the script to resume after using it.

LIGHTWEIGHT VISION
Expensive navigation checks run at most four times per second. Controller output
and the cheap loading-screen check still run with the host callbacks. Outdoor
landmarks are not searched while indoors; lobby templates use a smaller image
and cached scales. Menu templates are skipped while the walker is active.
After selecting the court, a small set of tracked corners follows its physical
slot instead of repeatedly scanning all doorways and event signs. Forward/backward
tracking checks reject unreliable motion. The status file reports vision timing.

DOOR SELECTION
The intended target remains the entrance-relative right-hand court, not whichever
door looks rightmost later. The supplied Oct 27 recording revealed a different
entry view and crowds hiding the opening. A calibrated permanent-wall reference
for that view now locates the same physical slot. The camera holds while the view
is confirmed, then tracks the selected slot through the turn. Weekly event names
are not used for selection. Uncertain tracking stops movement instead of choosing
an adjacent court. Start at the Theater entrance for a direct test, or let the
normal return cycle bring the player there.

VALIDATION
Version 5.8 passed simulated full-down output, neutral right stick, stale-frame
release, TO/menu/disable pauses and Theater control priority. Door navigation
is unchanged from version 5.7. In-game results require a live test.

CONTINUOUS RUNNING / REMOTE PLAY
There is no overall runtime limit. Recoverable menu/walking failures remain
armed. After a 30-second cooldown and at least two seconds of fresh video,
confirmed menus/errors can resume, or a failed walker can start localization
again. Unknown menu screens remain waiting. Missing video releases movement.
The script cannot power on an Xbox or reconnect a Remote Play session itself.
Unloading the script stops it; L3 + Down remains the emergency pause.
Controller API errors still require correcting the cause and reloading.
For overnight use, check the Xbox inactivity shutdown setting and the PC's
sleep setting. Confirm the Remote Play controller path works with your GPC
setup before leaving it unattended. This update has not been live-tested with
Remote Play and Helios GPC 3.
Validated cooldowns, video return, recognized-menu gating, manual stop,
walker relocalization, movement pauses and 12 hours of simulated movement.

THEATER ENTRANCE FIX (5.11)
The Oct 28 recording shows the walker losing the large exterior sign near the
entrance, stopping, and repeatedly searching. A close-up statue/base reference
now provides a separate doorway aim point when that sign leaves the view.
After repeated centered close detections, the walker holds forward up to five
seconds, releasing immediately for loading or video loss. It waits eight more
seconds for loading before allowing normal recovery retry. The reference
excludes the weekly event banners. This is an exterior entrance fix; the
entrance-relative indoor court selection remains unchanged.
Passed supplied-frame reacquisition, bounded entry, loading release, negative
frames, prior indoor navigation checks and actual Creative encoder tests.
The entire three-hour session was not recorded here; live entry needs testing.

OVR BAR STOP + RANDOM SHOTS (5.12)
- Stops the script once the end-of-game OVR PERFORMANCE bar has no blue left.
- Reads only the bar and its OVR PERFORMANCE label; rank emblem and name are ignored.
- Needs about one second of the recap page with that bar; reload the script to run again.
- New Random shooting switch on the Plate Drop tab (Square / X, on by default).
- Shots hold 0.4-0.9 s every 3-8 s, only while the in-game stat HUD is visible.
- Recap overlay: colour ring beside the bar plus the decision text under the label.
- Ring colours: blue = blue bar, grey = empty bar, white = ticks, pink = other, red = unreadable.
- Overlay never covers the pixels the bar check reads (Helios draws into the frame).
- Creative GUI title is now Freakbob Stole Lurk's Plate Drop; new Patch notes tab.
- Checked on the Nov 3 recording plus edited empty / 5% bars; not live-tested yet.

BACK OUT + BLACK PLATE ESTIMATE (5.13)
- After an OVR stop: Continue on the recap, then Exit (Circle) on Waiting For Opponent.
- Then Yes (Cross) on "Are you sure you want to leave?"; lands in the Theater lobby.
- Presses only on confirmed screens; never Circle on the leave dialog (Circle = No).
- Retries Exit / Yes up to 3 times; gives up after 150 s without the queue screen.
- L3 + Down cancels the back-out. Bottom-left overlay shows each step and what it sees.
- Black plate tab: games and time to an empty bar from the per-recap bar drop.
- One reading per recap (median, about 0.05% steady) kept in ovr_history.json.
- Started with three readings from the Nov 3 recordings: 56.15, 47.83, 46.56%.
- A gap over 30 min between recaps starts a new trend; tick marks give the next rank.
- GUI fields are filled through the host's set_value; overlay and status line show it too.
