"""End-of-game OVR PERFORMANCE bar: report when its blue fill is gone.

Only the fixed OVR PERFORMANCE label and the bar's own arc are read. The
emblem and rank name above the bar change with rank, so neither is compared.
Measured on the Nov 3 recording; coordinates are 1920x1080 design pixels.
"""
import math
from pathlib import Path

import cv2
import numpy as np

# The label reference keeps the recording's scale; live crops are reduced to it.
SCALE = (1162/1920, 655/1080)
LABEL = (144.1, 396.0)                     # label reference top-left
SLACK = 24                                 # slide-in / capture offset tolerated
CENTER = (243.2, 399.3)                    # bar centre when the label is at LABEL
RADII = (109.2, 111.7, 114.2, 116.7, 119.2)  # inside the 106-123 px bar band
# The bar runs from -90 (left end) over the top to +90 degrees (right end).
ANGLES = np.radians(np.arange(-88, 89) - 90.0)
LABEL_MIN = .6
EMPTY_BINS = 1                             # no visible blue: one stray angle at most
CONFIRM_SECONDS, CONFIRM_READS = 1.0, 4
# Overlay pixels land in the frame itself, so the ring sits outside the bar band
# and the text below the label search area; nothing covers a pixel read above.
KINDS = 'BCWT.'                            # blue, other colour, tick, grey track, unreadable
KIND_COLORS = {'B': (40, 160, 255), 'C': (235, 90, 235), 'W': (255, 255, 255),
               'T': (150, 150, 150), '.': (255, 60, 60)}
RING = 129
GREEN, ORANGE, RED, YELLOW = (70, 230, 100), (255, 170, 40), (255, 70, 70), (255, 220, 60)
# Fill percentage for the black plate estimate: quarter-degree steps, middle of the band.
FINE_ANGLES = np.arange(-89.5, 89.51, .25)
FINE_RADII = np.array([110.5, 112.5, 114.2, 116.0, 118.0])[:, None]
RECAP_END = 4.0     # seconds without the bar before a recap's reading is final


class OvrBar:
    def __init__(self, root):
        self.label = cv2.imread(str(Path(root) / 'ovr_performance.png'), cv2.IMREAD_GRAYSCALE)
        if self.label is None:
            raise RuntimeError('Missing OVR PERFORMANCE reference')
        self.checked = -10.0
        self.seen_at = -10.0
        self.reading = {}
        self.last_gauge = {}
        self.empty_since = None
        self.empty_reads = 0
        self.recap_pcts = []

    def observe(self, frame, now):
        """True once a readable bar has shown no blue for a full second."""
        if now - self.checked < .25:
            return False
        self.checked = now
        self.reading = reading = self.measure(frame)
        if reading.get('gauge'):
            self.seen_at = now
            self.last_gauge = dict(reading, at=round(now, 2))
            self.recap_pcts.append(reading['pct'])
        if not reading.get('gauge') or reading['bins'][0] > EMPTY_BINS:
            self.empty_since, self.empty_reads = None, 0
            return False
        if self.empty_since is None:
            self.empty_since = now
        self.empty_reads += 1
        return self.empty_reads >= CONFIRM_READS and now - self.empty_since >= CONFIRM_SECONDS

    def pop_game(self, now, force=False):
        """The finished recap's bar (median %), once the recap has gone; else None."""
        if not self.recap_pcts or (not force and now - self.seen_at < RECAP_END):
            return None
        pct = float(np.median(self.recap_pcts))
        self.recap_pcts = []
        return round(pct, 2)

    def measure(self, frame):
        h, w = frame.shape[:2]
        fx, fy = w / 1920, h / 1080
        th, tw = self.label.shape
        x1, y1 = LABEL[0] - SLACK, LABEL[1] - SLACK
        x2, y2 = LABEL[0] + tw / SCALE[0] + SLACK, LABEL[1] + th / SCALE[1] + SLACK
        crop = frame[round(y1*fy):round(y2*fy), round(x1*fx):round(x2*fx), :3]
        size = (round((x2-x1) * SCALE[0]), round((y2-y1) * SCALE[1]))
        if not crop.size:
            return dict(label=0.0)
        crop = cv2.cvtColor(cv2.resize(crop, size, interpolation=cv2.INTER_AREA), cv2.COLOR_BGR2GRAY)
        _, score, _, (lx, ly) = cv2.minMaxLoc(cv2.matchTemplate(crop, self.label, cv2.TM_CCOEFF_NORMED))
        reading = dict(label=round(float(score), 3) if np.isfinite(score) else 0.0)
        if reading['label'] < LABEL_MIN:
            return reading
        # The bar moves with its label while the recap page slides in.
        cx = CENTER[0] + lx / SCALE[0] - SLACK
        cy = CENTER[1] + ly / SCALE[1] - SLACK
        reading['offset'] = (round(cx - CENTER[0], 1), round(cy - CENTER[1], 1))
        radii = np.array(RADII)[:, None]
        xs = np.rint((cx + radii*np.cos(ANGLES)) * fx).astype(int)
        ys = np.rint((cy + radii*np.sin(ANGLES)) * fy).astype(int)
        if xs.min() < 0 or ys.min() < 0 or xs.max() >= w or ys.max() >= h:
            return reading
        hsv = cv2.cvtColor(np.ascontiguousarray(frame[ys, xs, :3]), cv2.COLOR_BGR2HSV).astype(int)
        hue, sat, val = hsv[..., 0], hsv[..., 1], hsv[..., 2]
        colored = (sat >= 80) & (val >= 70)
        blue = colored & (hue >= 78) & (hue <= 132)
        kinds = np.stack([blue, colored & ~blue, ~colored & (val >= 150),
                          ~colored & (val >= 33) & (val < 150)]).sum(axis=1)
        # Each angle needs three of its five radial samples to agree.
        kind = np.where(kinds.max(axis=0) >= 3, kinds.argmax(axis=0), 4)
        blue_n, other_n, tick_n, track_n, unknown_n = np.bincount(kind, minlength=5)
        bar = blue_n + other_n + track_n
        reading.update(gauge=bool(unknown_n <= .1*len(ANGLES) and bar >= .75*len(ANGLES)),
                       blue=round(float(blue_n / max(bar, 1)), 3),
                       fill=round(float((blue_n + other_n) / max(bar, 1)), 3),
                       bins=[int(blue_n), int(other_n), int(tick_n), int(track_n), int(unknown_n)],
                       kinds=''.join(KINDS[k] for k in kind))
        if reading['gauge']:
            reading['pct'] = self._fill_pct(frame, cx, cy, fx, fy)
        return reading

    @staticmethod
    def _fill_pct(frame, cx, cy, fx, fy):
        """Where the blue run ends, as a percentage of the bar (about 0.05% steady)."""
        angles = np.radians(FINE_ANGLES - 90)
        xs = np.rint((cx + FINE_RADII*np.cos(angles)) * fx).astype(int)
        ys = np.rint((cy + FINE_RADII*np.sin(angles)) * fy).astype(int)
        hsv = cv2.cvtColor(np.ascontiguousarray(frame[ys, xs, :3]), cv2.COLOR_BGR2HSV).astype(int)
        share = ((hsv[..., 1] >= 80) & (hsv[..., 2] >= 70) & (hsv[..., 0] >= 78)
                 & (hsv[..., 0] <= 132)).mean(axis=0)
        found = np.nonzero(share >= .5)[0]
        if not len(found) or found[0] > 12:
            return 0.0
        # Follow the run from the left end; tick marks leave gaps under 3 degrees.
        breaks = np.nonzero(np.diff(found) > 12)[0]
        k = found[breaks[0]] if len(breaks) else found[-1]
        step = 0.0
        if k + 1 < len(share):
            step = min(1.0, max(0.0, (share[k] - .5) / max(1e-6, share[k] - share[k + 1])))
        return round(float((FINE_ANGLES[k] + step*.25 + 90) / 1.8), 2)

    def draw(self, overlay, now, stopped=None, note=None):
        """Show what the bar check sees (ring of per-angle classes) and what it decides.
        stopped: headline to show once the script has stopped, else None.
        note: an extra line under the panel (the black plate estimate)."""
        reading = self.reading
        if reading.get('label', 0) < LABEL_MIN or now - self.checked > (10 if stopped else .75):
            return
        style = dict(space=overlay.DESIGN_1080P, target=overlay.FRAME)
        dx, dy = reading['offset']
        if stopped:
            color, headline = RED, stopped
        elif not reading.get('gauge'):
            color, headline = YELLOW, 'OVR LABEL FOUND - BAR NOT READABLE'
        elif self.empty_reads:
            color, headline = ORANGE, 'NO BLUE LEFT - CONFIRMING %.2f / %g s' % (
                min(now - self.empty_since, CONFIRM_SECONDS), CONFIRM_SECONDS)
        else:
            color, headline = GREEN, 'BLUE BAR %d%% - KEEP RUNNING' % round(100*reading['blue'])
        # Underline the matched label just below its reference area.
        th, tw = self.label.shape
        y = round(LABEL[1] + dy + th/SCALE[1] + 10)
        overlay.line(round(LABEL[0] + dx + 4), y, round(LABEL[0] + dx + tw/SCALE[0] - 4), y,
                     color=color, thickness=2, **style)
        detail = 'label match %.2f' % reading['label']
        if reading.get('gauge'):
            cx, cy = CENTER[0] + dx, CENTER[1] + dy
            kinds = reading['kinds']
            for k in range(0, len(kinds), 3):
                part = kinds[k:k+3]
                a, b = math.radians(k - 178.5), math.radians(k - 178.5 + len(part))
                overlay.line(round(cx + RING*math.cos(a)), round(cy + RING*math.sin(a)),
                             round(cx + RING*math.cos(b)), round(cy + RING*math.sin(b)),
                             color=KIND_COLORS[max(part, key=part.count)], thickness=6, **style)
            blue_n, other_n, tick_n, track_n, unknown_n = reading['bins']
            detail += ' | angles: %d blue, %d grey, %d tick' % (blue_n, track_n, tick_n)
            if other_n or unknown_n:
                detail += ', %d other, %d unread' % (other_n, unknown_n)
        overlay.text(headline, 120, 456, color=color, scale=3, **style)
        overlay.text(detail, 120, 488, color=(235, 235, 235), scale=2, **style)
        overlay.text('Stops after %g s with no blue (%d+ checks)' % (CONFIRM_SECONDS, CONFIRM_READS),
                     120, 512, color=(235, 235, 235), scale=2, **style)
        if note:
            overlay.text(note, 120, 536, color=(120, 220, 255), scale=2, **style)
