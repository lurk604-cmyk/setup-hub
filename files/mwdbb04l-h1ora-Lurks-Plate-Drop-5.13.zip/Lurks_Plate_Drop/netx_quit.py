"""One-shot NETX button click, isolated from Helios frame processing.

Only a verified NetX.exe window is eligible. Match the cyan group heading,
then require the enabled button's cyan fill and dark label.
"""
import ctypes
from ctypes import wintypes as W
import os
from pathlib import Path
import threading
import time


def process_is_elevated(kernel, process):
    security = ctypes.WinDLL('advapi32', use_last_error=True)
    security.OpenProcessToken.argtypes = [W.HANDLE, W.DWORD, ctypes.POINTER(W.HANDLE)]
    security.GetTokenInformation.argtypes = [W.HANDLE, ctypes.c_int, ctypes.c_void_p,
                                            W.DWORD, ctypes.POINTER(W.DWORD)]
    token = W.HANDLE()
    if not security.OpenProcessToken(process, 0x0008, ctypes.byref(token)):
        return None
    try:
        elevated, size = W.DWORD(), W.DWORD()
        if not security.GetTokenInformation(token, 20, ctypes.byref(elevated),
                                           ctypes.sizeof(elevated), ctypes.byref(size)):
            return None
        return bool(elevated.value)
    finally:
        kernel.CloseHandle(token)


def focus_netx(api, kernel, hwnd):
    """Try normal activation, then temporarily share the foreground input queue."""
    if api.GetForegroundWindow() == hwnd:
        return True
    api.SetForegroundWindow(hwnd)
    if api.GetForegroundWindow() == hwnd:
        return True
    foreground = api.GetForegroundWindow()
    foreground_thread = api.GetWindowThreadProcessId(foreground, None) if foreground else 0
    own_thread = kernel.GetCurrentThreadId()
    attached = False
    try:
        if foreground_thread and foreground_thread != own_thread:
            attached = bool(api.AttachThreadInput(own_thread, foreground_thread, True))
        if attached:
            api.BringWindowToTop(hwnd)
            api.SetForegroundWindow(hwnd)
        return api.GetForegroundWindow() == hwnd
    finally:
        if attached:
            api.AttachThreadInput(own_thread, foreground_thread, False)


def locate_button(rgb, template):
    """Return window-relative button center, or an actionable failure message."""
    import cv2
    import numpy as np
    # Mask cyan text so moving game imagery outside the app cannot match it.
    def cyan(image):
        r, g, b = image[:, :, 0], image[:, :, 1], image[:, :, 2]
        return ((g > 125) & (b > 125) & (r < 100)).astype('uint8') * 255
    haystack, needle = cyan(rgb), cyan(template)
    haystack = cv2.GaussianBlur(haystack, (3, 3), 0)
    best = None
    for scale in (.8, .9, 1., 1.1, 1.25, 1.5, 1.75, 2.):
        target = cv2.resize(needle, None, fx=scale, fy=scale, interpolation=cv2.INTER_NEAREST)
        target = cv2.GaussianBlur(target, (3, 3), 0)
        h, w = target.shape
        if h > haystack.shape[0] or w > haystack.shape[1]:
            continue
        scores = cv2.matchTemplate(haystack, target, cv2.TM_CCOEFF_NORMED)
        _, score, _, point = cv2.minMaxLoc(scores)
        if best is None or score > best[0]:
            best = score, point, scale
    if best is None or best[0] < .80:
        return None, 'Open NETX on its Shooting tab'
    _, (x, y), scale = best
    # Offsets calibrated to the supplied NETX screenshot, from heading crop.
    x1, y1 = x + round(4*scale), y + round(32*scale)
    x2, y2 = x + round(108*scale), y + round(64*scale)
    body = rgb[y1:y2, x1:x2]
    if body.shape[:2] != (y2-y1, x2-x1):
        return None, 'NETX button is clipped'
    # The actual enabled button is CYAN with BLACK text. Bright-text gating
    # incorrectly rejected it; use the real supplied enabled-state screenshot.
    filled = cyan(body) > 0
    tx1, ty1 = x + round(24*scale), y + round(41*scale)
    tx2, ty2 = x + round(88*scale), y + round(57*scale)
    text = rgb[ty1:ty2, tx1:tx2]
    dark_text = text.max(axis=2) < 100
    if filled.mean() < .55 or np.count_nonzero(dark_text) < max(8, round(12*scale*scale)):
        return None, 'NETX Quit Game appears disabled (cyan fill not found)'
    return (x + round(57*scale), y + round(48*scale)), 'NETX Quit Game ready'


class NetxQuit:
    def __init__(self):
        self.message = 'NETX ready to monitor'
        self.cancel = threading.Event()
        self.thread = None
        self.attempted = False
        self.click_sent_at = None
        self.exit_confirmed = False

    def reset(self):
        self.cancel.set()
        self.attempted = False
        self.message = 'NETX ready to monitor'
        self.click_sent_at = None
        self.exit_confirmed = False

    def confirm_exit(self, code):
        self.exit_confirmed = True
        self.message = 'Connection error observed: %s; automatic recovery will continue' % code

    def mark_unconfirmed(self):
        if not self.exit_confirmed:
            self.message = 'NETX click sent; game exit not confirmed. Check the game before resetting.'

    def request(self, still_valid):
        if self.attempted or (self.thread and self.thread.is_alive()):
            return
        self.attempted = True
        self.cancel = threading.Event()
        self.thread = threading.Thread(target=self._run,
            args=(self.cancel, still_valid), name='PlateDropNetx', daemon=True)
        self.thread.start()

    def _run(self, cancel, still_valid):
        try:
            from PIL import Image, ImageGrab
            import numpy as np
            api = ctypes.WinDLL('user32', use_last_error=True)
            kernel = ctypes.WinDLL('kernel32', use_last_error=True)
            api.FindWindowW.argtypes = [W.LPCWSTR, W.LPCWSTR]
            api.FindWindowW.restype = W.HWND
            api.GetForegroundWindow.restype = W.HWND
            api.GetWindowThreadProcessId.argtypes = [W.HWND, ctypes.POINTER(W.DWORD)]
            api.GetWindowThreadProcessId.restype = W.DWORD
            api.AttachThreadInput.argtypes = [W.DWORD, W.DWORD, W.BOOL]
            api.BringWindowToTop.argtypes = [W.HWND]
            kernel.GetCurrentThreadId.restype = W.DWORD
            api.GetWindowRect.argtypes = [W.HWND, ctypes.POINTER(W.RECT)]
            api.IsIconic.argtypes = [W.HWND]
            api.ShowWindow.argtypes = [W.HWND, ctypes.c_int]
            api.SetForegroundWindow.argtypes = [W.HWND]
            api.WindowFromPoint.argtypes = [W.POINT]
            api.WindowFromPoint.restype = W.HWND
            api.GetAncestor.argtypes = [W.HWND, W.UINT]
            api.GetAncestor.restype = W.HWND
            kernel.OpenProcess.argtypes = [W.DWORD, W.BOOL, W.DWORD]
            kernel.OpenProcess.restype = W.HANDLE
            kernel.GetCurrentProcess.restype = W.HANDLE
            kernel.QueryFullProcessImageNameW.argtypes = [W.HANDLE, W.DWORD, W.LPWSTR, ctypes.POINTER(W.DWORD)]
            kernel.CloseHandle.argtypes = [W.HANDLE]
            class Mouse(ctypes.Structure):
                _fields_ = [('dx', W.LONG), ('dy', W.LONG), ('data', W.DWORD),
                            ('flags', W.DWORD), ('time', W.DWORD), ('extra', ctypes.c_size_t)]
            class Payload(ctypes.Union):
                _fields_ = [('mouse', Mouse)]
            class Input(ctypes.Structure):
                _fields_ = [('type', W.DWORD), ('payload', Payload)]
            api.SendInput.argtypes = [W.UINT, ctypes.POINTER(Input), ctypes.c_int]
            template = np.array(Image.open(Path(__file__).with_name('netx_heading.png')).convert('RGB'))
            deadline = time.monotonic() + 30
            focus_at = -10.0
            while not cancel.is_set() and time.monotonic() < deadline:
                if not still_valid():
                    self.message = 'NETX request expired, reset, or counter returned below limit'
                    return
                hwnd = api.FindWindowW(None, 'Net X')
                if not hwnd:
                    self.message = 'Open NETX on its Shooting tab'
                    cancel.wait(.5)
                    continue
                pid = W.DWORD()
                api.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
                process = kernel.OpenProcess(0x1000, False, pid.value)
                if not process:
                    raise RuntimeError('Cannot inspect NETX; check Helios/NETX permissions')
                try:
                    path, size = ctypes.create_unicode_buffer(32768), W.DWORD(32768)
                    if not kernel.QueryFullProcessImageNameW(process, 0, path, ctypes.byref(size)):
                        raise RuntimeError('Cannot verify NETX process')
                    if os.path.basename(path.value).lower() != 'netx.exe':
                        raise RuntimeError('Net X window does not belong to NetX.exe')
                    if (process_is_elevated(kernel, process) is True
                            and process_is_elevated(kernel, kernel.GetCurrentProcess()) is False):
                        raise RuntimeError('NETX runs as administrator. Run Helios as administrator too, then reload Plate Drop.')
                finally:
                    kernel.CloseHandle(process)
                if api.GetForegroundWindow() != hwnd and time.monotonic() - focus_at > 2:
                    if api.IsIconic(hwnd):
                        api.ShowWindow(hwnd, 9)
                    focus_netx(api, kernel, hwnd)
                    focus_at = time.monotonic()
                    if cancel.wait(.25):
                        return
                if api.GetForegroundWindow() != hwnd:
                    self.message = 'Windows blocked NETX focus; bring its Shooting tab forward'
                    cancel.wait(.5)
                    continue
                rect = W.RECT()
                if not api.GetWindowRect(hwnd, ctypes.byref(rect)):
                    raise RuntimeError('NETX window disappeared')
                rgb = np.array(ImageGrab.grab(bbox=(rect.left, rect.top, rect.right, rect.bottom), all_screens=True).convert('RGB'))
                point, self.message = locate_button(rgb, template)
                if point is None:
                    cancel.wait(.5)
                    continue
                target = W.POINT(rect.left + point[0], rect.top + point[1])
                under = api.WindowFromPoint(target)
                if (cancel.is_set() or not still_valid() or api.GetForegroundWindow() != hwnd
                        or api.GetAncestor(under, 2) != hwnd):
                    self.message = 'NETX click cancelled: window or counter changed'
                    return
                # Use one down/up pair; never retry an ambiguous click outcome.
                if not api.SetCursorPos(target.x, target.y):
                    raise RuntimeError('Cannot position NETX click')
                current = W.RECT()
                if (cancel.is_set() or not still_valid()
                        or api.GetForegroundWindow() != hwnd
                        or not api.GetWindowRect(hwnd, ctypes.byref(current))
                        or tuple((current.left, current.top, current.right, current.bottom))
                        != tuple((rect.left, rect.top, rect.right, rect.bottom))
                        or api.GetAsyncKeyState(1) & 0x8000):
                    self.message = 'NETX click cancelled: window moved or mouse in use'
                    return
                down, up = Input(), Input()
                down.payload.mouse.flags = 0x0002
                up.payload.mouse.flags = 0x0004
                pressed = api.SendInput(1, ctypes.byref(down), ctypes.sizeof(Input))
                try:
                    # A real press interval gives NETX's UI time to process it.
                    time.sleep(.08)
                finally:
                    released = api.SendInput(1, ctypes.byref(up), ctypes.sizeof(Input))
                if pressed != 1 or released != 1:
                    raise RuntimeError('NETX input blocked; check Helios/NETX permissions')
                self.message = 'NETX click sent; waiting for connection-error confirmation'
                self.click_sent_at = time.monotonic()
                return
            if not cancel.is_set():
                self.message += ' (timed out; L3 + Down to retry)'
        except Exception as exc:
            self.message = 'NETX: ' + str(exc)[:140]
