"""After the OVR stop: leave the next Theater queue the way the user does by hand.

Recap (Cross = Continue) -> THE THEATER loading -> Waiting For Opponent
(Circle = Exit) -> "Are you sure you want to leave?" (Cross = Yes) -> lobby.
Circle on that dialog means No, so Circle is never pressed while it shows.
References come from the Nov 3 17:21 recording (1166 px wide, no letterbox).
"""
from pathlib import Path

import cv2
import numpy as np

SCALE = (1166/1920, 654/1080)
SLACK = 20
# Reference top-left in 1920x1080 design pixels and the score it must reach.
REFS = {'queue': ((1561.4, 40.0), .7),     # "Waiting For Opponent" header
        'title': ((611.2, 413.2), .7),     # "Confirmation"
        'leave': ((612.9, 505.6), .65)}    # "Are you sure you want to leave?"
BUTTONS = {'A': 'BUTTON_16', 'B': 'BUTTON_15'}  # Cross / Circle
PULSE = .18
GREEN, ORANGE, RED = (70, 230, 100), (255, 170, 40), (255, 70, 70)
TITLES = {'recap': 'BACKING OUT - RECAP', 'wait_queue': 'BACKING OUT - WAITING FOR THE QUEUE SCREEN',
          'exit_sent': 'BACKING OUT - PRESSED EXIT (CIRCLE)', 'yes_sent': 'BACKING OUT - PRESSED YES (CROSS)',
          'done': 'BACKED OUT - SCRIPT STOPPED', 'failed': 'BACK-OUT FAILED - SCRIPT STOPPED'}


class BackOut:
    def __init__(self, root, ovr):
        self.refs = {}
        for name in REFS:
            image = cv2.imread(str(Path(root) / ('backout_%s.png' % name)), cv2.IMREAD_GRAYSCALE)
            if image is None:
                raise RuntimeError('Missing back-out reference: ' + name)
            self.refs[name] = image
        self.ovr = ovr
        self.state = 'idle'
        self.message = ''
        self.checked = -10.0
        self.scores = {}
        self.locations = {}
        self.hits = dict(queue=0, leave=0)
        self.recap = False
        self.pulse = None
        self.presses = []
        self.attempts = dict(continue_=0, exit=0, yes=0)
        self.started = self.since = self.last_press = self.clear_since = self.ended_at = None

    @property
    def active(self):
        return self.state not in ('idle', 'done', 'failed')

    def start(self, now):
        self.started = now
        self._go('recap', now, 'Recap: Continue (Cross), then wait for the queue screen')

    def fail(self, reason, now):
        self._go('failed', now, reason + '; back out by hand')

    def status(self):
        return dict(state=self.state, message=self.message, scores=dict(self.scores), hits=dict(self.hits),
                    presses=list(self.presses), attempts=dict(self.attempts))

    def observe(self, frame, now):
        if not self.active or now - self.checked < .25:
            return
        self.checked = now
        for name in REFS:
            self.scores[name], self.locations[name] = self._match(frame, name)
        queue = self.scores['queue'] >= REFS['queue'][1]
        leave = self.scores['leave'] >= REFS['leave'][1] and self.scores['title'] >= REFS['title'][1]
        self.hits['queue'] = self.hits['queue'] + 1 if queue else 0
        self.hits['leave'] = self.hits['leave'] + 1 if leave else 0
        if queue or leave:
            self.clear_since = None
        elif self.clear_since is None:
            self.clear_since = now
        if self.state == 'recap':
            self.recap = self.ovr.measure(frame).get('label', 0) >= .6
        self._advance(now)

    def tick(self, now):
        """Controller writes for this cycle: hold the pressed button, then release it once."""
        if self.pulse is None:
            return {}
        name, started = self.pulse
        if started is None:
            # The pulse clock starts on the controller callback, not in vision.
            self.pulse[1] = started = now
        if now - started < PULSE:
            return {name: 100}
        self.pulse = None
        return {name: 0}

    def _advance(self, now):
        if self.pulse is not None:
            return  # Let the current press finish first.
        queue, leave = self.hits['queue'] >= 2, self.hits['leave'] >= 2
        state, waited = self.state, now - self.since
        since_press = now - self.last_press if self.last_press is not None else 99
        if state in ('recap', 'wait_queue') and queue:
            self._press('B', 'exit', now, 'exit_sent', 'Pressed Exit (Circle) on Waiting For Opponent')
        elif state == 'recap':
            if not self.recap and waited >= 1:
                self._go('wait_queue', now, 'Looking for the Waiting For Opponent screen')
            elif self.recap and waited >= 1 and not self.attempts['continue_']:
                # One press only: the recap also continues on its own after a few seconds.
                self._press('A', 'continue_', now, 'recap', 'Pressed Continue (Cross) on the recap')
        elif state == 'wait_queue':
            if waited > 150:
                self.fail('Waiting For Opponent never showed in 150 s', now)
        elif state == 'exit_sent':
            if leave:
                self._press('A', 'yes', now, 'yes_sent', 'Pressed Yes (Cross) on the leave dialog')
            elif since_press >= 3 and self.hits['queue']:
                if self.attempts['exit'] < 3:
                    self._press('B', 'exit', now, 'exit_sent', 'No leave dialog yet: Exit (Circle) again')
                else:
                    self.fail('Exit (Circle) did not open the leave dialog', now)
            elif since_press >= 6:
                self.fail('Queue screen closed without the leave dialog', now)
        elif state == 'yes_sent':
            if self.hits['leave']:
                if since_press >= 2.5:
                    if self.attempts['yes'] < 3:
                        self._press('A', 'yes', now, 'yes_sent', 'Dialog still open: Yes (Cross) again')
                    else:
                        self.fail('Yes (Cross) did not close the leave dialog', now)
            elif queue and since_press >= 3:
                if self.attempts['exit'] < 3:
                    self._press('B', 'exit', now, 'exit_sent', 'Still in the queue: Exit (Circle) again')
                else:
                    self.fail('Still in the queue after 3 tries', now)
            elif self.clear_since is not None and now - self.clear_since >= 1.5:
                self._go('done', now, 'Left the queue; back in the Theater lobby')

    def _press(self, button, kind, now, state, message):
        self.attempts[kind] += 1
        self.pulse = [BUTTONS[button], None]
        self.last_press = now
        self.presses.append('%s %.1fs' % ({'A': 'Cross', 'B': 'Circle'}[button], now - self.started))
        self._go(state, now, message)

    def _go(self, state, now, message):
        self.state, self.since, self.message = state, now, message
        if state in ('done', 'failed'):
            self.ended_at = now

    def _match(self, frame, name):
        h, w = frame.shape[:2]
        fx, fy = w / 1920, h / 1080
        (lx, ly), _ = REFS[name]
        ref = self.refs[name]
        th, tw = ref.shape
        x1, y1 = lx - SLACK, ly - SLACK
        x2, y2 = lx + tw / SCALE[0] + SLACK, ly + th / SCALE[1] + SLACK
        crop = frame[round(y1*fy):round(y2*fy), round(x1*fx):round(x2*fx), :3]
        if not crop.size:
            return 0.0, None
        size = (round((x2-x1) * SCALE[0]), round((y2-y1) * SCALE[1]))
        crop = cv2.cvtColor(cv2.resize(crop, size, interpolation=cv2.INTER_AREA), cv2.COLOR_BGR2GRAY)
        _, score, _, (mx, my) = cv2.minMaxLoc(cv2.matchTemplate(crop, ref, cv2.TM_CCOEFF_NORMED))
        if not np.isfinite(score):
            return 0.0, None
        return round(float(score), 3), (round(x1 + mx / SCALE[0], 1), round(y1 + my / SCALE[1], 1))

    def draw(self, overlay, now):
        """Bottom-left readout of each back-out step, clear of every reference area."""
        if self.state == 'idle' or (self.ended_at is not None and now - self.ended_at > 20):
            return
        style = dict(space=overlay.DESIGN_1080P, target=overlay.FRAME)
        color = GREEN if self.state == 'done' else RED if self.state == 'failed' else ORANGE
        message = self.message
        if self.state == 'wait_queue':
            message += ' (%d s)' % (now - self.since)
        scores = ' | '.join('%s %.2f' % (name, self.scores.get(name, 0)) for name in ('queue', 'title', 'leave'))
        overlay.text(TITLES[self.state], 40, 900, color=color, scale=3, **style)
        overlay.text(message, 40, 932, color=(235, 235, 235), scale=2, **style)
        overlay.text('seen: %s | presses: %s' % (scores, ', '.join(self.presses) or 'none'),
                     40, 956, color=(235, 235, 235), scale=2, **style)
        # Underline a matched screen just below its reference text.
        for name in ('queue', 'leave'):
            if self.active and self.hits[name] and self.locations.get(name):
                x, y = self.locations[name]
                th, tw = self.refs[name].shape
                y = round(y + th / SCALE[1] + 6)
                overlay.line(round(x + 4), y, round(x + tw / SCALE[0] - 4), y, color=color, thickness=2, **style)
