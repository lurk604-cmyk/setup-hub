"""Track the selected physical slot using nearby structural corners, not labels."""
import cv2
import numpy as np

class SlotTracker:
    def __init__(self):
        self.gray=None
        self.points=None
        self.match=None
        self.checked=-10.

    def seed(self,gray,target,now):
        self.gray=gray.copy()
        self.match=dict(target)
        self.checked=now
        self.points=self.features(gray,target)
        return self.points is not None and len(self.points)>=6

    @staticmethod
    def features(gray,target):
        p=np.array(target['polygon'])/4
        left,top=p.min(axis=0);right,bottom=p.max(axis=0)
        mask=np.zeros_like(gray)
        # Static wall, lintel and sign mounting above the slot; avoid the
        # crowd standing in front of the opening and the floor nameplates.
        x1=max(0,int(left)-30);x2=min(gray.shape[1],int(right)+30)
        y1=max(0,int(top)-50);y2=min(gray.shape[0],int(top)+5)
        mask[y1:y2,x1:x2]=255
        return cv2.goodFeaturesToTrack(gray,48,.015,5,mask=mask,blockSize=5)

    def observe(self,gray,now):
        self.checked=now
        if self.points is None or self.gray is None or self.match is None:return None
        points,ok,_=cv2.calcOpticalFlowPyrLK(self.gray,gray,self.points,None,
                    winSize=(15,15),maxLevel=3,criteria=(cv2.TERM_CRITERIA_EPS|cv2.TERM_CRITERIA_COUNT,15,.03))
        if points is None or ok is None:return self.fail()
        back,back_ok,_=cv2.calcOpticalFlowPyrLK(gray,self.gray,points,None,
                    winSize=(15,15),maxLevel=3,criteria=(cv2.TERM_CRITERIA_EPS|cv2.TERM_CRITERIA_COUNT,15,.03))
        if back is None or back_ok is None:return self.fail()
        valid=(ok.ravel()>0)&(back_ok.ravel()>0)&(np.linalg.norm(back-self.points,axis=2).ravel()<1.)
        old=self.points.reshape(-1,2)[valid];new=points.reshape(-1,2)[valid]
        if len(new)<6:return self.fail()
        matrix,inliers=cv2.estimateAffinePartial2D(old,new,method=cv2.RANSAC,ransacReprojThreshold=2,maxIters=300)
        if matrix is None or inliers is None or int(inliers.sum())<6:return self.fail()
        scale=float(np.hypot(matrix[0,0],matrix[1,0]))
        if not .72<scale<1.4 or np.linalg.norm(matrix[:,2])>100:return self.fail()
        polygon=cv2.transform((np.array(self.match['polygon'],np.float32)/4).reshape(1,-1,2),matrix)[0]*4
        if not np.isfinite(polygon).all():return self.fail()
        center=polygon.mean(axis=0)
        if not -120<center[0]<2040 or not -100<center[1]<1300:return self.fail()
        width=float((np.linalg.norm(polygon[1]-polygon[0])+np.linalg.norm(polygon[2]-polygon[3]))/2)
        self.match=dict(id='queue_threshold',name='Locked entrance-right court',kind='tracked_slot',
                       polygon=polygon.tolist(),aim=[float(center[0]),float(max(polygon[:,1]))],
                       width=width,observed_at=now)
        self.gray=gray.copy()
        self.points=new[inliers.ravel()>0].reshape(-1,1,2)
        if len(self.points)<20:
            refreshed=self.features(gray,self.match)
            if refreshed is not None and len(refreshed)>=6:self.points=refreshed
        return self.match

    def fail(self):
        self.points=None
        self.match=None
        return None
