"""Visual Theater approach. Positive right-stick X searches to the right."""
from .waypoint_detector import Detector
from .door_threshold import ThresholdDetector
from .slot_tracker import SlotTracker
from time import perf_counter

class Navigator:
    def __init__(self,root):
        self.detector=Detector(root)
        self.active=False
        self.state='idle'
        self.message='START: look right for the Theater sign'
        self.started=self.stage_started=self.last_frame=-10.
        self.loading=False
        self.dark_since=None
        self.last_sequence=-1
        self.hits={}
        self.last_target=-10.
        self.best_width=0
        self.progress_at=0
        self.near_entrance=False
        self.yaw_sign=1
        self.progress_target=None
        self.guide=None
        self.threshold=ThresholdDetector()
        self.queue_anchor=None
        self.queue_anchor_at=-10.
        self.entry_started=0.
        self.entry_target=None
        self.centered_hits=0
        self.centered_seen=-10.
        self.entry_last_seen=-10.
        self.entry_stall_point=None
        self.entry_stall_at=0.
        self.entry_error=None
        self.entry_retries=0
        self.interior_hits=0
        self.slot=SlotTracker()
        self.vision_at=-10.
        self.vision_ms=0.
        self.small_gray=None
        self.close_door=ThresholdDetector()
        self.close_checked=-10.
        self.close_hits=0
        self.finish_started=0.
        self.finish_attempt=0

    def start(self,now):
        self.detector.load()
        self.active=True
        self.state='locate_start'
        self.started=self.stage_started=self.last_target=self.progress_at=now
        self.last_sequence=-1
        self.hits={}
        self.best_width=0
        self.near_entrance=False
        self.dark_since=None
        self.progress_target=None
        self.detector.matches={}
        self.detector.checked=-10.
        self.message='Checking the current view before starting the walk'
        self.threshold=ThresholdDetector()
        self.queue_anchor=None
        self.queue_anchor_at=-10.
        self.entry_started=0.
        self.entry_target=None
        self.centered_hits=0
        self.centered_seen=-10.
        self.entry_last_seen=-10.
        self.entry_stall_point=None
        self.entry_stall_at=0.
        self.entry_error=None
        self.entry_retries=0
        self.interior_hits=0
        self.slot=SlotTracker()
        self.vision_at=-10.
        self.small_gray=None
        self.close_door=ThresholdDetector()
        self.close_checked=-10.
        self.close_hits=0
        self.finish_started=0.
        self.finish_attempt=0




    def begin_entry(self,target,now):
        self.transition('align_queue',now)
        self.entry_started=now
        self.entry_target=target
        self.centered_hits=0
        self.centered_seen=-10.
        self.entry_stall_point=None
        self.entry_stall_at=now
        self.message='Centering on the open locked court doorway before walking in'

    def current_door_target(self,now):
        if self.slot.match is not None and now-self.slot.checked<.6:
            return self.slot.match
        if self.threshold.locked and self.slot.gray is not None:
            return None
        if self.threshold.match is not None and now-self.threshold.checked<.4:
            return self.threshold.match
        return None

    def align_output(self,now):
        if now-self.entry_started>30 or now-self.stage_started>15:
            if self.entry_retries<2:
                self.entry_retries+=1
                self.stage_started=now
                self.entry_started=now
                self.message='Waiting to reacquire the same locked doorway (%d/2)'%self.entry_retries
                return {}
            self.stop('Could not center on the doorway; stopped')
            return {}
        target=self.current_door_target(now)
        if target is None:
            self.centered_hits=0
            self.message='Waiting for a clear view of the selected doorway'
            return {}
        self.entry_target=target
        self.set_guide(target,now)
        error=target['aim'][0]-960
        self.entry_error=error
        self.message='Centering on the open locked court doorway before walking in'
        tolerance=max(20,min(60,target.get('width',300)*.20))
        if abs(error)<=tolerance:
            if target['observed_at']!=self.centered_seen:
                self.centered_seen=target['observed_at']
                self.centered_hits+=1
            if self.centered_hits>=3:
                self.transition('enter_queue',now)
                self.entry_last_seen=now
                self.entry_stall_at=now
                self.entry_stall_point=None
                return self.enter_output(now)
            return {}
        self.centered_hits=0
        # Use the same effective turn strength as the successful rightward
        # search, with short settling gaps. Do not push into the side frame.
        yaw=(1 if error>0 else -1)*35*self.yaw_sign
        duty=.18 if abs(error)>180 else .08
        return {'STICK_1_X':yaw if (now-self.stage_started)%.40<duty else 0}

    def enter_output(self,now):
        if now-self.entry_started>30:
            self.stop('Door entry timed out without loading; stopped')
            return {}
        target=self.current_door_target(now)
        if target is not None:
            self.entry_target=target
            self.entry_last_seen=now
            error=target['aim'][0]-960
            self.entry_error=error
            if abs(error)>max(30,min(110,target.get('width',366)*.30)):
                self.transition('align_queue',now)
                self.centered_hits=0
                self.centered_seen=-10.
                return self.align_output(now)
            point=(target['aim'][0],target['aim'][1],target['width'])
            old=self.entry_stall_point
            if (old is None or abs(point[0]-old[0])>25 or abs(point[1]-old[1])>12
                    or abs(point[2]-old[2])>max(8,old[2]*.04)):
                self.entry_stall_point=point
                self.entry_stall_at=now
            elif now-self.entry_stall_at>3.5:
                self.stop('No movement through the doorway detected; possible obstruction. Stopped.')
                return {}
        elif now-self.entry_last_seen>1.8:
            # Continue through the threshold as it passes under the camera,
            # then release if no visible doorway remains to follow.
            self.transition('wait_queue',now)
            self.message='Entry movement completed; waiting for game loading'
            return {}
        if self.entry_target:self.set_guide(self.entry_target,now,moving=True,lateral=0)
        self.message='Walking straight through the centered locked court doorway'
        return dict(STICK_1_X=0,STICK_2_X=0,STICK_2_Y=-100)

    def check_close_opening(self,frame,now):
        """At the selected threshold, validate the actual opening, not optical-flow drift."""
        if not self.threshold.locked or self.state not in ('align_queue','enter_queue','finish_queue'):
            return
        if now-self.close_checked<.5:return
        self.close_checked=now
        import numpy as np
        # Most approach frames do not need another geometric scan.
        if np.mean(self.small_gray[80:190,180:300]<70)<.35:
            self.close_hits=0
            return
        self.close_door.observe(frame,now,hint_x=960)
        target=self.close_door.match
        valid=(target is not None and target.get('kind')=='door_frame'
               and target['width']>=300 and abs(target['aim'][0]-960)<=90
               and target['aim'][1]>=800
               and target['polygon'][0][0]<890 and target['polygon'][1][0]>1030)
        if not valid:
            self.close_hits=0
            return
        self.close_hits+=1
        if self.close_hits>=2 and self.state!='finish_queue':
            self.entry_target=target
            self.entry_error=target['aim'][0]-960
            self.transition('finish_queue',now)
            self.finish_started=now
            self.finish_attempt=1
            self.message='Actual doorway confirmed; walking through the threshold'

    def finish_output(self,now):
        elapsed=now-self.finish_started
        if elapsed<4:
            self.set_guide(self.entry_target,now,moving=True)
            self.message='Walking through the confirmed opening (%d/2)'%self.finish_attempt
            return dict(STICK_1_X=0,STICK_1_Y=0,STICK_2_X=0,STICK_2_Y=-100)
        if elapsed<4.35:
            return {}  # Release before one bounded automatic retry.
        if self.finish_attempt==1 and self.close_hits>=2 and now-self.close_checked<.6:
            self.finish_attempt=2
            self.finish_started=now
            return self.finish_output(now)
        self.transition('wait_queue',now)
        self.message='Threshold movement finished; waiting for game loading'
        return {}


    def stop(self,message='Stopped; manual controls restored'):
        self.active=False
        self.state='stopped'
        self.guide=None
        self.message=message

    def observe(self,frame,now):
        if frame is None:return
        import cv2
        import numpy as np
        self.last_frame=now
        # Cheap loading check on every frame; the expensive vision cadence
        # must not delay releasing input when the game starts loading.
        pixels=frame[::24,::24,:3]
        self.loading=bool(np.mean(np.max(pixels,axis=2)<24)>.92)
        if self.loading:return
        if now-self.vision_at<.25:return
        self.vision_at=now
        started=perf_counter()
        self.small_gray=cv2.cvtColor(cv2.resize(frame[:,:,:3],(480,270)),cv2.COLOR_BGR2GRAY)
        self.check_close_opening(frame,now)
        if self.state=='finish_queue':
            pass  # Keep the camera still; do not let a lost feature undo entry.
        elif self.threshold.locked:
            self.slot.observe(self.small_gray,now)
        else:
            self.detector.mode=('inside' if self.state in ('search_queue','loading_theater') else
                                'outside' if self.state in ('search_theater','approach_theater') else 'auto')
            self.detector.observe(frame,now)
            if (self.state=='locate_start' and now-self.started>=.5
                    and not any(k in self.detector.matches for k in ('lobby','theater','entrance'))):
                # Only during initial classification: distinguish a reload
                # inside the lobby from a city spawn without scanning doors
                # throughout the normal outside walk.
                self.threshold.observe(frame,now,discover=True)
                self.interior_hits=self.interior_hits+1 if self.threshold.openings else 0
        self.vision_ms=(perf_counter()-started)*1000

    def lock_entrance_door(self,matches,now):
        """Select the physical far-right slot only in the entrance-facing view."""
        layout=matches.get('lobby')
        if layout is None or self.hits.get('lobby',0)<3:return False
        polygon=layout['polygon']
        center=sum(p[0] for p in polygon)/4
        if not 640<center<1280 or not 240<layout['width']<600:return False
        target=layout.get('door_hint')
        if target is None or self.small_gray is None:return False
        if not 1050<target['aim'][0]<1880:return False
        if not self.slot.seed(self.small_gray,target,now):return False
        self.queue_anchor=target['aim'][0]
        self.queue_anchor_at=now
        self.threshold.locked=True
        self.threshold.anchor=self.threshold.match=target
        self.threshold.anchor_at=now
        self.begin_entry(target,now)
        self.message='Entrance far-right doorway locked; weekly signs ignored'
        return True

    def transition(self,state,now):
        self.state=state
        self.stage_started=self.last_target=self.progress_at=now
        self.best_width=0
        self.hits={}

    def search(self,now):
        # Only rotate the camera. Pause briefly so features can settle.
        return {'STICK_1_X':35*self.yaw_sign} if (now-self.stage_started)%1.1<.8 else {}

    def set_guide(self,target,now,moving=False,lateral=0):
        self.guide=dict(origin=[960,900],target=list(target['aim']),
            name=target['name'],id=target['id'],observed_at=now,
            confirmed=self.hits.get(target['id'],0)>=3,moving=moving,lateral=lateral)

    def steer(self,target,now):
        x=target['aim'][0]
        error=(x-960)/960
        yaw=0 if abs(error)<.035 else self.yaw_sign*(1 if error>0 else -1)*min(35,max(18,abs(error)*85))
        forward=-100 if abs(error)<.32 else 0
        # Target must be seen repeatedly before any forward movement.
        if self.hits.get(target['id'],0)<3:forward=0
        lateral=0
        if forward and abs(error)>.045:
            lateral=(1 if error>0 else -1)*min(40,max(20,round(abs(error)*140)))
        self.set_guide(target,now,moving=bool(forward),lateral=lateral)
        width=target['width']
        if self.progress_target!=target.get('name',target['id']):
            self.progress_target=target.get('name',target['id'])
            self.best_width=width
            self.progress_at=now
        if forward:
            if width>self.best_width*1.04:
                self.best_width=width
                self.progress_at=now
            elif now-self.progress_at>12:
                self.stop('No visible progress; possible obstruction. Stopped.')
                return {}
        return dict(STICK_1_X=yaw,STICK_2_X=lateral,STICK_2_Y=forward)

    def output(self,now):
        self.guide=None
        if not self.active:return {}
        if now-self.last_frame>.4:
            if now-self.started<1:return {}
            self.stop('Video missing; stopped')
            return {}
        if now-self.started>240:
            self.stop('Walk timed out; stopped')
            return {}
        fresh=now-self.detector.checked<.4
        matches=self.detector.matches if fresh else {}
        if self.detector.sequence!=self.last_sequence:
            self.last_sequence=self.detector.sequence
            self.hits={k:self.hits.get(k,0)+1 for k in matches}
        # A loading transition is accepted only after getting close to the
        # outside entrance. Indoor signs provide a second, visual confirmation.
        if self.loading:
            if self.dark_since is None:self.dark_since=now
            if self.state in ('approach_theater','enter_theater') and self.near_entrance and now-self.dark_since>.25:
                self.transition('loading_theater',now)
            elif self.state in ('approach_queue','align_queue','enter_queue','finish_queue','wait_queue') and now-self.dark_since>.4:
                self.active=False
                self.state='done'
                self.message='Transition at the locked court doorway detected; walking stopped'
            self.message='Waiting for loading' if self.active else self.message
            if now-self.dark_since>90:self.stop('Loading timed out; stopped')
            return {}
        self.dark_since=None
        if self.state=='finish_queue':return self.finish_output(now)
        if self.state=='enter_theater':
            elapsed=now-self.stage_started
            self.message='Walking through the confirmed Theater entrance'
            if elapsed<5:
                return dict(STICK_1_X=0,STICK_2_X=0,STICK_2_Y=-100)
            self.message='Waiting for Theater loading'
            if elapsed>13:self.stop('Theater entrance did not load; waiting to retry')
            return {}
        if self.state=='locate_start':
            if self.lock_entrance_door(matches,now):return self.align_output(now)
            if self.hits.get('lobby',0)>=3 or (self.interior_hits>=2 and not matches.get('theater') and not matches.get('entrance')):
                self.transition('search_queue',now)
            elif now-self.stage_started>=1.2 or self.hits.get('theater',0)>=3:
                self.transition('search_theater',now)
            else:
                self.message='Checking the entrance layout before selecting a doorway'
                return {}
        if self.state=='align_queue':return self.align_output(now)
        if self.state=='enter_queue':return self.enter_output(now)
        if self.state=='wait_queue':
            self.message='Door entry movement completed; waiting for loading'
            if now-self.stage_started>15:
                self.stop('Door entry movement completed; no loading transition seen yet. Walking stopped.')
            return {}
        if self.state=='loading_theater':
            self.transition('search_queue',now)
        if self.state in ('search_theater','approach_theater') and self.near_entrance and self.hits.get('lobby',0)>=3:
            self.transition('search_queue',now)
        if self.state=='search_theater':
            if matches.get('theater'):self.set_guide(matches['theater'],now)
            self.message='Looking RIGHT for the Theater sign; no forward movement'
            if self.hits.get('theater',0)>=3 or self.hits.get('entrance',0)>=3:
                self.transition('approach_theater',now)
            else:
                if now-self.stage_started>35:self.stop('Theater sign not found; stopped')
                return self.search(now) if self.active else {}
        if self.state=='approach_theater':
            if now-self.stage_started>90:
                self.stop('Theater entrance not reached; stopped')
                return {}
            target=matches.get('entrance') or matches.get('theater')
            if target is None:
                self.message='Theater obscured; pausing walking'
                if now-self.last_target>5:self.stop('Lost Theater entrance; stopped')
                return {}
            self.last_target=now
            if target['id']=='entrance' and target['width']>330:self.near_entrance=True
            if (target.get('close_entry') and target['width']>=135
                    and abs(target['aim'][0]-960)<=60 and self.hits.get('entrance',0)>=3):
                self.near_entrance=True
                self.transition('enter_theater',now)
                self.message='Close entrance confirmed; walking inside'
                return dict(STICK_1_X=0,STICK_2_X=0,STICK_2_Y=-100)
            self.message='Following Theater entrance' if target['id']=='entrance' else 'Following Theater sign'
            return self.steer(target,now)
        if self.state=='search_queue':
            self.message='Looking for the entrance-facing lobby layout; weekly signs ignored'
            if self.lock_entrance_door(matches,now):return self.align_output(now)
            if matches.get('lobby'):
                self.message='Entrance layout found; holding camera to confirm the court slot'
                return {}
            if now-self.stage_started>35:
                self.stop('Entrance layout not confirmed; no court doorway selected. Restart from the Theater entrance.')
                return {}
            return self.search(now)
        return {}
