"""Track the opening's frame instead of the visible fraction of its floor glow."""
import cv2
import numpy as np

class ThresholdDetector:
    def __init__(self):
        self.checked=-10.
        self.match=None
        self.hits=0
        self.frame_acquired=False
        self.anchor=None
        self.anchor_at=-10.
        self.locked=False
        self.openings=[]

    def observe(self,frame,now,hint_x=None,discover=False):
        if now-self.checked<.15:return
        self.checked=now
        im=cv2.resize(frame[:,:,:3],(960,540),interpolation=cv2.INTER_AREA)
        gray=cv2.cvtColor(im,cv2.COLOR_BGR2GRAY)
        hsv=cv2.cvtColor(im,cv2.COLOR_BGR2HSV)
        glow=cv2.inRange(hsv,np.array([40,30,130]),np.array([105,255,255]))
        glow[:190 if discover else 280]=0;glow[520:]=0
        glow[:,:20 if discover else 200]=0;glow[:,940 if discover else 850:]=0
        if discover:
            glow=cv2.dilate(glow,np.ones((2,2),np.uint8))
        contours,_=cv2.findContours(glow,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
        strips=[]
        for contour in contours:
            if cv2.contourArea(contour)<(12 if discover else 35):continue
            x,y,w,h=cv2.boundingRect(contour)
            rect=cv2.minAreaRect(contour)
            length,thickness=sorted(rect[1],reverse=True)
            if w<30 or length<35 or length>400 or thickness<1 or length/thickness<3.5 or w<h*.85:continue
            strips.append((rect[0][0],rect[0][1],length,rect))

        previous=self.match
        wanted=(hint_x/2 if hint_x is not None else previous['aim'][0]/2 if previous else 480)
        edges=cv2.Canny(gray,50,120)
        left_bound=20 if discover or self.locked else 210
        right_bound=939 if discover or self.locked else 849
        edges[:40 if self.locked else 140]=0;edges[430 if self.locked else 390:]=0
        edges[:,:left_bound]=0;edges[:,right_bound+1:]=0
        lines=cv2.HoughLinesP(edges,1,np.pi/180,20,minLineLength=25,maxLineGap=12)
        lines=list(lines.reshape(-1,4)) if lines is not None else []
        if self.locked and self.anchor is not None:
            # A short/angled lintel may disappear from Hough output mid-turn.
            # Reacquire dark-opening boundaries only around the existing lock.
            old_y=round(self.anchor['polygon'][0][1]/2)
            old_x=self.anchor['aim'][0]/2
            for yy in range(max(46,old_y-28),min(409,old_y+29),2):
                dark=np.mean(gray[yy+12:yy+45,:]<65,axis=0)>.75
                changes=np.diff(np.r_[False,dark,False].astype(np.int8))
                for left,right in zip(np.flatnonzero(changes==1),np.flatnonzero(changes==-1)):
                    if 28<=right-left<=380 and abs((left+right)/2-old_x)<60:
                        lines.append((left,yy,right-1,yy))
        candidates=[]
        for line in lines:
            x1,y1,x2,y2=map(int,line)
            if x2<x1:x1,y1,x2,y2=x2,y2,x1,y1
            span=x2-x1
            if not 25<span<420 or abs(y2-y1)>span*.15:continue
            y=round((y1+y2)/2);center=round((x1+x2)/2)
            if not (45 if self.locked else 145)<y<(410 if self.locked else 370):continue
            # Extend a partial top edge across the actual dark opening.
            # A player's head/body lower down must not shift its midpoint.
            band=gray[y+12:y+45,:]
            dark=np.mean(band<65,axis=0)>.75
            if not dark[center]:continue
            left=right=center
            while left>left_bound and dark[left-1]:left-=1
            while right<right_bound and dark[right+1]:right+=1
            width=right-left
            if not (28 if discover or self.locked else 45)<=width<=380:continue
            # Keep the same opening while turning. Nearby avatars can expose
            # dark rectangles, but cannot suddenly double the door's width or
            # move its lintel far down the screen between adjacent frames.
            if not discover and self.anchor is not None and (self.locked or now-self.anchor_at<1.2):
                old_width=self.anchor['width']/2
                old_y=self.anchor['polygon'][0][1]/2
                if not .55*old_width<=width<=1.8*old_width or abs(y-old_y)>55:
                    continue
                if self.locked and abs((left+right)/2-self.anchor['aim'][0]/2)>max(60,old_width*.65):
                    continue
            cx=(left+right)/2
            if not discover and abs(cx-wanted)>260:continue
            margin=max(8,round(width*.1))
            above=gray[y-25:y-8,left+margin:right-margin]
            below=gray[y+12:y+60,left+margin:right-margin]
            if not above.size or not below.size:continue
            darkness=float(np.mean(below<65))
            interior=float(np.mean(below))
            if darkness<.75 or float(np.mean(above))-interior<35:continue
            sides=[float(np.mean(gray[y+12:y+60,max(0,left-10):max(1,left-3)])),
                   float(np.mean(gray[y+12:y+60,min(959,right+3):min(960,right+10)]))]
            if max(sides)<50 or sum(sides)/2-interior<22:continue
            nearby=[s for s in strips if left-15<=s[0]<=right+15 and s[1]>y+width*.6]
            # Distant doors are narrower than 75 pixels. Require their green
            # threshold too, so a player's dark shirt/head is not a doorway.
            tracked = self.anchor is not None and now-self.anchor_at<1.2
            if discover and not nearby:continue
            if width<100 and not nearby and not tracked:continue
            bottom=max((s[1] for s in nearby),default=min(515,y+width*1.3))
            score=width*darkness-abs(cx-wanted)*.25+(25 if nearby else 0)
            candidates.append((score,cx,y,left,right,bottom,width))

        self.openings=[]
        for _,cx,y,left,right,bottom,width in candidates:
            if any(abs(cx*2-m['aim'][0])<30 for m in self.openings):continue
            self.openings.append(dict(id='queue_threshold',name='Entrance-relative court doorway',kind='door_frame',
                aim=[cx*2,min(1030,bottom*2)],polygon=[[left*2,y*2],[right*2,y*2],
                [right*2,bottom*2],[left*2,bottom*2]],width=width*2,observed_at=now))
        self.match=None
        if candidates:
            self.frame_acquired=True
            if self.locked:
                chosen=min(candidates,key=lambda value:abs(value[1]-wanted))
            else:
                chosen=max(candidates,key=lambda value:value[0])
            _,cx,y,left,right,bottom,width=chosen
            self.match=dict(id='queue_threshold',name='Locked entrance-right court opening',kind='door_frame',
                aim=[cx*2,min(1030,bottom*2)],polygon=[[left*2,y*2],[right*2,y*2],
                [right*2,bottom*2],[left*2,bottom*2]],width=width*2,observed_at=now)
        # A complete visible strip remains a fallback for unusual lighting.
        # After tracking a frame, avoid switching to an occluded strip whose
        # midpoint can be biased toward either door jamb.
        elif not self.frame_acquired:
            full=[s for s in strips if s[2]>=100 and abs(s[0]-wanted)<140]
            if full:
                cx,cy,length,rect=max(full,key=lambda s:s[2])
                x1=max(0,round(cx-length*.4));x2=min(960,round(cx+length*.4))
                y1=max(0,round(cy-length*1.6));y2=max(y1+1,round(cy-length*.3))
                above=gray[y1:y2,x1:x2]
                if above.size and float(np.mean(above<65))>=.5:
                    self.match=dict(id='queue_threshold',name='Locked court threshold',kind='floor_strip',
                        aim=[cx*2,cy*2],polygon=(cv2.boxPoints(rect)*2).tolist(),width=length*2,observed_at=now)
        if self.match is None:self.hits=0
        elif previous and abs(previous['aim'][0]-self.match['aim'][0])<180:self.hits+=1
        else:self.hits=1
        if self.match is not None and self.match.get('kind')=='door_frame':
            self.anchor=self.match
            self.anchor_at=now
