from helios import overlay
from .detection_nav import Navigator

class Walker:
    def __init__(self, root):
        self.nav = Navigator(root)
        self.commanded = {}
        self.message = ''
        self.draw_fault = None
        self.settings = dict(show_status=False, show_detections=True, show_guides=True)

    def draw_guide(self,now):
        guide=self.nav.guide
        if not self.settings['show_guides'] or not self.nav.active or guide is None:
            return
        if now-guide['observed_at']>.4:return
        sx,sy=guide['origin']
        tx,ty=guide['target']
        tx=round(max(32,min(1888,tx)))
        ty=round(max(110,min(930,ty)))
        color=(50,240,120) if guide['moving'] else (255,205,65)
        def line(x1,y1,x2,y2,width=2,c=color):
            overlay.line(round(x1),round(y1),round(x2),round(y2),color=c,thickness=width,
                space=overlay.DESIGN_1080P,target=overlay.FRAME)
        # Forward reference and a corridor converging on the current target.
        line(sx,sy,sx,330,1,(100,130,150))
        line(sx-34,sy,tx-14,ty,2)
        line(sx+34,sy,tx+14,ty,2)
        line(sx,sy,tx,ty,4)
        line(tx-13,ty,tx+13,ty,3)
        line(tx,ty-13,tx,ty+13,3)
        correction=self.commanded.get('STICK_2_X',0)
        direction='RIGHT' if correction>0 else 'LEFT' if correction<0 else 'CENTER'
        overlay.text('GUIDE: '+guide['name']+' | '+direction,sx-280,sy+40,color=color,scale=2,
            space=overlay.DESIGN_1080P,target=overlay.FRAME)

    def draw(self, now):
        if self.draw_fault:
            return
        try:
            if self.settings['show_status']:
                overlay.text('THEATER TEST 3.5 | ' + self.message, 16, 28,
                    color=(255,255,255), scale=2, space=overlay.DESIGN_1080P, target=overlay.FRAME)
                overlay.text('Left stick up: %d%% | RT/R2: 0 | L3 + Down stops' %
                    abs(self.commanded.get('STICK_2_Y',0)), 16, 55, color=(70,230,100),
                    scale=2, space=overlay.DESIGN_1080P, target=overlay.FRAME)
            self.draw_guide(now)
            if not self.settings['show_detections'] or now-self.nav.detector.checked>.4:
                return
            for match in self.nav.detector.matches.values():
                polygon = match['polygon']
                for i in range(4):
                    x1,y1=polygon[i]; x2,y2=polygon[(i+1)%4]
                    overlay.line(round(x1),round(y1),round(x2),round(y2),color=(0,240,130),
                        thickness=2,space=overlay.DESIGN_1080P,target=overlay.FRAME)
                overlay.text(match['name'],round(polygon[0][0]),max(85,round(polygon[0][1])-20),
                    color=(0,240,130),scale=2,space=overlay.DESIGN_1080P,target=overlay.FRAME)
        except Exception as exc:
            self.draw_fault = 'Video overlay disabled: ' + str(exc)[:110]

