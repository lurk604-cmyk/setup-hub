"""Experimental landmark steering, isolated from the Plate Drop script."""
import json
import math
from pathlib import Path
import cv2
import numpy as np

ORDER=('theater','entrance','lobby')


class Detector:
    def __init__(self, root):
        self.root=Path(root)/'points'
        self.orb=cv2.ORB_create(nfeatures=1200,scaleFactor=1.2,nlevels=10,edgeThreshold=10,fastThreshold=8)
        self.matcher=cv2.BFMatcher(cv2.NORM_HAMMING)
        self.references=[]
        self.checked=-10.
        self.matches={}
        self.sequence=0
        self.layouts=[]
        self.mode="auto"
        self.elapsed_ms=0.

    def load(self):
        if self.references:return
        raw=json.loads((self.root/'points.json').read_text(encoding='utf-8'))
        for spec in raw['references']:
            path=(self.root/spec['file']).resolve()
            if path.parent!=self.root.resolve() or spec['id'] not in ORDER:
                raise ValueError('Invalid detection point reference')
            image=cv2.imread(str(path),cv2.IMREAD_GRAYSCALE)
            if image is None:raise ValueError('Missing point image: '+spec['file'])
            if spec['id']=='lobby':
                for scale in (.85,1.,1.15):
                    ref=cv2.resize(image,None,fx=scale*.5,fy=scale*.5)
                    self.layouts.append((ref,scale,spec))
                continue
            keys,descriptors=self.orb.detectAndCompute(image,None)
            if descriptors is None or len(keys)<12:raise ValueError('Point image has too few features')
            self.references.append((spec,image.shape,keys,descriptors))

    def observe(self, frame, now):
        if now-self.checked<.25:return self.matches
        self.checked=now
        self.sequence+=1
        self.load()
        found={}
        best=None
        if self.mode in ('auto','inside'):
            gray=cv2.cvtColor(cv2.resize(frame[:,:,:3],(480,270)),cv2.COLOR_BGR2GRAY)
            for ref,scale,spec in self.layouts:
                if ref.shape[0]>140:continue
                _,score,_,location=cv2.minMaxLoc(cv2.matchTemplate(gray[:140],ref,cv2.TM_CCOEFF_NORMED))
                if score>=.82 and (best is None or score>best[0]):best=(score,location,ref.shape,scale,spec)
            if best:
                score,(x,y),(h,w),scale,spec=best
                door=spec.get('door_box')
                hint=None
                if door:
                    x1,y1,x2,y2=[float(v)*scale*.5 for v in door]
                    polygon=[[(x+x1)*4,(y+y1)*4],[(x+x2)*4,(y+y1)*4],
                             [(x+x2)*4,(y+y2)*4],[(x+x1)*4,(y+y2)*4]]
                    hint=dict(id='queue_threshold',name='Entrance-right physical court slot',kind='layout_slot',
                              polygon=polygon,aim=[(x+(x1+x2)/2)*4,(y+y2)*4],width=(x2-x1)*4,observed_at=now)
                found['lobby']=dict(id='lobby',name='Fixed entrance-facing center wall',
                    polygon=[[x*4,y*4],[(x+w)*4,y*4],[(x+w)*4,(y+h)*4],[x*4,(y+h)*4]],
                    aim=[(x+w/2)*4,(y+h/2)*4],width=w*4,confidence=score,inliers=0,observed_at=now,door_hint=hint)
        if self.mode=='inside':
            self.matches=found
            return found
        small=cv2.resize(frame[:,:,:3],(960,540),interpolation=cv2.INTER_AREA)
        gray=cv2.cvtColor(small,cv2.COLOR_BGR2GRAY)
        keys,descriptors=self.orb.detectAndCompute(gray,None)
        if descriptors is None:
            self.matches=found
            return self.matches
        for spec,(height,width),rk,rd in self.references:
            pairs=self.matcher.knnMatch(rd,descriptors,k=2)
            good=[p[0] for p in pairs if len(p)==2 and p[0].distance<.72*p[1].distance]
            if len(good)<10:continue
            source=np.float32([rk[m.queryIdx].pt for m in good]).reshape(-1,1,2)
            target=np.float32([keys[m.trainIdx].pt for m in good]).reshape(-1,1,2)
            if np.ptp(source[:,0,0])<width*.3 or np.ptp(source[:,0,1])<height*.3:continue
            if spec.get('close_entry'):
                affine,mask=cv2.estimateAffinePartial2D(source,target,method=cv2.RANSAC,ransacReprojThreshold=3)
                matrix=None if affine is None else np.vstack((affine,[0,0,1]))
            else:
                matrix,mask=cv2.findHomography(source,target,cv2.RANSAC,4)
            if matrix is None or mask is None:continue
            inliers=int(mask.sum())
            if inliers<10 or inliers/len(good)<.55:continue
            points=np.float32([[0,0],[width,0],[width,height],[0,height],
                [spec['aim'][0]*width,spec['aim'][1]*height]]).reshape(-1,1,2)
            projected=cv2.perspectiveTransform(points,matrix).reshape(-1,2)*2
            polygon=projected[:4]
            if not np.isfinite(projected).all() or not cv2.isContourConvex(polygon.astype('float32')):continue
            area=abs(float(cv2.contourArea(polygon)))
            if not 1500<=area<=1920*1080*.9:continue
            if polygon[:,0].min() < -960 or polygon[:,0].max()>2880:continue
            if polygon[:,1].min() < -540 or polygon[:,1].max()>1620:continue
            observed_width=float((np.linalg.norm(polygon[1]-polygon[0])+np.linalg.norm(polygon[2]-polygon[3]))/2)
            fraction=.5
            anchor=polygon[3]*(1-fraction)+polygon[2]*fraction
            landmark_height=float((np.linalg.norm(polygon[3]-polygon[0])+np.linalg.norm(polygon[2]-polygon[1]))/2)
            aim=(projected[4] if spec.get('aim_mode')=='projected' else
                 np.float32([anchor[0],min(930,max(240,anchor[1]+landmark_height*.75))]))
            if not -960<=aim[0]<=2880 or not -540<=aim[1]<=2700:continue
            match=dict(id=spec['id'],name=spec['name'],polygon=polygon.tolist(),
                aim=aim.tolist(),width=observed_width,inliers=inliers,
                confidence=round(inliers/len(good),3),observed_at=now,close_entry=spec.get('close_entry',False))
            previous=found.get(spec['id'])
            if previous is None or inliers>previous['inliers']:found[spec['id']]=match
        self.matches=found
        return found
