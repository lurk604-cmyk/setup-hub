"""Hands-free court bootstrap from fresh score changes and a running shot clock.

This supplies a delayed cue after a basket, not a possession flag at 0-0.
"""


class ScoreStart:
    def __init__(self):
        self.readings = {}
        self.scores = None
        self.pending = None
        self.new_game = False
        self.message = 'Waiting for a confirmed basket to learn this court automatically'

    def stable(self, key, sample, now, maximum):
        if sample is None:
            return None
        sequence, value, age = sample
        if age > .65 or type(value) is not int or not 0 <= value <= maximum:
            return None
        previous = self.readings.get(key)
        if previous is None or previous[0] != sequence:
            count = previous[2]+1 if previous and previous[1] == value and now-previous[3] < .8 else 1
            self.readings[key] = (sequence, value, count, now)
        current = self.readings[key]
        return value if current[2] >= 2 and now-current[3] < .8 else None

    def update(self, obs, now, side):
        self.new_game = False
        if not obs.get('video') or not obs.get('hud') or obs.get('pause') or obs.get('sliders'):
            return None
        left = self.stable('left', obs.get('score_left'), now, 999)
        right = self.stable('right', obs.get('score_right'), now, 999)
        clock = self.stable('clock', obs.get('shot_clock'), now, 24)
        scores = None if left is None or right is None else (left,right)
        if scores is not None:
            if self.scores is None:
                self.scores = scores
                self.new_game = scores == (0,0)
            elif scores != self.scores:
                before = self.scores
                self.scores = scores
                self.pending = None
                if scores == (0,0) and before != (0,0):
                    self.new_game = True
                    self.message = 'New game; waiting for a basket or a known defensive view'
                else:
                    delta = (scores[0]-before[0],scores[1]-before[1])
                    if delta in ((2,0),(3,0),(0,2),(0,3)):
                        scoring_side = 'Away' if delta[0] else 'Home'
                        self.pending = dict(phase='defense' if scoring_side == side else 'offense',
                                            at=now, start=None, last=None, drops=0)
                        self.message = 'Basket confirmed; waiting for the new possession clock'
                    else:
                        self.message = 'Score change ambiguous or free throw; waiting for another clear cue'
        pending = self.pending
        if pending is None:
            return None
        if now-pending['at'] > 15:
            self.pending = None
            self.message = 'Possession cue expired; waiting for a known view or another basket'
            return None
        if clock is None or now-pending['at'] < .6:
            return None
        if pending['start'] is None:
            if clock >= 23:
                pending['start'] = pending['last'] = clock
            return None
        if clock > pending['last']:
            self.pending = None
            self.message = 'Shot clock reset again; possession ambiguous'
            return None
        if clock < pending['last']:
            drop = pending['last']-clock
            if drop > 3:
                self.pending = None
                return None
            pending['drops'] += drop
            pending['last'] = clock
        if pending['drops'] >= 2 and clock <= 22 and obs.get('period') in (1,2,3,4):
            phase = pending['phase']
            self.pending = None
            self.message = 'New '+phase+' possession confirmed after the basket'
            return phase
        return None
