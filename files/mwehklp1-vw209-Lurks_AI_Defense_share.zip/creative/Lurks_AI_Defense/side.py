"""Lightweight offense/defense detector (3.6).

The gameplay camera turns to face the basket the offense is attacking, so the
court flips end-for-end on every change of possession. The scorer's table,
benches and LED boards are on one sideline only, so when the camera flips the
left and right edges of the picture swap what they show. Colour histograms
of the outer left and right fifths of the arena band are compared with a
reference: same order => same end, swapped order => other end.

Calibration: when you press L3+R3 to start or resume Smother you are telling
the script "I am on defense now". The current view is stored as the defense
end. From then on

    score = (L.Ld + R.Rd - L.Rd - R.Ld) / self-score   (+1 same end, -1 other)

positive => defense, negative => offense. Pressing L3+R3 again always
re-calibrates, which also fixes the halftime basket switch.

Cost: one 192x108 resize, two small histograms and a scorebug template
match every 0.1 s (about 1-2 ms).
No OCR, no ORB, no file access.
"""
from pathlib import Path

# Tuning. Scores are normalised: about +1 at the calibrated end, -1 at the other.
# Measured on the supplied clip: defense +0.4..+1.0, offense -0.5..-1.0 after
# the camera turn. A large dark panel over the left of the screen (like the
# LB defensive menu) moved defense frames to as low as -0.43 in simulation,
# so while our own menu is open only a much stronger reading may switch.
SCAN_INTERVAL = 0.10      # seconds between frames that are analysed
SIDE_WIDTH = 38           # of 192 columns: the outer fifth on each side
THRESHOLD = 0.10          # |score| needed to count a frame as evidence
STRONG_THRESHOLD = 0.60   # evidence needed while our own LB menu is open
CONFIRM_SECONDS = 0.30    # evidence must persist this long before switching
STRONG_CONFIRM = 0.20
LEARN_THRESHOLD = 0.30    # confident frames slowly refine the reference
LEARN_RATE = 0.05
HUD_THRESHOLD = 0.80
# Camera-turn safety stop. On a change of possession the camera swings round;
# the right side of the picture (never covered by the LB menu) changes far more
# than during normal play. Clip: 36-54 during the turn, 5-19 otherwise.
TURN_DIFF = 30.0
TURN_FRAMES = 2           # consecutive analysed frames above TURN_DIFF
TURN_HOLD = 0.60          # seconds a detected turn keeps inputs stopped
# Automatic calibration from the score (3.8). When a team scores, the view
# shortly BEFORE the score changed shows the end that team was attacking.
# Opponent scored -> that end is your defense end; you scored -> offense end.
# The result is then checked against the next possession: the team that was
# scored on gets the ball, so the camera must show the other end.
SCORE_BOXES = {'Away': (790, 978, 880, 1022), 'Home': (1040, 978, 1130, 1022)}
SCORE_CHANGE = 14.0       # mean grey-level change that counts as a new score
SCORE_STABLE = 0.80       # the new digits must stay this long (not an animation)
SAMPLE_BEFORE = 0.60      # use a view at least this long before the change
SAMPLE_WINDOW = 4.0       # ...but not older than this
VALIDATE_WITHIN = 12.0    # the next possession must confirm within this time
VALIDATE_HOLD = 1.0


class SideTracker:
    def __init__(self, root):
        self.root = Path(root)
        self.reference = None
        self.state = 'unknown'      # 'defense' | 'offense' | 'unknown'
        self.view = False           # a gameplay court view is on screen now
        self.score = 0.0
        self.candidate = None
        self.candidate_since = 0.0
        self.checked = -10.0
        self.latest = None          # (time, feature) of the last gameplay view
        self.calibrate_wanted = False
        self.calibrated_at = None
        self.state_since = 0.0
        self.strict = False         # set by the caller while its menu is open
        self.previous_right = None
        self.turn_frames = 0
        self.turn_at = -10.0
        self.error = ''
        self.own_side = 'Away'
        self.validated = False      # safe to start inputs on our own
        self.source = None          # 'button' | 'score'
        self.history = []           # (time, feature, turning) of recent views
        self.score_ref = {}
        self.score_pending = {}
        self.change_start = {}
        self.expect = None          # (state, deadline) after a score calibration
        self.expect_since = None
        self.agree = self.disagree = 0
        self.misses = 0             # LB menu misses on views that read as defense
        self.menu_confirmed = False # an opened LB panel agreed with these ends
        self.miss_at = -100.0
        self.events = []
        self.last_view = -10.0
        self.last_score_event = {}
        self._hud = None
        self._cv2 = self._np = None

    # ------------------------------------------------------------------ util
    def _load(self):
        if self._cv2 is None:
            import cv2
            import numpy as np
            self._cv2, self._np = cv2, np
            hud = cv2.imread(str(self.root/'hud.png'), cv2.IMREAD_GRAYSCALE)
            self._hud = hud
        return self._cv2, self._np

    def _gameplay(self, frame):
        cv2, np = self._load()
        if self._hud is None:
            return True
        # Same region as vision.py: the scorebug at the bottom centre.
        # vision.py matches hud.png on a 960x540 frame inside (300,420)-(660,540).
        h, w = frame.shape[:2]
        crop = frame[h*420//540:h, w*300//960:w*660//960, :3]
        small = cv2.resize(crop, (360, 120), interpolation=cv2.INTER_AREA)
        gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
        if gray.shape[0] < self._hud.shape[0] or gray.shape[1] < self._hud.shape[1]:
            return False
        score = cv2.minMaxLoc(cv2.matchTemplate(gray, self._hud, cv2.TM_CCOEFF_NORMED))[1]
        return score >= HUD_THRESHOLD

    def feature(self, frame):
        """Colour histograms of the left and right thirds of the arena band."""
        cv2, np = self._load()
        thumb = cv2.resize(frame[:, :, :3], (192, 108), interpolation=cv2.INTER_AREA)
        hsv = cv2.cvtColor(thumb, cv2.COLOR_BGR2HSV)
        band = hsv[30:78]
        if float(band[:, :, 2].mean()) < 25:       # fade to black / loading
            return None
        sides = []
        for part in (band[:, :SIDE_WIDTH], band[:, 192-SIDE_WIDTH:]):
            hist = cv2.calcHist([part], [0, 1, 2], None, [12, 4, 4],
                                [0, 180, 0, 256, 0, 256]).ravel()
            sides.append(np.sqrt(hist/max(float(hist.sum()), 1.0)))
        return sides

    @staticmethod
    def _raw(current, reference):
        left, right = current
        ref_left, ref_right = reference
        return float(left@ref_left+right@ref_right-left@ref_right-right@ref_left)

    def compare(self, current):
        """+1 = same end as the calibrated defense view, -1 = the other end."""
        full = self._raw(self.reference, self.reference)
        if full < 1e-3:
            return 0.0
        return self._raw(current, self.reference)/full

    # ------------------------------------------------------------- interface
    @property
    def calibrated(self):
        return self.reference is not None

    def request_calibration(self, now):
        """The user has just said "I am defending". Use the freshest view."""
        if self.latest is not None and now-self.latest[0] < .35:
            self._set_reference(self.latest[1], now)
        else:
            self.calibrate_wanted = True

    def _set_reference(self, vector, now, source='button'):
        self.reference = [vector[0].copy(), vector[1].copy()]
        self.calibrate_wanted = False
        self.calibrated_at = now
        self.source = source
        self.candidate = None
        self.expect = None
        self.agree = self.disagree = 0
        self.menu_confirmed = False
        if source == 'button':
            self.validated = True
            self.state = 'defense'
            self.state_since = now
            self.score = 1.0
        else:
            self.validated = False
            self.state = 'unknown'

    # ------------------------------------------------------------ score cue
    def _log(self, text, now):
        import time
        self.events = (self.events+['%s %s' % (time.strftime('%H:%M:%S'), text)])[-6:]

    def _score_watch(self, frame, now):
        cv2, np = self._cv2, self._np
        h, w = frame.shape[:2]
        # After any gap in normal gameplay (replay, timeout, intro graphic)
        # start from the digits now on screen instead of comparing across it.
        if now-self.last_view > 2.0:
            self.score_ref = {}
            self.score_pending = {}
            self.change_start = {}
        self.last_view = now
        for side, (x1, y1, x2, y2) in SCORE_BOXES.items():
            crop = frame[y1*h//1080:y2*h//1080, x1*w//1920:x2*w//1920, :3]
            digits = cv2.resize(cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY), (45, 22),
                                interpolation=cv2.INTER_AREA).astype(np.float32)
            stable = self.score_ref.get(side)
            if stable is None:
                self.score_ref[side] = digits
                continue
            change = float(np.abs(digits-stable).mean())
            if change < SCORE_CHANGE*.5:
                self.score_pending[side] = None
                self.change_start.pop(side, None)
                continue
            if change < SCORE_CHANGE:
                continue
            self.change_start.setdefault(side, now)
            pending = self.score_pending.get(side)
            if pending is None or float(np.abs(digits-pending[0]).mean()) > SCORE_CHANGE*.5:
                self.score_pending[side] = [digits, now]
            elif now-pending[1] >= SCORE_STABLE:
                self.score_ref[side] = digits
                self.score_pending[side] = None
                started = self.change_start.pop(side)
                other = 'Home' if side == 'Away' else 'Away'
                if other in self.change_start or now-self.last_score_event.get(other, -10) < 1.5:
                    # Both scores changed together: the scorebug was redrawn
                    # (Nov 4 game: "Away scored" and "Home scored" 0.1 s apart).
                    self._log('scorebug redraw ignored', now)
                    self.last_score_event[side] = now
                    continue
                self.last_score_event[side] = now
                self._score_event(side, started, now)

    def _score_event(self, side, changed_at, now):
        mine = side == self.own_side
        samples = [(t, v) for t, v, turning in self.history
                   if changed_at-SAMPLE_WINDOW <= t <= changed_at-SAMPLE_BEFORE and not turning]
        if not samples:
            self._log('%s scored; no clear view before it' % side, now)
            return
        t, view = samples[-1]
        # Express it as the DEFENSE view: an offense view is the mirror image.
        defense_view = view if not mine else (view[1], view[0])
        who = 'you' if mine else 'opponent'
        if self.reference is None or not self.validated:
            self._set_reference(defense_view, now, source='score')
            # The team that was scored on gets the ball next.
            self.expect = ('offense' if not mine else 'defense', now+VALIDATE_WITHIN)
            self.expect_since = None
            self._log('%s scored -> ends learned, checking next possession' % who, now)
            return
        agreement = self.compare(defense_view)
        if agreement > THRESHOLD:
            self.agree += 1
            self.disagree = 0
            self._log('%s scored -> agrees (%.2f)' % (who, agreement), now)
        elif agreement < -THRESHOLD:
            self.disagree += 1
            self._log('%s scored -> DISAGREES (%.2f)' % (who, agreement), now)
            # Two in a row (e.g. teams switched baskets at halftime): re-learn.
            if self.disagree >= 2:
                self._set_reference(defense_view, now, source='score')
                self.expect = ('offense' if not mine else 'defense', now+VALIDATE_WITHIN)
                self.expect_since = None
                self._log('re-learned ends from the score', now)

    def label(self, at, phase, now, why):
        """The game itself told us the phase at time `at` (LB menu opened ->
        defense; LB + player opened nothing -> offense). Use the view from
        just before the LB press (the menu panel covers part of the band)."""
        samples = [(t, v) for t, v, turning in self.history if t <= at and not turning and at-t <= 2.0]
        if phase == 'defense':
            self.misses = 0
        if not samples:
            return 'none'
        t, view = samples[-1]
        defense_view = view if phase == 'defense' else (view[1], view[0])
        if self.reference is None or not self.validated:
            self._set_reference(defense_view, now, source='menu')
            self.validated = True
            self.menu_confirmed = phase == 'defense'
            self.state, self.state_since = phase, now
            self._log('%s -> ends learned (%s)' % (why, phase), now)
            return 'learned'
        agreement = self.compare(defense_view)
        if phase == 'offense' and agreement < THRESHOLD and self.menu_confirmed:
            # 4.0.4: the LB panel already opened on these ends this game, which
            # is proof. A menu that fails to open later (inbound, dead ball,
            # your own buttons) never flips them again (Nov 6: two misses on
            # clear defense views flipped correct ends, then it pressed on
            # every offense).
            self.misses = self.misses+1 if now-self.miss_at < 30 else 1
            self.miss_at = now
            self._log('%s; ends already confirmed by the menu, kept (%.2f)' % (why, agreement), now)
            return 'kept'
        if phase == 'offense' and agreement < THRESHOLD:
            # 4.0.2: one miss on a view that reads as (or might be) your defense
            # end is usually a steal/rebound (camera has not turned yet) or a
            # dead ball, not wrong ends. Flipping the ends on it made the next
            # real defense read as offense, so Smother never continued.
            # Only a second miss within 30 s corrects the ends.
            self.misses = self.misses+1 if now-self.miss_at < 30 else 1
            self.miss_at = now
            if self.misses < 2:
                self._log('%s on a defense view -> change of possession or dead ball; ends kept (%.2f)'
                          % (why, agreement), now)
                return 'kept'
            self.misses = 0
        if agreement < THRESHOLD:
            # The game disagrees with the court reading (or it was unsure):
            # the game wins. This is what went wrong in the Nov 4 Heat game.
            self._set_reference(defense_view, now, source='menu')
            self.validated = True
            self.state, self.state_since = phase, now
            self.candidate = None
            self.menu_confirmed = phase == 'defense'
            self._log('%s -> corrected ends (%s, was %.2f)' % (why, phase, agreement), now)
            return 'corrected'
        mix = .25
        self.reference = [(1-mix)*self.reference[0]+mix*defense_view[0],
                          (1-mix)*self.reference[1]+mix*defense_view[1]]
        if phase == 'defense':
            self.menu_confirmed = True
        if phase != self.state:
            self.state, self.state_since = phase, now
        return 'agreed'

    def _check_expectation(self, now):
        if self.expect is None:
            return
        wanted, deadline = self.expect
        if self.state == wanted:
            if self.expect_since is None:
                self.expect_since = now
            if now-self.expect_since >= VALIDATE_HOLD:
                self.validated = True
                self.expect = None
                self._log('next possession confirmed the ends', now)
            return
        self.expect_since = None
        # After a basket the camera stays at that end for the inbound, then
        # turns; so only "never saw the expected end in time" counts as a fail.
        if now > deadline:
            # e.g. a first free throw (no change of possession) or a bad view
            self.reference = None
            self.validated = False
            self.expect = None
            self.state = 'unknown'
            self._log('next possession did not confirm; waiting for another basket', now)

    def defense_for(self, now):
        return now-self.state_since if self.state == 'defense' else 0.0

    def turning(self, now):
        """True briefly after the camera swings round (likely possession change)."""
        return now-self.turn_at < TURN_HOLD

    def _turn_check(self, frame, now):
        cv2, np = self._cv2, self._np
        small = cv2.resize(frame[:, :, :3], (96, 54), interpolation=cv2.INTER_AREA)
        right = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)[8:44, 58:].astype(np.float32)
        if self.previous_right is not None:
            change = float(np.abs(right-self.previous_right).mean())
            self.turn_frames = self.turn_frames+1 if change > TURN_DIFF else 0
            if self.turn_frames >= TURN_FRAMES:
                self.turn_at = now
        self.previous_right = right

    def scan(self, frame, now):
        if frame is None or not hasattr(frame, 'shape'):
            self.view = False
            return self.state
        if now-self.checked < SCAN_INTERVAL:
            return self.state
        self.checked = now
        try:
            if not self._gameplay(frame):
                self.view = False
                self.candidate = None
                self.previous_right = None
                self.turn_frames = 0
                return self.state
            self._turn_check(frame, now)
            vector = self.feature(frame)
        except Exception as exc:  # never let vision break controller output
            self.error = str(exc)[:120]
            self.view = False
            return self.state
        if vector is None:
            self.view = False
            return self.state
        self.view = True
        self.latest = (now, vector)
        turning = self.turning(now)
        self.history = [entry for entry in self.history if now-entry[0] <= SAMPLE_WINDOW+1]
        self.history.append((now, vector, turning))
        try:
            self._score_watch(frame, now)
        except Exception as exc:
            self.error = 'score: '+str(exc)[:100]
        if self.calibrate_wanted:
            self._set_reference(vector, now)
            return self.state
        if self.reference is None:
            return self.state
        score = self.compare(vector)
        self.score = score
        limit = STRONG_THRESHOLD if self.strict else THRESHOLD
        hold = STRONG_CONFIRM if self.strict else CONFIRM_SECONDS
        verdict = 'defense' if score > limit else ('offense' if score < -limit else None)
        if verdict is None or verdict == self.state:
            self.candidate = None
        elif verdict != self.candidate:
            self.candidate, self.candidate_since = verdict, now
        elif now-self.candidate_since >= hold:
            self.state, self.state_since, self.candidate = verdict, now, None
        if self.state == 'unknown' and verdict and not self.strict:
            self.state, self.state_since = verdict, now
        self._check_expectation(now)
        if self.reference is None:
            return self.state
        # Adapt slowly to camera zoom/pan, only from confident agreeing frames.
        if (abs(score) >= LEARN_THRESHOLD and verdict == self.state and not self.strict
                and self.validated):
            # On offense the camera looks at the other end: its left side is
            # the defense view's right side.
            left, right = vector if verdict == 'defense' else (vector[1], vector[0])
            self.reference = [(1-LEARN_RATE)*self.reference[0]+LEARN_RATE*left,
                              (1-LEARN_RATE)*self.reference[1]+LEARN_RATE*right]
        return self.state

    def summary(self):
        return dict(state=self.state, calibrated=self.calibrated, validated=self.validated,
                    learned_from=self.source, your_side=self.own_side, view=self.view,
                    score=round(self.score, 3), strict=self.strict,
                    camera_turn=self.turn_frames > 0, events=self.events, error=self.error)
