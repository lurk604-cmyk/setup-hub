"""Discord OAuth public-client PKCE. No hardware IDs or application secrets."""
import base64
import ctypes
from ctypes import wintypes
import hashlib
from http.server import HTTPServer, BaseHTTPRequestHandler
import json
from pathlib import Path
import re
import secrets
import socket
import time
import urllib.error
import urllib.parse
import urllib.request
import webbrowser

REDIRECT = 'http://127.0.0.1:47683/callback'
API = 'https://discord.com/api/v10'


class SignInRequired(Exception):
    pass


def normalise_discord_id(value):
    value = str(value).strip()
    match = re.fullmatch(r'<@!?(\d{17,20})>', value)
    if match:
        value = match.group(1)
    return value if re.fullmatch(r'[1-9]\d{16,19}', value) and int(value) < 2**64 else None


def fingerprint(ident):
    return hashlib.sha256(('LAD-discord-v1|' + ident).encode()).hexdigest()


class Blob(ctypes.Structure):
    _fields_ = [('cbData', wintypes.DWORD), ('pbData', ctypes.POINTER(ctypes.c_ubyte))]


def crypt(value, decrypt=False):
    raw = base64.b64decode(value) if decrypt else value.encode()
    buffer = ctypes.create_string_buffer(raw)
    source = Blob(len(raw), ctypes.cast(buffer, ctypes.POINTER(ctypes.c_ubyte)))
    target = Blob()
    library = ctypes.WinDLL('crypt32', use_last_error=True)
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.LocalFree.argtypes = [ctypes.c_void_p]
    fn = library.CryptUnprotectData if decrypt else library.CryptProtectData
    fn.argtypes = [ctypes.POINTER(Blob), ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p,
                   ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(Blob)]
    fn.restype = wintypes.BOOL
    if not fn(ctypes.byref(source), None, None, None, None, 1, ctypes.byref(target)):
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        result = ctypes.string_at(target.pbData, target.cbData)
        return result.decode() if decrypt else base64.b64encode(result).decode()
    finally:
        kernel.LocalFree(target.pbData)


def session_path(client_id):
    if not normalise_discord_id(client_id):
        raise ValueError('Enter the Application ID from your Lurks AI Defense Discord application.')
    return Path.home() / 'Documents' / 'Lurks AI Defense Sign-in' / (client_id + '.dat')


def save_session(client_id, session):
    path = session_path(client_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix('.tmp')
    temp.write_text(crypt(json.dumps(session)), encoding='utf-8')
    temp.replace(path)


def request_json(path, bearer=None, form=None):
    headers = {'User-Agent': 'LurksAIDefense/Discord-1'}
    if bearer:
        headers['Authorization'] = 'Bearer ' + bearer
    body = None
    if form is not None:
        headers['Content-Type'] = 'application/x-www-form-urlencoded'
        body = urllib.parse.urlencode(form).encode()
    request = urllib.request.Request(API + path, data=body, headers=headers)
    try:
        with urllib.request.urlopen(request, timeout=12) as response:
            return json.load(response)
    except urllib.error.HTTPError as exc:
        if exc.code in (400, 401, 403):
            raise SignInRequired('Discord sign-in needs attention. Check Public Client and the redirect, then sign in again.') from None
        raise OSError('Discord is temporarily unavailable (HTTP %d).' % exc.code) from None
    except urllib.error.URLError:
        raise OSError('Cannot reach Discord. Check your internet connection.') from None


def token_record(response, previous=None):
    if (response.get('token_type', '').lower() != 'bearer' or not response.get('access_token')
            or 'identify' not in response.get('scope', '').split()):
        raise SignInRequired('Discord did not grant identity verification. Sign in again.')
    duration = int(response.get('expires_in', 0))
    if duration <= 0:
        raise SignInRequired('Discord returned an expired session.')
    return {'access_token': response['access_token'],
            'refresh_token': response.get('refresh_token') or (previous or {}).get('refresh_token'),
            'expires_at': time.time() + duration}


def verified_user(client_id, session):
    auth = request_json('/oauth2/@me', bearer=session['access_token'])
    if (str(auth.get('application', {}).get('id')) != client_id
            or 'identify' not in auth.get('scopes', [])):
        raise SignInRequired('This Discord session belongs to a different application. Sign in again.')
    user = auth.get('user', {})
    ident = normalise_discord_id(user.get('id', ''))
    if not ident or user.get('bot'):
        raise SignInRequired('Discord did not verify a member account.')
    return {'id': ident, 'username': user.get('username', ident),
            'name': user.get('global_name') or user.get('username', ident)}


def get_identity(client_id):
    try:
        session = json.loads(crypt(session_path(client_id).read_text(encoding='utf-8'), True))
    except (OSError, ValueError, TypeError, KeyError):
        raise SignInRequired('Open Lurks AI Defense.exe and sign in with Discord.') from None
    if float(session.get('expires_at', 0)) < time.time() + 90:
        if not session.get('refresh_token'):
            raise SignInRequired('Your Discord session expired. Open Lurks AI Defense.exe to sign in again.')
        response = request_json('/oauth2/token', form={'client_id': client_id,
            'grant_type': 'refresh_token', 'refresh_token': session['refresh_token']})
        session = token_record(response, session)
        save_session(client_id, session)
    return verified_user(client_id, session)


def pkce_values():
    verifier = secrets.token_urlsafe(48)
    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b'=').decode()
    return verifier, challenge


def callback_values(path, expected_state):
    parsed = urllib.parse.urlsplit(path)
    args = urllib.parse.parse_qs(parsed.query, strict_parsing=True)
    if parsed.path != '/callback' or any(len(v) != 1 for v in args.values()):
        raise ValueError('Invalid callback')
    if not secrets.compare_digest(args.get('state', [''])[0], expected_state):
        raise ValueError('Sign-in state did not match')
    if args.get('iss', [''])[0] != 'https://discord.com':
        raise ValueError('Unexpected sign-in issuer')
    if args.get('error'):
        raise SignInRequired('Discord sign-in was cancelled.')
    code = args.get('code', [''])[0]
    if not code or len(code) > 2048:
        raise ValueError('Missing sign-in code')
    return code


def login(client_id, timeout=180):
    if not normalise_discord_id(client_id):
        raise ValueError('Enter your separate Lurks AI Defense Discord Application ID first.')
    verifier, challenge = pkce_values()
    state = secrets.token_urlsafe(32)
    result = {}
    class Callback(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def do_GET(self):
            try:
                if self.headers.get('Host') != '127.0.0.1:47683':
                    raise ValueError('Invalid callback host')
                result['code'] = callback_values(self.path, state)
                status, text = 200, 'Finishing Discord sign-in. You can return to Lurks AI Defense.'
            except SignInRequired as exc:
                result['error'] = exc
                status, text = 400, 'Sign-in cancelled. Return to the app to try again.'
            except ValueError:
                status, text = 400, 'Invalid sign-in callback. Return to the app to try again.'
            body = ('<!doctype html><meta charset="utf-8"><title>Lurks AI Defense</title>'
                    '<body style="background:#101116;color:#e8ddff;font:18px Segoe UI;padding:48px">'
                    '<h1>Lurks AI Defense</h1><p>' + text + '</p></body>').encode()
            self.send_response(status)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('Referrer-Policy', 'no-referrer')
            self.send_header('Content-Security-Policy', "default-src 'none'; style-src 'unsafe-inline'; frame-ancestors 'none'")
            self.end_headers()
            self.wfile.write(body)
    class Loopback(HTTPServer):
        allow_reuse_address = False

        def server_bind(self):
            if hasattr(socket, 'SO_EXCLUSIVEADDRUSE'):
                self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
            super().server_bind()

        def get_request(self):
            connection, address = super().get_request()
            connection.settimeout(3)
            return connection, address
    try:
        server = Loopback(('127.0.0.1', 47683), Callback)
    except OSError:
        raise OSError('Discord sign-in is already open, or local port 47683 is in use. Close the other sign-in window and retry.') from None
    try:
        server.timeout = 0.5
        url = 'https://discord.com/oauth2/authorize?' + urllib.parse.urlencode({
            'client_id': client_id, 'response_type': 'code', 'scope': 'identify',
            'redirect_uri': REDIRECT, 'state': state, 'code_challenge': challenge,
            'code_challenge_method': 'S256', 'prompt': 'consent'})
        if not webbrowser.open(url):
            raise OSError('Could not open your browser for Discord sign-in.')
        deadline = time.monotonic() + timeout
        while not result and time.monotonic() < deadline:
            server.handle_request()
    finally:
        server.server_close()
    if result.get('error'):
        raise result['error']
    if not result.get('code'):
        raise SignInRequired('Discord sign-in timed out. Please try again.')
    response = request_json('/oauth2/token', form={'client_id': client_id,
        'grant_type': 'authorization_code', 'code': result['code'],
        'code_verifier': verifier, 'redirect_uri': REDIRECT})
    session = token_record(response)
    user = verified_user(client_id, session)
    save_session(client_id, session)
    return user
