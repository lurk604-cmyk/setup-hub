"""Conservative, calibrated court-view detection and resumable defense setup."""
import json
from pathlib import Path


class CourtViews:
    def __init__(self, root):
        import cv2
        self.root = Path(root)
        self.orb = cv2.ORB_create(nfeatures=1800, fastThreshold=14)
        self.matcher = cv2.BFMatcher(cv2.NORM_HAMMING)
        self.references = []
        self.online_refs = []
        self.learned_at = -10
        self.checked = -10
        self.phase = 'unknown'
        self.details = 'Waiting for a calibrated court view'
        self.current = None
        self.context = None
        self.load()

    def load(self):
        import numpy as np
        self.references = []
        for path in sorted(self.root.glob('court_*.npz')):
            if path.name.startswith('court_auto_'):
                continue  # Quarantine labels inferred from score/clock timing.
            try:
                with np.load(path, allow_pickle=False) as data:
                    meta = json.loads(str(data['metadata']))
                    self.references.append((data['points'].copy(), data['descriptors'].copy(), meta))
            except (OSError, ValueError, KeyError):
                continue

    def features(self, frame):
        import cv2
        import numpy as np
        f = cv2.resize(frame[:, :, :3], (960, 540), interpolation=cv2.INTER_AREA)
        gray = cv2.cvtColor(f, cv2.COLOR_BGR2GRAY)
        mask = np.zeros((540, 960), np.uint8)
        cv2.fillConvexPoly(mask, np.array([[250,200],[710,200],[955,510],[5,510]], np.int32), 255)
        mask[465:540, 290:670] = 0  # Scoreboard cannot be court evidence.
        b, g, r = (f[:, :, i].astype(np.int16) for i in range(3))
        wood = ((r > g) & (g > b+5) & (r-b > 25) & (r > 135)).astype(np.float32)
        # Prefer printed markings surrounded by wood; exclude crowds and jerseys.
        mask[cv2.boxFilter(wood, -1, (31,31)) < .50] = 0
        keypoints, descriptors = self.orb.detectAndCompute(gray, mask)
        points = np.float32([key.pt for key in keypoints]).reshape(-1,2)
        return points, descriptors

    def capture(self, side, period, phase='defense', automatic=False):
        import numpy as np
        if self.current is None or self.current[1] is None or len(self.current[0]) < 60:
            return False, 'No clear court view to learn; wait for normal gameplay'
        if period not in (1,2,3,4):
            return False, 'Waiting for the quarter indicator before learning the court'
        points, descriptors = self.current
        meta = dict(side=side, half=0 if period <= 2 else 1, phase=phase)
        # Four fixed automatic slots bound storage and retain both halves/directions.
        filename = ('court_auto_%s_%d' % (phase, 0 if period <= 2 else 1)) if automatic else 'court_custom'
        path = self.root/(filename+'.npz')
        temp = self.root/(filename+'.tmp')
        with temp.open('wb') as dst:
            np.savez_compressed(dst, points=points, descriptors=descriptors,
                                metadata=json.dumps(meta))
        temp.replace(path)
        self.load()
        self.checked = -10
        return True, ('Court view learned automatically from the new possession' if automatic else
                      'Defense court view learned; automatic setup is armed')

    def scan(self, frame, now, gameplay, side, period):
        if not gameplay or period not in (1,2,3,4):
            self.phase = 'unknown'
            self.details = 'Waiting for gameplay and a clear quarter indicator'
            return self.phase
        if self.context != (side, period):
            self.checked = -10
            self.context = (side, period)
        if now-self.checked < .25:
            return self.phase
        self.checked = now
        import cv2
        import numpy as np
        points, descriptors = self.features(frame)
        self.current = (points, descriptors)
        best = {'defense':0, 'offense':0}
        if descriptors is not None and len(descriptors) > 20:
            for ref_points, ref_descriptors, meta in self.references+self.online_refs:
                pairs = self.matcher.knnMatch(ref_descriptors, descriptors, k=2)
                good = [pair[0] for pair in pairs if len(pair)==2 and pair[0].distance < .72*pair[1].distance]
                if len(good) < 24:
                    continue
                src = np.float32([ref_points[m.queryIdx] for m in good])
                dst = np.float32([points[m.trainIdx] for m in good])
                transform, inliers = cv2.findHomography(src, dst, cv2.RANSAC, 3)
                if transform is None or inliers is None:
                    continue
                accepted = inliers.ravel().astype(bool)
                count = int(accepted.sum())
                if count < 24 or count/len(good) < .35:
                    continue
                # Reject tiny patches of a repeated logo, one jersey, and reflections.
                if min(cv2.contourArea(cv2.convexHull(src[accepted])),
                       cv2.contourArea(cv2.convexHull(dst[accepted]))) < 3500:
                    continue
                basis = cv2.perspectiveTransform(np.float32([[[480,360],[520,360],[480,400]]]), transform)[0]
                dx, dy = basis[1]-basis[0], basis[2]-basis[0]
                if not (0 < dx[0] < 180 and 0 < dy[1] < 180 and
                        abs(dx[1]) < dx[0]*.7 and abs(dy[0]) < dy[1]*.7):
                    continue
                phase = meta['phase']
                reversed_ends = (meta['side'] != side) ^ (meta['half'] != (0 if period <= 2 else 1))
                if reversed_ends:
                    phase = 'offense' if phase == 'defense' else 'defense'
                best[phase] = max(best[phase], count)
        winner = max(best, key=best.get)
        other = 'offense' if winner == 'defense' else 'defense'
        self.phase = winner if best[winner] >= 24 and best[winner] >= best[other]*1.7 else 'unknown'
        # Extend only a strong, geometrically validated view. The opposite end
        # cannot be learned merely because the camera moved or a timer elapsed.
        if (self.phase != 'unknown' and best[winner] >= 60 and best[winner] >= best[other]*2
                and descriptors is not None and best[winner] < len(descriptors)*.5
                and now-self.learned_at >= 2):
            self.online_refs.append((points.copy(),descriptors.copy(),
                                     dict(phase=self.phase,side=side,half=0 if period<=2 else 1)))
            self.online_refs = self.online_refs[-8:]
            self.learned_at = now
        self.details = 'Court matches D:%d O:%d' % (best['defense'], best['offense'])
        return self.phase


class DefenseRun:
    """Commit completed players; retry only the interrupted player's menu."""
    ALL = ('LT','A','X','B','Y')

    def __init__(self):
        self.players = self.ALL
        self.index = 0
        self.step = 0
        self.sequence = ()
        self.until = None
        self.state = 'waiting'
        self.manual_pause = False
        self.interrupted = False
        self.defense_since = None
        self.clear_until = 0
        self.clear_tries = 0
        self.message = 'Waiting for defense'
        self.in_pregame = False
        self.pregame_since = None

    def reset(self, pause=False, center=False):
        self.__init__()
        self.players = ('LT',) if center else self.ALL
        self.manual_pause = pause
        if pause:
            self.message = 'Defense setup paused by you'

    @property
    def owns_output(self):
        return self.state in ('running','clearing')

    def toggle(self):
        if self.state == 'complete':
            self.reset()
        else:
            self.manual_pause = not self.manual_pause
            if self.manual_pause:
                self.suspend('Defense setup paused by you')

    def suspend(self, message):
        if self.state == 'running':
            self.interrupted = True
        if self.state != 'complete':
            self.state = 'waiting'
        self.until = None
        self.defense_since = None
        self.message = message

    def begin_player(self, now):
        player = self.players[self.index]
        trigger = player == 'LT'
        self.sequence = (('LB',.08),(None,.50 if trigger else .30),
                         (player,.24 if trigger else .08),(None,.50 if trigger else .22),
                         ('RT',.08),(None,.16),('RT',.08),(None,.16),('X',.08),(None,.40))
        self.step = 0
        self.until = now+self.sequence[0][1]
        self.state = 'running'
        self.message = 'Defense setup: player %d/%d' % (self.index+1,len(self.players))
        return self.sequence[0][0]

    def tick(self, obs, now, busy=False):
        if obs.get('pregame'):
            if self.pregame_since is None:
                self.pregame_since = now
            if now-self.pregame_since > 1 and not self.in_pregame:
                self.reset()
                self.in_pregame = True
                self.pregame_since = now
        else:
            self.in_pregame = False
            self.pregame_since = None
        if self.state == 'complete':
            self.message = 'Defense setup complete for all selected players'
            return None
        phase = obs.get('possession','unknown')
        if self.manual_pause:
            self.suspend('Defense setup paused by you')
            return None
        if busy or not obs.get('video') or phase != 'defense':
            reason = 'Offense' if phase == 'offense' else 'Waiting for confirmed defense'
            self.suspend(reason+' | %d/%d players complete' % (self.index,len(self.players)))
            return None
        if self.state == 'running':
            if now >= self.until:
                self.step += 1
                if self.step == len(self.sequence):
                    self.index += 1
                    if self.index == len(self.players):
                        self.state = 'complete'
                        self.message = 'Defense setup complete for all selected players'
                        return None
                    return self.begin_player(now)
                self.until = now+self.sequence[self.step][1]
            return self.sequence[self.step][0]
        if self.defense_since is None:
            self.defense_since = now
        if now-self.defense_since < .4:
            return None
        if self.interrupted:
            # Dismiss only a visually confirmed defensive menu, and only on defense.
            # Unknown panels wait; B must never be sent as an offensive pass.
            if self.state == 'clearing' and now < self.clear_until:
                return 'B' if now < self.clear_until-.25 else None
            if obs.get('defense_menu'):
                if self.clear_tries >= 3:
                    self.manual_pause = True
                    self.suspend('Close the defensive menu, then L3+R3 to resume')
                    return None
                self.clear_tries += 1
                self.state = 'clearing'
                self.clear_until = now+.33
                return 'B'
            if obs.get('menu_panel'):
                self.message = 'Waiting for the open menu to be recognized or closed'
                return None
            self.interrupted = False
            self.clear_tries = 0
        return self.begin_player(now)
