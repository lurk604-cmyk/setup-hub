"""Starting 5 setup. Independent of the Helios controller transport for testing."""
import json
import os
import re
from pathlib import Path

SLIDERS = (
    ('help_defense', 'Help Defense', 50),
    ('run_plays', 'Run Plays Frequency', 99),
    ('zone_usage', 'Zone Usage Frequency', 2),
    ('bench_depth', 'Bench Depth', 9),
    ('bench_utilization', 'Bench Utilization', 35),
    ('lineup_factor', 'Lineup Performance Factor', 45),
)
POSITIONS = ('PG', 'SG', 'SF', 'PF', 'C')
DEFENDER_BUTTONS = dict(zip(POSITIONS, ('A', 'B', 'X', 'Y', 'LT')))
# Opponent buttons in the MATCHUP page differ from the defender icon buttons.
TARGET_BUTTONS = ('A', 'X', 'Y', 'LB', 'RB')
MENU_ORDER = ('Quit', 'Timeout', 'Gameplan', 'Game Stats', 'Options', 'Camera', 'Mute')
SUBMENU_ORDER = ('System Proficiency', 'Coach Settings', 'Coaching Sliders', 'Player Health')
# Cycle order on the System Proficiency page, read from the supplied 2K27
# recording (RT/LT cycle through these; the direction is confirmed live).
SYSTEMS = ('Defense', 'Balanced', 'Grit & Grind', 'Pace & Space',
           'Perimeter Centric', 'Post Centric', 'Triangle', 'Seven Seconds')
# After a menu input, wait for the screen to show the result before the next
# one. Sending again before the capture updates caused the old ping-pong.
CONFIRM_TIMEOUT = .80
# Slider values are read from the knob position on the bar (every frame),
# not OCR. Value = low + bar% * (high-low). Bench Depth's bar sits at 40% for
# a value of 9 in both recordings, which fits a 5-15 range; OCR, when it
# produces a confident reading, overrides the bar if they disagree.
SLIDER_RANGES = {'bench_depth': (5, 15)}
SETTLE = .15        # value must be unchanged this long before a decision
CHANGE_WAIT = .50   # after an input, wait this long for the bar to move
HOLD_MIN = 8        # distances >= this are covered by holding the stick
HOLD_LAG = .22      # release this many seconds of travel early (display lag)
END_SETTLE = .20    # 4.6.1: hold this long after the bar reads 0 (or 100): it is exact
SPEED_FILE = 'slider_speed.json'
DEFAULTS = dict(coach_auto=True, coach_enabled=True, coach_fast=True, matchup_enabled=True,
                team_type='All-Time', team='Chicago Bulls', own_position='PG',
                defender='Team preference', preview=True, defense_auto=True, own_side='Away',
                coach_system='Off',
                **{key: value for key, _, value in SLIDERS})


def atomic_json(path, value):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(value, indent=2), encoding='utf-8')
    os.replace(temp, path)


class Setup:
    def __init__(self, root):
        self.root = Path(root)
        self.settings = dict(DEFAULTS)
        self.stamp = None
        self.checked = -10
        self.profiles = {'All-Time|Chicago Bulls': 'SF'}
        try:
            self.profiles.update(json.loads((self.root/'profiles.json').read_text()))
        except (OSError, ValueError):
            pass
        self.state = 'idle'
        self.message = 'Ready | L3+Left: matchup | L3+Right: coach setup'
        self.queue = []
        self.step_until = 0
        self.cooldown = 0
        self.started = 0
        self.coach_started = 0
        self.pregame_seen_at = None
        self.early = False
        self.rearm = False
        self.lost_since = None
        self.await_target = None
        self.armed = True
        self.suspended = False
        self.hud_since = None
        self.pregame_since = None
        self.last_video = -10
        self.row = 0
        self.targets = {}
        self.verified = set()
        self.last_action = -10
        self.last_ocr_sequence = None
        self.readings = []
        self.no_change = 0
        self.previous_value = None
        self.adjustment_row = None
        self.submenu_label = None
        self.submenu_hits = 0
        self.submenu_sequence = None
        self.menu_vote = (None, 0, None)
        self.sub_vote = (None, 0, None)
        self.row_vote = (None, 0, None)
        self.name_vote = (None, 0, None)
        self.match_candidate = None
        self.match_hits = 0
        self.match_opened = False
        self.status_at = -10
        self.await_change = None
        self.system_target = None
        self.system_done = False
        self.system_hits = 0
        self.system_seen = None
        self.system_sequence = None
        self.rt_forward = True
        self.system_tries = 0
        self.system_note = ''
        self.last_trigger = None
        self.pause_attempts = 1
        self.pause_requested = 0
        self.hold = None
        self.hold_works = None
        self.speeds = self._load_speeds()
        self.touched_row = None     # 4.6.1: last slider row an input was sent on
        self.timeline = []
        self.t0 = 0.0
        self.hold_fails = 0
        self.extra_pauses = 0
        self.overdriven = set()
        self.closed_since = None
        self.bar_track = []
        self.from_value = None
        self.ocr_disagree = 0
        self.ocr_last = None

    def refresh(self, now):
        if now-self.checked < .25:
            return
        self.checked = now
        try:
            path = self.root/'module.json'
            stamp = path.stat().st_mtime_ns
            if stamp == self.stamp:
                return
            raw = json.loads(path.read_text(encoding='utf-8'))
            clean = dict(self.settings)
            for key, default in DEFAULTS.items():
                value = raw.get(key, default)
                if type(default) is bool and type(value) is bool:
                    clean[key] = value
                elif type(default) is int and type(value) is int and 0 <= value <= 100:
                    clean[key] = value
                elif type(default) is str and isinstance(value, str):
                    clean[key] = value
            clean['coach_auto'] = clean['coach_fast'] = True   # 4.0 panel: always
            self.settings, self.stamp = clean, stamp
            if clean['defender'] in POSITIONS:
                key = clean['team_type']+'|'+clean['team']
                self.profiles[key] = clean['defender']
                atomic_json(self.root/'profiles.json', self.profiles)
            if self.state.startswith('coach') and not clean['coach_enabled']:
                self.stop('Coach setup disabled')
            if self.state.startswith('match') and not clean['matchup_enabled']:
                self.stop('Matchups disabled')
        except (OSError, ValueError, TypeError):
            pass

    @property
    def busy(self):
        return self.state != 'idle'

    def stop(self, message='Stopped; return to gameplay before retrying'):
        self.queue.clear()
        self.state = 'idle'
        self.message = message
        self.hud_since = None

    def emergency(self):
        self.suspended = True
        self.armed = False
        self.stop('Cancelled; L3+Right retries coaching, L3+Left retries matchup')

    def taps(self, names, now, press=.045, gap=.055):
        self.adjustment_row = None
        self.queue = []
        for name in names:
            self.queue.extend(((name, press), (None, gap)))
        self.step_until = None  # Start the clock only when a callback emits it.
        self.last_action = now
        self.readings = []
        self.last_ocr_sequence = None

    def coach_taps(self, names, now, press, gap, fast_press=.025, fast_gap=.05):
        if self.settings['coach_fast']:
            press, gap = fast_press, fast_gap
        self.taps(names, now, press, gap)

    def nav_tap(self, name, now, observed, press=.07, gap=.10, timeout=None, count=1, target=None):
        """Menu input(s), then wait until the screen shows their effect.
        3.9.2: a known distance is sent in one go (e.g. DOWN, DOWN from System
        Proficiency to Coaching Sliders) and checked once at the end."""
        self.taps([name]*count, now, press, gap)
        self.await_change = (observed, now, timeout)
        # With several inputs in flight, an in-between screen is not the end:
        # wait for the target itself (or the timeout).
        self.await_target = target

    def waiting(self, observed, now, timeout=CONFIRM_TIMEOUT):
        if self.await_change is None:
            return False
        before, started, fixed = self.await_change
        timeout = fixed or timeout
        target = getattr(self, 'await_target', None)
        if target is not None and observed is not None and observed != target and now-started <= (timeout+.6):
            return True
        if observed is not None and observed != before:
            self.await_change = None
            return False
        if now-started > timeout:
            self.await_change = None   # input probably missed; allow a retry
            return False
        return True

    def stable(self, attribute, value, sequence, hits_needed=2):
        """Count fresh vision frames that agree; return the value once stable."""
        seen, hits, last = getattr(self, attribute)
        if value is None:
            # An unreadable frame neither confirms nor resets the vote.
            return None
        if sequence == last:
            return value if hits >= hits_needed and value == seen else None
        hits = hits+1 if value == seen else 1
        setattr(self, attribute, (value, hits, sequence))
        return value if hits >= hits_needed else None

    def coach(self, now, on_sliders=False, on_pause=False):
        if not self.settings['coach_enabled']:
            self.message = 'Enable Coach Sliders first'
            return
        self.suspended = False
        self.armed = False
        self.started = now
        self.t0 = now
        self.timeline = []
        self.touched_row = None
        self.coach_started = now
        self.row = 0
        self.verified.clear()
        self.targets = {k: self.settings[k] for k, _, _ in SLIDERS}
        self.previous_value = None
        self.no_change = 0
        self.state = 'coach_values' if on_sliders else ('coach_nav' if on_pause else 'coach_pause')
        self.submenu_label = None
        self.submenu_hits = 0
        self.submenu_sequence = None
        self.pause_attempts = 1
        self.pause_requested = now
        self.await_change = None
        target = self.settings.get('coach_system', 'Off')
        self.system_target = target if target in SYSTEMS else None
        self.system_done = self.system_target is None
        self.system_tries = 0
        self.system_hits = 0
        self.system_seen = None
        self.system_note = ''
        self.system_seen = None
        self.last_trigger = None
        self.menu_vote = self.sub_vote = self.row_vote = self.name_vote = (None, 0, None)
        self.hold = None
        self.bar_track = []
        self.from_value = None
        self.ocr_disagree = 0
        self.extra_pauses = 0
        self.overdriven = set()
        self.closed_since = None
        self.message = 'Applying saved coach sliders'+(
            ' and system '+self.system_target if self.system_target else '')
        if not on_sliders and not on_pause:
            self.coach_taps(['START'], now, .20, .30, .20, .25)

    def matchup(self, now):
        if not self.settings['matchup_enabled']:
            self.message = 'Enable Matchups first'
            return
        choice = self.settings['defender']
        if choice == 'Team preference':
            choice = self.profiles.get(self.settings['team_type']+'|'+self.settings['team'])
        if choice not in POSITIONS:
            self.message = 'Choose an AI defender once for this team, then use Team preference'
            return
        if choice == self.settings['own_position']:
            self.message = 'Chosen defender is your MyPlayer; select an AI position'
            return
        self.suspended = False
        self.started = now
        self.state = 'match_open'
        self.match_hits = 0
        self.match_candidate = None
        self.match_opened = False
        self.message = 'Opening '+choice+' matchup; use this shortcut while defending'
        self.taps(['LB', DEFENDER_BUTTONS[choice]], now, .08, .35)

    def stable_number(self, observation, now):
        result = observation.get('ocr')
        # The capture shows a slider change a few frames late; read only after
        # the picture has had time to settle.
        settle = .30 if self.settings['coach_fast'] else .45
        if not result or now-self.last_action < settle:
            return None
        sequence, text, age = result
        if age > .7 or sequence == self.last_ocr_sequence:
            return None
        self.last_ocr_sequence = sequence
        if not re.fullmatch(r'\d{1,3}', text.strip()):
            self.readings = []
            return None
        value = int(text)
        if not 0 <= value <= 100:
            return None
        self.readings = (self.readings+[value])[-3:]
        return value if len(self.readings) == 3 and len(set(self.readings)) == 1 else None

    def tick(self, obs, now):
        """Return one controller name, or None. Never skip an input on a late frame."""
        self.refresh(now)
        if obs.get('video'):
            self.last_video = now
        if now-self.last_video > .6:
            if self.busy:
                self.stop('Video lost; setup stopped')
            return None
        # 4.0.1: a pop-up over the dimmed lineup ("Your opponent has left the
        # match", quit/connection messages) means this match is not starting.
        # Forget the lineup so returning to the City never counts as loading.
        if obs.get('dialog'):
            self.dialog_at = now
            self.pregame_seen_at = None
            self.pregame_since = None
            self.hud_since = None
            self.rearm = False
            if self.busy and self.state == 'coach_pause' and self.early:
                self.stop('Match did not start (pop-up after the lineup); coaching waits for the next game')
            return None
        if obs.get('pregame') and not self.busy and now-getattr(self, 'dialog_at', -99) > 3:
            if self.pregame_since is None:
                self.pregame_since = now
            if now-self.pregame_since > 1:
                self.armed = True
                self.suspended = False
                self.pregame_seen_at = now
        else:
            self.pregame_since = None
        if not self.busy:
            auto = (self.armed and not self.suspended and obs.get('ready')
                    and self.settings['coach_auto'] and self.settings['coach_enabled'])
            own_pause = obs.get('coach_settings') or (obs.get('pause') and obs.get('selected_menu'))
            # 3.8: start the moment the "Ready!" lineup screen is gone, before
            # the tip-off, instead of waiting for live play (scorebug).
            # 3.9.2: not on a dark/dimmed screen - e.g. "Your opponent has left
            # the match" over the dimmed lineup (mean brightness ~4 vs 25+
            # for the loading screen and intro). Pressing Start there blocked A.
            loading = (self.pregame_seen_at is not None and not obs.get('pregame')
                       and now-self.pregame_seen_at < 25 and obs.get('brightness', 99) > 12)
            if loading or (obs.get('hud') and not obs.get('pause')) or obs.get('sliders') or own_pause:
                if self.hud_since is None:
                    self.hud_since = now
                if now-self.hud_since > (.6 if loading else .3) and auto:
                    self.coach(now, on_sliders=obs.get('sliders', False), on_pause=bool(own_pause))
                    self.early = loading and not own_pause and not obs.get('sliders')
            else:
                self.hud_since = None
            return None
        # 2K's pause clock is 30 s; it un-pauses by itself first, and the
        # slider step then continues in one more pause (continue_in_new_pause).
        if now-self.started > (32 if self.state.startswith('coach') else 8):
            self.stop('Setup timed out; check menu/video, then retry')
            return None
        # A long callback gap must not continue tapping through a changed screen.
        if self.queue:
            if self.state == 'coach_values' and not obs.get('sliders'):
                self.queue.clear()
                if not self.continue_in_new_pause(obs, now):
                    self.stop('Coach slider page disappeared; setup stopped')
                return None
            if (self.adjustment_row is not None and obs.get('slider_row') is not None
                    and obs.get('slider_row') != self.adjustment_row):
                self.stop('Selected coach slider changed; adjustment stopped')
                return None
            if self.step_until is None:
                self.step_until = now+self.queue[0][1]
            elif now >= self.step_until:
                self.queue.pop(0)
                if self.queue:
                    self.step_until = now+self.queue[0][1]
                else:
                    self.cooldown = now+(.04 if self.state.startswith('coach') and self.settings['coach_fast'] else .16)
                    self.last_action = now
            return self.queue[0][0] if self.queue else None
        if now < self.cooldown:
            return None
        if self.state == 'coach_pause':
            if obs.get('sliders') or obs.get('system_page') or obs.get('pause') or obs.get('coach_settings'):
                self.started = now    # 2K's 30 s pause clock starts when the menu opens
            if obs.get('sliders') or obs.get('system_page'):
                self.state = 'coach_values' if obs.get('sliders') else 'coach_system'
                self._mark(now, 'page open: '+self.state)
            elif obs.get('pause') or obs.get('coach_settings'):
                self.state = 'coach_nav'
            elif now-self.pause_requested >= (1.5 if self.early else 3):
                # During the intro/tip cut-scene Start may be ignored or only
                # skip the scene, so keep asking until the pause menu opens.
                limit = 10 if self.early else 3
                if self.pause_attempts < limit and obs.get('video') and (self.early or obs.get('hud')):
                    self.pause_attempts += 1
                    self.pause_requested = now
                    self.message = 'Opening Pause (attempt %d)' % self.pause_attempts
                    self.coach_taps(['START'], now, .20, .30, .20, .25)
                elif now-self.coach_started >= (16 if self.early else 9):
                    if self.early:
                        # Start was ignored during the intro: try again once
                        # normal gameplay (scorebug) is visible.
                        self.rearm = True
                        self.armed = True     # 4.5.1: really retry (coach() had disarmed it)
                        self.pregame_seen_at = None
                    self.stop(f'Pause screen not detected after {self.pause_attempts} Menu/Start attempts'
                              + (' (will retry when gameplay shows)' if self.early else ''))
            return None
        if self.state == 'coach_nav':
            return self.navigate(obs, now)
        if self.state == 'coach_system':
            return self.choose_system(obs, now)
        if self.state == 'coach_system_back':
            if obs.get('system_page'):
                if not self.waiting('system_page', now, 1.0):
                    self.nav_tap('B', now, 'system_page', .08, .15)
                return None
            if obs.get('pause'):
                self.state = 'coach_nav'
                self.await_change = None
                self.message = 'System set; opening Coaching Sliders'
            return None
        if self.state == 'coach_values':
            if obs.get('system_page'):
                self.state = 'coach_system'
                return None
            if not obs.get('sliders'):
                if self.continue_in_new_pause(obs, now):
                    return None
                self.stop('Coach slider page disappeared; setup stopped')
                return None
            return self.adjust_sliders(obs, now)
        if self.state in ('coach_back', 'coach_back_to_system') and obs.get('hud') and not (
                obs.get('pause') or obs.get('sliders') or obs.get('system_page')):
            # The 30 s pause clock ran out after the last slider was set.
            if self.state == 'coach_back' or not self.continue_in_new_pause(obs, now):
                self.state = 'coach_close'
            return None
        if self.state == 'coach_back_to_system':
            if obs.get('pause') and not obs.get('sliders'):
                self.state = 'coach_nav'
                self.await_change = None
            elif obs.get('sliders') and not self.waiting('sliders', now, 1.0):
                self.nav_tap('B', now, 'sliders', .08, .15)
            return None
        if self.state == 'coach_back':
            if obs.get('pause') and not obs.get('sliders'):
                self.state = 'coach_close'
                self.coach_taps(['B'], now, .08, .45, .04, .15)
            elif obs.get('sliders') and not self.waiting('sliders', now, 1.0):
                self.nav_tap('B', now, 'sliders', .08, .15)
            return None
        if self.state == 'coach_close':
            # The menus are gone once neither pause nor a coach page shows for
            # 1 s. (At tip-off the scorebug is a different intro graphic, so
            # waiting for the normal scorebug timed out in the Nov 4 game.)
            menus = obs.get('pause') or obs.get('sliders') or obs.get('system_page') or obs.get('coach_settings')
            if menus:
                self.closed_since = None
            elif obs.get('video'):
                self.closed_since = self.closed_since or now
            if obs.get('hud') and not obs.get('pause') or (self.closed_since and now-self.closed_since >= 1.0):
                done = 'all six values verified'
                if self.system_target:
                    done += ', system '+self.system_target+(' active' if self.system_done else ' NOT set')
                self.stop('Coach preset applied; '+done+(' | '+self.system_note if self.system_note else ''))
            elif obs.get('pause') and not self.waiting('pause', now, 1.2):
                self.nav_tap('B', now, 'pause', .08, .15)
            return None
        if self.state == 'match_open':
            if not obs.get('matchup'):
                return None
            row = obs.get('human_row')
            if row is None:
                self.match_hits = 0
                return None
            self.match_hits = self.match_hits+1 if row == self.match_candidate else 1
            self.match_candidate = row
            if self.match_hits >= 3:
                self.state = 'match_confirm'
                self.taps([TARGET_BUTTONS[row]], now, .08, .16)
                self.message = 'Selecting the human in matchup row '+str(row+1)
            return None
        if self.state == 'match_confirm':
            if not obs.get('matchup'):
                self.stop('Matchup selection sent; check the defensive assignment in game')
            elif obs.get('target_highlight') == self.match_candidate:
                self.stop('Human matchup selected (menu confirmation detected)')
            return None
        return None

    def adjust_sliders(self, obs, now):
        selected = obs.get('slider_row')
        if selected is None:
            return None
        key, label, _ = SLIDERS[self.row]
        target = self.targets[key]
        low, high = SLIDER_RANGES.get(key, (0, 100))
        raw = obs.get('slider_bar')
        value = None if raw is None else low+raw/100.0*(high-low)
        # ---- holding the stick for a long distance (closed loop on the bar)
        if self.hold is not None:
            direction = self.hold['dir']
            if selected != self.row and self.hold['mode'] == 'combo':
                self.speeds['combo_bad'] = True     # the D-pad changed the row: stop using it
            if value is not None and selected == self.row:
                self.hold['hist'].append((now, value))
            history = [(t, v) for t, v in self.hold['hist'] if now-t <= .30]
            speed = 0.0
            if len(history) >= 2 and history[-1][0] > history[0][0]:
                speed = max(0.0, (history[-1][1]-history[0][1])*direction/(history[-1][0]-history[0][0]))
            current = history[-1][1] if history else self.hold['v0']
            moved = (current-self.hold['v0'])*direction
            remaining = (target-current)*direction
            elapsed = now-self.hold['start']
            if moved >= 1.5:
                self.hold_works = True
                self.hold_fails = 0
            if self.hold['end']:
                # 4.6: going to 0 (or 100) cannot overshoot, so keep holding until
                # the bar has sat at the end for END_SETTLE s; then it is exact.
                at_end = abs(current-target) < .5
                if at_end and self.hold.get('end_at') is None:
                    self.hold['end_at'] = now
                if not at_end:
                    self.hold['end_at'] = None
                if (self.hold.get('end_at') is not None and now-self.hold['end_at'] >= END_SETTLE) \
                        or elapsed > 16 or selected != self.row:
                    if selected == self.row and self.hold.get('end_at') is not None:
                        self.overdriven.add(key)        # pressed against the end stop
                    self.end_input(now, current)
                    return None
            elif remaining <= speed*HOLD_LAG+1.0 or elapsed > 6 or selected != self.row:
                self.end_input(now, current)
                return None
            if elapsed > .90 and moved < 1.5:
                # Holding does not auto-repeat (or the input was missed).
                self.hold_fails += 1
                if self.hold_fails >= 2:
                    self.hold_works = False      # use taps from now on
                self.end_input(now, current)
                return None
            self.message = '%s: holding %s (%d -> %d)' % (label, 'right' if direction > 0 else 'left',
                                                       round(current), target)
            command = 'SLIDER_RIGHT' if direction > 0 else 'SLIDER_LEFT'
            return command+'_FAST' if self.hold['mode'] == 'combo' else command
        if self.waiting(selected, now, .6):
            return None
        if selected != self.row:
            self.nav_tap('DOWN' if selected < self.row else 'UP', now, selected, .05, .08)
            self.bar_track = []
            return None
        if value is None:
            return None
        rounded = int(round(value))
        # ---- has the last input finished showing on screen?
        self.bar_track = [(t, v) for t, v in self.bar_track if now-t <= .5]+[(now, rounded)]
        recent = [v for t, v in self.bar_track if now-t <= SETTLE]
        settled = (len(set(recent)) == 1 and self.bar_track[0][0] <= now-SETTLE
                   and now-self.last_action >= SETTLE)
        seq = obs.get('vision_sequence')
        reads = getattr(self, 'fresh_reads', [])
        if not reads or reads[-1][0] != seq:
            reads = (reads+[(seq, self.row, rounded)])[-3:]
            self.fresh_reads = reads
        if (self.touched_row != self.row and self.hold is None and not self.queue and len(reads) >= 2
                and reads[-1][1:] == reads[-2][1:] == (self.row, rounded)):
            # 4.6.1: nothing was sent on this row yet, so its value cannot be
            # moving: two matching readings from separate frames are enough.
            settled = True
        moved = self.from_value is None or rounded != self.from_value
        if not settled or (not moved and now-self.last_action < CHANGE_WAIT):
            return None
        # Optional OCR cross-check (fast when available, never waited for).
        reading = obs.get('ocr')
        if reading and reading[1].strip().isdigit() and reading[2] < .3:
            ocr_value = int(reading[1])
            if 0 <= ocr_value <= 100 and abs(ocr_value-rounded) <= 30:
                if ocr_value != rounded:
                    self.ocr_disagree = self.ocr_disagree+1 if self.ocr_last == ocr_value else 1
                    self.ocr_last = ocr_value
                    if self.ocr_disagree >= 2:
                        rounded = ocr_value          # trust confident OCR
                else:
                    self.ocr_disagree = 0
        self.message = '%s: %d -> %d' % (label, rounded, target)
        rounded = min(high, max(low, rounded))
        if key in self.overdriven and abs(rounded-target) <= 1:
            rounded = target        # pushed against the end stop: it IS the end value
        if (target in (low, high) and key not in self.overdriven and abs(rounded-target) < HOLD_MIN
                and self.row < len(SLIDERS)-1 and selected == self.row):
            # 4.6.1: close to 0 (or 100): tap into the end stop (it cannot go
            # past it, so +3 makes it exact) and go to the next slider in the
            # same burst, instead of tapping, waiting and checking.
            towards = 'SLIDER_LEFT' if target == low else 'SLIDER_RIGHT'
            count = abs(rounded-target)+3
            self.overdriven.add(key)
            self.verified.add(key)
            self._mark(now, '%s = %d (%d taps into the end, then next)' % (label, target, count))
            self.taps([towards]*count+['DOWN'], now, .05, .06)
            self.adjustment_row = None      # the DOWN at the end changes the row on purpose
            self.fresh_reads = []
            # the row-change check starts when the DOWN actually goes out
            self.await_change = (selected, now+(count+1)*.11, None)
            self.await_target = None
            self.touched_row = None
            self.row += 1
            self.readings = []
            self.previous_value = None
            self.no_change = 0
            self.from_value = None
            self.ocr_disagree = 0
            self.bar_track = []
            return None
        if abs(rounded-target) <= 1 and target in (low, high) and key not in self.overdriven:
            # The knob reads the same at 0 and 1 (and 99/100): the Nov 4 game
            # ended Help Defense on 1 while the bar said 0. The slider cannot
            # pass its end, so 5 extra taps toward that end make it exact.
            self.overdriven.add(key)
            self.touched_row = self.row
            # 4.6.1: 3 taps (it is at most 1 away); 50/60 ms still lands every tap
            self.taps(['SLIDER_LEFT' if target == low else 'SLIDER_RIGHT']*3, now, .05, .06)
            self.adjustment_row = self.row
            self.from_value = None
            self.bar_track = []
            return None
        if rounded == target:
            self.verified.add(key)
            self._mark(now, '%s = %d' % (label, target))
            self.row += 1
            self.readings = []
            self.previous_value = None
            self.no_change = 0
            self.from_value = None
            self.ocr_disagree = 0
            self.bar_track = []
            if self.row == len(SLIDERS):
                self.state = 'coach_back' if self.system_done else 'coach_back_to_system'
                self.nav_tap('B', now, 'sliders', .06, .12)
            else:
                self.nav_tap('DOWN', now, selected, .05, .08)
            return None
        if self.from_value is not None and not moved:
            self.no_change += 1
            if self.no_change >= 4:
                self.stop(label+' did not change; check its allowed range and controls')
                return None
        else:
            self.no_change = 0
        steps = target-rounded
        direction = 1 if steps > 0 else -1
        if abs(steps) >= HOLD_MIN and high-low >= 50 and self.hold_works is not False:
            self.touched_row = self.row
            self._mark(now, '%s: hold from %d' % (label, rounded))
            self.hold = dict(dir=direction, start=now, v0=value, hist=[(now, value)],
                             end=target in (low, high), mode=self._pick_mode(), row=self.row)
            self.message = '%s: holding %s (%d -> %d)' % (label, 'right' if direction > 0 else 'left',
                                                       rounded, target)
            return 'SLIDER_RIGHT' if direction > 0 else 'SLIDER_LEFT'
        count = min(abs(steps), 40)
        self.touched_row = self.row
        self._mark(now, '%s: %d taps from %d' % (label, count, rounded))
        # Live recording: 24 taps at 25/25 ms moved the slider only 12, so
        # taps closer than ~0.1 s are dropped. 50/60 ms lands every tap.
        self.taps(['SLIDER_RIGHT' if direction > 0 else 'SLIDER_LEFT']*count, now, .05, .06)
        self.adjustment_row = self.row
        self.from_value = rounded
        return None

    def continue_in_new_pause(self, obs, now):
        """The 30 s pause ran out mid-sliders: pause once more and carry on."""
        if self.extra_pauses >= 1 or not (obs.get('hud') and not obs.get('pause')):
            return False
        self.extra_pauses += 1
        self.hold = None
        self.queue.clear()
        self.overdriven = set(self.verified) & self.overdriven   # redo an interrupted end-stop push
        self.state = 'coach_pause'
        self.started = now
        self.coach_started = now
        self.pause_attempts = 1
        self.pause_requested = now
        self.await_change = None
        self.menu_vote = self.sub_vote = (None, 0, None)
        self.message = 'Pause time ran out at %s; pausing once more to finish' % SLIDERS[min(self.row, 5)][1]
        self.coach_taps(['START'], now, .20, .30, .20, .25)
        return True

    def _mark(self, now, text):
        """4.6.1: coaching timeline (seconds since coaching started) for status.json."""
        self.timeline.append('%5.2f %s' % (now-self.t0, text))
        self.timeline = self.timeline[-40:]

    # ---- 4.6: learn whether holding the D-pad with the stick moves faster
    def _load_speeds(self):
        try:
            data = json.loads((self.root/SPEED_FILE).read_text(encoding='utf-8'))
            return {k: v for k, v in data.items() if k in ('stick', 'combo', 'combo_bad')}
        except (OSError, ValueError, AttributeError):
            return {}

    def _pick_mode(self):
        sp = self.speeds
        if sp.get('combo_bad'):
            return 'stick'
        if 'combo' not in sp:
            return 'combo'          # try it once
        if 'stick' not in sp:
            return 'stick'          # measure the normal way once
        return 'combo' if sp['combo'] > sp['stick']*1.15 else 'stick'

    def _learn_speed(self, hold, now, value):
        try:
            stop = hold.get('end_at') or now            # time spent parked at 0 is not travel
            elapsed = stop-hold['start']-.3             # 2K's auto-repeat delay
            moved = (value-hold['v0'])*hold['dir'] if value is not None else 0
            if hold['row'] != self.row and hold['mode'] == 'combo':
                self.speeds['combo_bad'] = True         # D-pad moved the selection: never again
            elif elapsed >= .8 and moved >= 5:
                rate = moved/elapsed
                old = self.speeds.get(hold['mode'])
                self.speeds[hold['mode']] = round(rate if old is None else .5*old+.5*rate, 2)
            else:
                return
            (self.root/SPEED_FILE).write_text(json.dumps(self.speeds), encoding='utf-8')
        except (OSError, TypeError, ValueError):
            pass

    def end_input(self, now, value):
        if self.hold is not None:
            self._learn_speed(self.hold, now, value)
            self._mark(now, 'hold ended at %s' % (None if value is None else round(value)))
        self.hold = None
        self.last_action = now
        self.from_value = None     # a hold is judged by the next reading, not counted
        self.bar_track = []

    def navigate(self, obs, now):
        """Pause menu -> Gameplan -> the needed submenu, one confirmed input at a time."""
        want = 'System Proficiency' if not self.system_done else 'Coaching Sliders'
        if obs.get('sliders'):
            self.state = 'coach_values'
            self.last_action = now
            self.await_change = None
            return None
        if obs.get('system_page'):
            self.state = 'coach_system'
            self.await_change = None
            return None
        if obs.get('coach_settings'):
            if not self.waiting('coach_settings', now, 1.0):
                self.message = 'Backing out of Coach Settings to select '+want
                self.nav_tap('B', now, 'coach_settings', .10, .15)
            return None
        if not obs.get('pause'):
            if obs.get('hud') and self.verified:
                self.continue_in_new_pause(obs, now)
            elif obs.get('video') and not obs.get('hud'):
                # An unknown page (e.g. Player Health opened by mistake):
                # back out after 1.5 s.
                self.lost_since = self.lost_since or now
                if now-self.lost_since > 1.5 and not self.waiting('lost', now, 1.0):
                    self.message = 'Unknown page; backing out'
                    self.nav_tap('B', now, 'lost', .08, .15)
                    self.lost_since = now
            return None
        self.lost_since = None
        sequence = obs.get('vision_sequence')
        selected = self.stable('menu_vote', obs.get('selected_menu'), sequence)
        label = self.stable('sub_vote', obs.get('submenu_text'), sequence)
        # Only a stable reading may end the wait; an unread frame never does.
        if selected is None:
            observed = None
        elif selected != 'Gameplan':
            observed = ('menu', selected)
        else:
            observed = ('sub', label) if label else None
        if self.waiting(observed, now):
            return None
        if selected is None:
            self.message = 'Reading highlighted pause menu item'
            return None
        if selected != 'Gameplan':
            if selected not in MENU_ORDER:
                return None
            distance = MENU_ORDER.index('Gameplan')-MENU_ORDER.index(selected)
            direction = 'RIGHT' if distance > 0 else 'LEFT'
            self.message = 'Pause menu: '+selected+' -> Gameplan'
            self.nav_tap(direction, now, ('menu', selected), .06, .12, count=abs(distance))
            return None
        if label is None:
            self.message = 'Gameplan open; reading the highlighted item'
            return None
        self.message = 'Gameplan highlight: %s (want %s)' % (label, want)
        if label == want:
            # Opening a page takes a moment; never send a second A early.
            self.nav_tap('A', now, ('sub', label), .10, .15, timeout=2.0)
            self.sub_vote = (None, 0, None)
        elif label in SUBMENU_ORDER:
            distance = SUBMENU_ORDER.index(want)-SUBMENU_ORDER.index(label)
            direction = 'DOWN' if distance > 0 else 'UP'
            self.nav_tap(direction, now, ('sub', label), .06, .12, count=abs(distance),
                         target=('sub', want) if abs(distance) > 1 else None)
        return None

    def choose_system(self, obs, now):
        if obs.get('sliders'):
            self.state = 'coach_values'
            return None
        if not obs.get('system_page'):
            if obs.get('pause'):
                self.state = 'coach_nav'
            return None
        if self.system_done:
            self.state = 'coach_system_back'
            self.await_change = None
            return None
        sequence = obs.get('vision_sequence')
        name = self.stable('name_vote', obs.get('system_name'), sequence)
        active = obs.get('system_active')
        if self.waiting(('system', name, active) if name else None, now, 1.2):
            return None
        if name is None:
            self.message = 'System Proficiency: reading the shown system'
            return None
        target = self.system_target
        if name == target:
            if active:
                self.system_done = True
                self.message = 'System '+target+' is active'
                self.state = 'coach_system_back'
                self.await_change = None
                return None
            if self.system_tries >= 3:
                self.system_done = True   # carry on with sliders; report it
                self.system_note = 'Make Active (A) did not take effect for '+target
                self.state = 'coach_system_back'
                return None
            self.system_tries += 1
            self.message = 'Making '+target+' active'
            self.nav_tap('A', now, ('system', name, active), .10, .20, timeout=1.5)
            return None
        if name not in SYSTEMS or target not in SYSTEMS:
            return None
        here, there = SYSTEMS.index(name), SYSTEMS.index(target)
        if self.system_seen is not None and self.system_seen in SYSTEMS and self.system_seen != name:
            # Learn which trigger moves forward from the last confirmed move.
            before = SYSTEMS.index(self.system_seen)
            moved_forward = here == (before+1) % len(SYSTEMS)
            moved_back = here == (before-1) % len(SYSTEMS)
            expected_forward = (self.last_trigger == 'RT') == self.rt_forward
            if (moved_forward or moved_back) and moved_forward != expected_forward:
                self.rt_forward = not self.rt_forward
        forward = (there-here) % len(SYSTEMS) <= len(SYSTEMS)//2
        trigger = 'RT' if forward == self.rt_forward else 'LT'
        self.system_seen = name
        self.last_trigger = trigger
        self.message = 'System Proficiency: %s -> %s (%s)' % (name, target, trigger)
        self.nav_tap(trigger, now, ('system', name, active), .08, .12)
        return None

    def save_status(self, now, defense=None):
        if now-self.status_at < .5:
            return
        self.status_at = now
        try:
            atomic_json(self.root/'status.json', dict(state=self.state, message=self.message,
                        verified=sorted(self.verified), armed=self.armed, defense=defense))
        except OSError:
            pass
