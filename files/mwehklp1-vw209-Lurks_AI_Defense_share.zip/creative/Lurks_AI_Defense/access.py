"""Discord account access checks. No machine IDs, hardware data or owner credentials."""
import importlib.util
import json
from pathlib import Path
import re
import sys
import threading
import time
import urllib.parse
import urllib.request

if getattr(sys, 'frozen', False):
    import discord_identity as _identity
else:
    _spec = importlib.util.spec_from_file_location('_lurks_discord_identity', Path(__file__).with_name('discord_identity.py'))
    _identity = importlib.util.module_from_spec(_spec)
    _spec.loader.exec_module(_identity)
fingerprint = _identity.fingerprint
normalise = _identity.normalise_discord_id
INTERVAL = 45
LEASE = 120
TIMEOUT = 8


def validate_url(url):
    parsed = urllib.parse.urlsplit(url)
    if (parsed.scheme != 'https' or parsed.hostname != 'gist.githubusercontent.com'
            or parsed.username or parsed.password or parsed.port not in (None, 443)):
        raise ValueError('An HTTPS GitHub Gist raw URL is required.')
    return url


def parse_manifest(text, allow_legacy=False):
    data = json.loads(text)
    schemas = (2, 3) if allow_legacy else (3,)
    if (not isinstance(data, dict) or data.get('schema') not in schemas
            or (data.get('schema') == 3 and data.get('identity') != 'discord')
            or not isinstance(data.get('revision'), str)
            or not isinstance(data.get('allowed'), list)
            or any(not isinstance(v, str) or not re.fullmatch('[a-f0-9]{64}', v)
                   for v in data['allowed'])):
        raise ValueError('Invalid Discord access list')
    return data


class Access:
    def __init__(self, root, url=None, client_id=None):
        self.root = Path(root)
        self.id = 'Sign in with Discord'
        self.name = ''
        self.state = 'checking'
        self._url, self._client_id = url, client_id
        self._next = self._valid_until = 0.0
        self._busy = False
        self._lock = threading.Lock()

    def allowed(self):
        now = time.monotonic()
        with self._lock:
            if self.state == 'approved' and now >= self._valid_until:
                self.state = 'offline'
            if not self._busy and now >= self._next:
                self._busy = True
                threading.Thread(target=self._check, name='LurksDiscordAccess', daemon=True).start()
            return self.state == 'approved'

    def _check(self):
        try:
            config = {}
            if self._url is None or self._client_id is None:
                config = json.loads((self.root / 'access_config.json').read_text(encoding='utf-8'))
            url = self._url if self._url is not None else config.get('url', '')
            client_id = self._client_id if self._client_id is not None else config.get('discord_client_id', '')
            validate_url(url)
            if not normalise(client_id):
                with self._lock:
                    self.state, self._valid_until = 'setup', 0.0
                return
            # Authorization is always derived from Discord's verified response, never an entered ID.
            user = _identity.get_identity(client_id)
            request = urllib.request.Request(url + ('&' if '?' in url else '?') + 'check=' + str(time.time_ns()),
                headers={'Cache-Control': 'no-cache', 'User-Agent': 'LurksAccess/Discord-1'})
            with urllib.request.urlopen(request, timeout=TIMEOUT) as response:
                validate_url(response.url)
                raw = response.read(524289)
            if len(raw) > 524288:
                raise ValueError('Access list too large')
            manifest = parse_manifest(raw.decode('utf-8'))
            approved = fingerprint(user['id']) in manifest['allowed']
            with self._lock:
                self.id, self.name = user['id'], user['username']
                self.state = 'approved' if approved else 'denied'
                self._valid_until = time.monotonic() + LEASE if approved else 0.0
        except _identity.SignInRequired:
            with self._lock:
                self.state, self._valid_until = 'login', 0.0
        except Exception:
            with self._lock:
                if self.state != 'approved' or time.monotonic() >= self._valid_until:
                    self.state = 'offline'
        finally:
            with self._lock:
                self._next = time.monotonic() + (INTERVAL if self.state == 'approved' else 15)
                self._busy = False

    def message(self):
        if self.state == 'approved':
            return 'Lifetime Discord access active - @' + self.name
        if self.state == 'login':
            return 'Sign in required: open Lurks AI Defense.exe in the Lurks_AI_Defense folder.'
        if self.state == 'setup':
            return 'Discord setup is pending. Ask Lurk for the connected Discord sign-in package.'
        if self.state == 'checking':
            return 'Checking verified Discord account access...'
        if self.state == 'offline':
            return 'Cannot verify access online. Check your internet connection and Discord sign-in.'
        return 'Discord account not approved or revoked. Send your Discord user ID to Lurk: ' + self.id
