"""Shot clock reader (4.8).

The 24-second shot clock sits in a small white box on the scoreboard, at the
bottom centre of the screen. It resets to 24 the moment the ball hits the rim
or changes hands, so a jump to 24 is the warning that a rebound or a change of
possession is coming. Afterwards:

  * 14 counting down  -> they got the offensive rebound (still your defense),
  * 23 counting down  -> new possession (after a rim hit on your defense this
                         is your team's ball).

Reading it is very cheap: a 29x17 px box (at 1080p) and two digits matched
against small templates (shot_clock_digits.npy, cut from a real 1080p game).
Digits it has no template for (5, 6, under 10 s) just read as "other".
"""
import time

REF_H = 1080.0
BOX = (21, 1030, 50, 1047)        # x0, y0, x1, y1 at 1080p; x relative to the screen centre
GLYPH_H, GLYPH_W = 12, 11
DIGITS = '01234789'
MATCH_MIN = .85                    # template correlation needed for a digit
MATCH_MARGIN = .06                 # ... and this much above the next best digit
STABLE = 2                         # same value this many reads in a row
REBOUND_WAIT = 6.0                 # s after a reset in which a 14 means an offensive rebound
WORKING_READS = 30                 # reads in a game before the clock is trusted
FRESH = 2.0                        # s: a read this recent means the clock is on screen


class ShotClock:
    def __init__(self, root):
        import numpy as np
        self.error = ''
        try:
            self.templates = np.load(str(root)+'/shot_clock_digits.npy').astype(np.float32)
            self.ok = self.templates.shape[0] == len(DIGITS)
        except Exception as exc:
            self.ok, self.error = False, 'digit templates missing: %s' % str(exc)[:60]
        self.value = None              # last stable reading: int, 'other' or None
        self._raw, self._count = None, 0
        self.read_at = -10.0           # last time a number was read
        self.reads = 0
        self.resets = 0
        self.reset_at = -10.0
        self.before_reset = None
        self.after_reset = None        # 'offensive_rebound' / 'new_possession'
        self.events = []
        self._queue = []
        self.cost_ms = 0.0
        self.history = []

    # ------------------------------------------------------------- reading
    def _glyphs(self, gray):
        import numpy as np
        dark = gray < 110
        dark[:3, :] = False
        dark[-2:, :] = False
        dark[:, :2] = False
        dark[:, -2:] = False
        cols = dark.any(axis=0)
        runs, start = [], None
        for x, on in enumerate(list(cols)+[False]):
            if on and start is None:
                start = x
            if not on and start is not None:
                runs.append((start, x))
                start = None
        out = []
        for a, b in runs:
            rows = np.where(dark[:, a:b].any(axis=1))[0]
            if b-a < 2 or len(rows) < 7:
                continue
            out.append(gray[rows[0]:rows[-1]+1, a:b])
        return out

    def _digit(self, glyph):
        import cv2
        import numpy as np
        h, w = glyph.shape
        width = max(2, min(GLYPH_W, int(round(w*GLYPH_H/float(h)))))
        g = cv2.resize(glyph.astype(np.float32), (width, GLYPH_H), interpolation=cv2.INTER_AREA)
        canvas = np.full((GLYPH_H, GLYPH_W), 255.0, np.float32)
        x0 = (GLYPH_W-width)//2
        canvas[:, x0:x0+width] = g
        v = canvas-canvas.mean()
        v /= (np.sqrt((v*v).sum())+1e-6)
        scores = (self.templates*v).sum(axis=(1, 2))
        order = scores.argsort()
        best, second = scores[order[-1]], scores[order[-2]]
        if best >= MATCH_MIN and best-second >= MATCH_MARGIN:
            return DIGITS[int(order[-1])]
        return None

    def _read(self, frame):
        import cv2
        h, w = frame.shape[:2]
        k = h/REF_H
        cx = w/2.0
        x0, y0, x1, y1 = BOX
        crop = frame[int(y0*k):int(y1*k)+1, int(cx+x0*k):int(cx+x1*k)+1, :3]
        if crop.shape[0] < 6 or crop.shape[1] < 10:
            return None
        if abs(k-1) > .02:
            crop = cv2.resize(crop, (x1-x0+1, y1-y0+1), interpolation=cv2.INTER_AREA)
        gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
        if (gray > 190).mean() < .45:             # no white box here
            return None
        glyphs = self._glyphs(gray)
        if not 1 <= len(glyphs) <= 2:
            return 'other'
        text = ''
        for glyph in glyphs:
            digit = self._digit(glyph)
            if digit is None:
                return 'other'
            text += digit
        value = int(text)
        return value if value <= 24 else 'other'

    # -------------------------------------------------------------- public
    def scan(self, frame, now):
        """Call every frame during gameplay (about 0.05 ms)."""
        if not self.ok or frame is None or not hasattr(frame, 'shape'):
            return
        t0 = time.perf_counter()
        try:
            raw = self._read(frame)
        except Exception as exc:              # never break the script
            self.error = str(exc)[:120]
            raw = None
        if raw == self._raw:
            self._count += 1
        else:
            self._raw, self._count = raw, 1
        if self._count == STABLE and raw is not None:
            self._accept(raw, now)
        if raw is not None and raw != 'other':
            self.read_at = now
            self.reads += 1
        self.cost_ms = round((time.perf_counter()-t0)*1000, 3)

    def _accept(self, value, now):
        old = self.value
        if value == old:
            return
        self.value = value
        if value == 24 and old != 24 and old is not None:
            # 24 after anything else: ball hit the rim or changed hands
            self.resets += 1
            self.reset_at = now
            self.before_reset = old
            self.after_reset = None
            self._queue.append('reset')
            self._log('shot clock reset to 24 (was %s)' % old)
        elif now-self.reset_at <= REBOUND_WAIT and self.after_reset is None and old == 24:
            if value == 14 or value == 13:
                self.after_reset = 'offensive_rebound'
                self._queue.append('offensive_rebound')
                self._log('then %s: offensive rebound' % value)
            elif value in (23, 22):
                self.after_reset = 'new_possession'
                self._queue.append('new_possession')
                self._log('then %s: new possession' % value)

    def take_events(self):
        events, self._queue = self._queue, []
        return events

    @property
    def working(self):
        return self.reads >= WORKING_READS

    def on_screen(self, now):
        return self.working and now-self.read_at <= FRESH

    def loose_ball(self, now):
        """Reset to 24 a moment ago and nobody has the ball yet (clock frozen)."""
        return self.value == 24 and self.after_reset is None and now-self.reset_at <= REBOUND_WAIT

    def new_game(self):
        self.value, self._raw, self._count = None, None, 0
        self.reads = self.resets = 0
        self.read_at = self.reset_at = -10.0
        self.after_reset = None
        self._queue = []

    def summary(self, now):
        return dict(value=self.value, working=self.working, on_screen=self.on_screen(now),
                    resets=self.resets, last_reset_ago=round(min(now-self.reset_at, 999), 1),
                    after_reset=self.after_reset, cost_ms=self.cost_ms,
                    events=self.events[-10:], error=self.error)

    def _log(self, text):
        self.events.append(time.strftime('%H:%M:%S ')+text)
        self.events = self.events[-12:]
