"""Video calibration from the supplied 1080p Starting 5 recordings."""
from pathlib import Path
import re


class Vision:
    def __init__(self, root):
        self.root = Path(root)
        self.engine = None
        self.error = ''
        self.retry_at = 0
        self.checked = -10
        self.obs = {}
        self.templates = {}
        self.region_key = None
        self.region_since = 0
        self.ocr_sequence = None
        self.ocr_at = -10
        self.ocr_text = ''
        self.ready = False
        self.courts = None
        self.side = 'Away'
        self.auto_detection = True
        self.fixed_ocr = {}
        self.period = None
        self.coach_active = False
        self.coach_fast = True
        self.ocr_priority = None
        self.vision_sequence = 0
        from .score_start import ScoreStart
        self.score_start = ScoreStart()
        self.score_start.message = 'Score-based possession learning is disabled after a live misclassification'
        self.score_notice = ''

    @staticmethod
    def dialog(small, gray):
        """2K pop-up over a dimmed screen ("Your opponent has left the match",
        quit / connection messages): a solid bright-cyan OK button with white
        text above it. The cyan-green "MC" logo of the normal lineup -> game
        transition is a different shape (half filled, taller than wide)."""
        import cv2
        import numpy as np
        px = small.astype(np.int16)
        b, g, r = px[..., 0], px[..., 1], px[..., 2]
        mask = ((g > 170) & (b > 150) & (r < 110) & (g-r > 90)).astype(np.uint8)
        if int(mask.sum()) < 300:
            return False
        count, labels, stats, _ = cv2.connectedComponentsWithStats(mask)
        for i in range(1, count):
            x, y, w, h, area = (int(v) for v in stats[i])
            if not (35 <= w <= 100 and 15 <= h <= 40 and w > 1.4*h and area > .75*w*h):
                continue
            if px[labels == i][:, 2].mean() > 45:
                continue
            text = gray[max(0, y-80):max(0, y-4), x:min(960, x+320)]
            if int((text > 200).sum()) >= 120:
                return True
        return False

    def close(self):
        if self.engine is not None:
            try:
                self.engine.destroy()
            except Exception:
                pass
        self.engine = None
        self.ready = False

    def start(self, now):
        if self.engine is not None:
            return
        if now < self.retry_at:
            return
        self.retry_at = now+5
        try:
            from helios import inference
            self.engine = inference.create_inference_engine()
            self.engine.set_ocr_skip_when_detections(False)
            self.engine.set_draw_ocr_region(False)
            self.engine.set_ocr_region_normalized(20, .85, .15, .90, .19)
            self.engine.set_ocr_region_normalized(21, 912/1920, 1033/1080, 960/1920, 1070/1080)
            self.engine.set_ocr_region_normalized(22, 150/1920, 252/1080, 410/1920, 290/1080)
            self.engine.set_ocr_region_normalized(23, 802/1920, 977/1080, 890/1920, 1022/1080)
            self.engine.set_ocr_region_normalized(24, 1015/1920, 977/1080, 1115/1920, 1022/1080)
            self.engine.set_ocr_region_normalized(25, 975/1920, 1033/1080, 1027/1920, 1072/1080)
            self.engine.set_ocr_enabled(True)
            self.engine.start()
            self.ocr_priority = None
            self.ready = True
            self.error = ''
        except Exception as exc:
            self.close()
            self.error = 'OCR unavailable: '+str(exc)[:100]

    def read_text(self, box, now):
        if self.engine is None:
            return None
        key = tuple(round(v) for v in box)
        if self.region_key != key:
            self.engine.set_ocr_region_normalized(20, box[0]/1920, box[1]/1080,
                                                 box[2]/1920, box[3]/1080)
            self.region_key = key
            self.region_since = now
            self.ocr_sequence = None
            self.ocr_at = -10
            self.ocr_text = ''
            return None
        from helios import inference
        result = self.engine.get_ocr_result(20)
        settle = .12 if self.coach_active and self.coach_fast else .25
        if now-self.region_since < settle or not result:
            return None
        sequence = result.get('frame_sequence')
        if sequence != self.ocr_sequence:
            self.ocr_sequence = sequence
            if (result.get('status') == inference.OCR_STATUS_READY
                    and result.get('confidence', 0) >= .88 and not result.get('flags', 0)):
                self.ocr_text = result.get('text', '').strip()
                self.ocr_at = now
            else:
                self.ocr_text = ''
                self.ocr_at = -10
        return (sequence, self.ocr_text, now-self.ocr_at)

    def fixed_text(self, region, now):
        if self.engine is None:
            return ''
        from helios import inference
        result = self.engine.get_ocr_result(region)
        cache = self.fixed_ocr.get(region, (None, '', -10))
        if result and result.get('frame_sequence') != cache[0]:
            valid = (result.get('status') == inference.OCR_STATUS_READY and
                     result.get('confidence',0) >= .88 and not result.get('flags',0))
            cache = (result.get('frame_sequence'), result.get('text','').strip() if valid else '', now)
            self.fixed_ocr[region] = cache
        return cache[1] if now-cache[2] < .75 else ''

    def learn_defense(self):
        if self.courts is None:
            return False, 'Waiting for a clear gameplay court view'
        if not self.obs.get('hud') or self.obs.get('pause'):
            return False, 'Learn the court during normal defensive gameplay'
        return self.courts.capture(self.side, self.period)

    def fixed_number(self, region, now, maximum):
        text = self.fixed_text(region, now)
        if self.engine is None or not re.fullmatch(r'\d{1,3}',text):
            return None
        result = self.engine.get_ocr_result(region)
        cached = self.fixed_ocr.get(region)
        if not result or result.get('confidence',0) < .93 or not cached:
            return None
        value = int(text)
        return (cached[0],value,now-cached[2]) if value <= maximum else None

    SYSTEM_TEMPLATES = (('Defense', 'system_defense'), ('Balanced', 'system_balanced'),
                        ('Grit & Grind', 'system_grit_and_grind'), ('Pace & Space', 'system_pace_and_space'),
                        ('Perimeter Centric', 'system_perimeter_centric'),
                        ('Post Centric', 'system_post_centric'), ('Triangle', 'system_triangle'),
                        ('Seven Seconds', 'system_seven_seconds'))

    def score(self, gray, name, box):
        import cv2
        if name not in self.templates:
            template = cv2.imread(str(self.root/(name+'.png')), cv2.IMREAD_GRAYSCALE)
            if template is None:
                raise RuntimeError('Missing video reference: '+name)
            self.templates[name] = template
        x1, y1, x2, y2 = (round(v/2) for v in box)
        crop = gray[y1:y2, x1:x2]
        ref = self.templates[name]
        if crop.shape[0] < ref.shape[0] or crop.shape[1] < ref.shape[1]:
            return 0.0
        return float(cv2.minMaxLoc(cv2.matchTemplate(crop, ref, cv2.TM_CCOEFF_NORMED))[1])

    def system_name(self, gray):
        """Name shown at the top of the System Proficiency lineup panel."""
        scores = sorted(((self.score(gray, ref, (680, 110, 1240, 176)), label)
                         for label, ref in self.SYSTEM_TEMPLATES), reverse=True)
        best, second = scores[0], scores[1]
        if best[0] >= .85 and best[0]-second[0] >= .08:
            return best[1]
        return None

    def match(self, gray, name, box, threshold=.88):
        import cv2
        if name not in self.templates:
            template = cv2.imread(str(self.root/(name+'.png')), cv2.IMREAD_GRAYSCALE)
            if template is None:
                raise RuntimeError('Missing video reference: '+name)
            self.templates[name] = template
        x1, y1, x2, y2 = (round(v/2) for v in box)
        crop = gray[y1:y2, x1:x2]
        ref = self.templates[name]
        if crop.shape[0] < ref.shape[0] or crop.shape[1] < ref.shape[1]:
            return False
        score = cv2.minMaxLoc(cv2.matchTemplate(crop, ref, cv2.TM_CCOEFF_NORMED))[1]
        return score >= threshold

    @staticmethod
    def slider_bars(frame):
        """Knob position of each Coaching Slider as 0-100 of the bar length.

        The white fill ends at the knob, so the right-most white column of the
        bar's centre line is the value. Works on the yellow highlighted row too
        (yellow is not white). Measured on the 1080p recording: 50.1, 99.3,
        2.2, 35.2, 45.4 for 50, 99, 2, 35, 45.
        """
        import numpy as np
        h, w = frame.shape[:2]
        sx, sy = w/1920.0, h/1080.0
        x0, x1 = round(1284*sx), round(1636*sx)
        values = []
        for i in range(6):
            cy = round((183+i*76.8)*sy)
            band = frame[cy-2:cy+3, x0:x1, :3]
            white = (band.min(axis=2) > 190).mean(axis=0) > .6
            xs = np.flatnonzero(white)
            if not len(xs):
                values.append(None)
                continue
            right = (x0+xs[-1])/sx
            # Fit on the true 1080p capture (Oct 31): 2/35/45/50/99 -> right
            # edge 1301/1411/1445/1461/1625 px, i.e. 3.34 px per point.
            values.append(float((right-1294.3)/3.34))
        return values

    @staticmethod
    def yellow(patch):
        import numpy as np
        if patch.size == 0:
            return 0
        b, g, r = patch[:, :, 0], patch[:, :, 1], patch[:, :, 2]
        return float(np.mean((b < 110) & (g > 190) & (r > 190)))

    def scan(self, frame, now):
        if frame is None or not hasattr(frame, 'shape'):
            self.obs = dict(video=False)
            return self.obs
        interval = .03 if self.coach_active and self.coach_fast else .10
        if now-self.checked < interval:
            return self.obs
        self.checked = now
        self.vision_sequence += 1
        self.start(now)
        priority = self.coach_active and self.coach_fast
        if self.engine is not None and self.ocr_priority != priority:
            for region in (21,22,23,24,25):
                self.engine.set_ocr_region_enabled(region, not priority)
            self.ocr_priority = priority
        import cv2
        import numpy as np
        small = cv2.resize(frame[:, :, :3], (960, 540), interpolation=cv2.INTER_AREA)
        gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
        obs = dict(video=True, ready=self.ready, vision_sequence=self.vision_sequence,
                   brightness=float(gray[::4, ::4].mean()))
        obs['dialog'] = obs['brightness'] < 25 and self.dialog(small, gray)
        obs['sliders'] = self.match(gray, 'sliders', (130, 15, 420, 85))
        obs['coach_settings'] = self.match(gray, 'coach_settings_title', (130,15,400,85))
        obs['system_page'] = (not obs['sliders'] and not obs['coach_settings'] and
                              self.match(gray, 'system_title', (130, 15, 460, 85), .85))
        if obs['system_page']:
            obs['system_name'] = self.system_name(gray)
            # "Active:" square beside the lineup: bright green only when the
            # shown system is the active one.
            # 3.9.2: count green pixels at full resolution. The old mean-colour
            # test (G > 170) failed live (mean G ~143 incl. the border), so it
            # kept pressing Make Active for ~4 s after the system was active.
            h, w = frame.shape[:2]
            box = frame[212*h//1080:240*h//1080, 1328*w//1920:1362*w//1920, :3].astype(np.int16)
            green = (box[:, :, 1] > 140) & (box[:, :, 0] < 100) & (box[:, :, 2] < 100)
            obs['system_active'] = bool(green.sum()*(1920.0/w)*(1080.0/h) >= 40)
        obs['pause'] = (not obs['sliders'] and
                        not obs['coach_settings'] and not obs['system_page'] and
                        self.match(gray, 'pause', (580, 10, 780, 70)))
        obs['pregame'] = self.match(gray, 'pregame', (815, 15, 935, 80))
        obs['hud'] = self.match(gray, 'hud', (600, 840, 1320, 1080), .86)
        obs['matchup'] = self.match(gray, 'matchup', (180, 242, 345, 300), .85)
        if obs['sliders']:
            amounts = []
            for i in range(6):
                cy = round((183+i*76.8)/2)
                amounts.append(self.yellow(small[cy-13:cy+13, 415:635]))
            row = int(np.argmax(amounts))
            obs['slider_bars'] = self.slider_bars(frame)
            if amounts[row] > .75:
                obs['slider_row'] = row
                obs['slider_bar'] = obs['slider_bars'][row]
                cy = 183+row*76.8
                # OCR is only a cross-check now; the bar is read every frame.
                obs['ocr'] = self.read_text((1640, cy-20, 1720, cy+20), now)
        elif obs['pause']:
            # 3.7: find the highlighted tile by its dark-on-white LABEL anywhere
            # in the tile row. The old white-outline search failed whenever a
            # bright court or jersey sat behind the menu (5 s stall live).
            rectangles = []
            band = gray[95:185]
            hits = []
            for name, ref in (('Timeout','menu_timeout'),('Gameplan','menu_gameplan'),
                              ('Gameplan','menu_gameplan_alt'),('Game Stats','menu_gamestats')):
                self.score(gray, ref, (0, 0, 2, 2))          # loads the template
                template = self.templates[ref]
                _, best, _, at = cv2.minMaxLoc(cv2.matchTemplate(band, template, cv2.TM_CCOEFF_NORMED))
                hits.append((best, name, at[0]+template.shape[1]/2, at[1]+95))
            hits.sort(reverse=True)
            runner = [v for v, n, _, _ in hits if n != hits[0][1]]
            if hits[0][0] >= .85 and hits[0][0]-(runner[0] if runner else 0) >= .15:
                obs['selected_menu'] = hits[0][1]
                centre, label_y = hits[0][2], hits[0][3]
                # Tile geometry relative to its label (full-resolution pixels).
                rectangles.append((round(centre*2-125), round(label_y*2-140), 250, 182))
            else:
                # Fallback: the raised white tile outline, then OCR of its label.
                white = cv2.inRange(small[60:170], (215, 215, 215), (255, 255, 255))
                contours, _ = cv2.findContours(white, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
                for contour in contours:
                    x, y, w, h = cv2.boundingRect(contour)
                    if 90 < w < 150 and 65 < h < 105:
                        rectangles.append((x*2, (y+60)*2, w*2, h*2))
            if len(rectangles) == 1:
                x, y, w, h = rectangles[0]
                reading = None
                if not obs.get('selected_menu'):
                    reading = self.read_text((x+12, y+h*.69, x+w-12, y+h*.90), now)
                if reading and reading[2] < .7:
                    text = re.sub(r'[^a-z]', '', reading[1].lower())
                    from .engine import MENU_ORDER
                    for name in MENU_ORDER:
                        if text == re.sub(r'[^a-z]', '', name.lower()):
                            obs['selected_menu'] = name
                if obs.get('selected_menu') == 'Gameplan':
                    # Find the actual highlighted bar, then read its text. Never
                    # infer Coaching Sliders merely from a hardcoded row height.
                    sx,sy = max(0,round(x/2)-3),round((y+h)/2)
                    area = small[sy:min(540,sy+135),sx:min(960,sx+round(w/2)+6)]
                    mask = cv2.inRange(area,(0,190,190),(110,255,255))
                    bars,_ = cv2.findContours(mask,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
                    bars = [cv2.boundingRect(c) for c in bars]
                    bars = [(bx,by,bw,bh) for bx,by,bw,bh in bars if bw>w*.38 and 12<bh<35]
                    if len(bars)==1:
                        bx,by,bw,bh=bars[0]
                        box=((sx+bx+4)*2,(sy+by+3)*2,(sx+bx+bw-4)*2,(sy+by+bh-3)*2)
                        refs=(('System Proficiency','submenu_system'),('Coach Settings','submenu_settings'),
                              ('Coaching Sliders','submenu_sliders'),('Coaching Sliders','submenu_sliders_alt'))
                        # Best label wins if it is clearly ahead; a fixed .90
                        # cut-off rejected real highlights (.88) after Back.
                        scored=sorted(((self.score(gray,reference,box),label) for label,reference in refs),reverse=True)
                        runner=[v for v,l in scored if l!=scored[0][1]]
                        if scored[0][0]>=.80 and scored[0][0]-(runner[0] if runner else 0)>=.20:
                            obs['submenu_text']=scored[0][1]
                        if not obs.get('submenu_text'):
                            reading=self.read_text(box,now)
                            if reading and reading[2]<.5:
                                clean=re.sub(r'[^a-z]','',reading[1].lower())
                                for label in ('System Proficiency','Coach Settings','Coaching Sliders','Player Health'):
                                    if clean==re.sub(r'[^a-z]','',label.lower()):obs['submenu_text']=label
                        order=('System Proficiency','Coach Settings','Coaching Sliders','Player Health')
                        if obs.get('submenu_text') in order:obs['submenu_row']=order.index(obs['submenu_text'])
        if obs['matchup']:
            # Platform glyph is present beside the gamertag, absent on AI rows.
            # The supplied recordings establish the Xbox glyph. Unknown glyphs wait.
            rows = []
            for i in range(5):
                cy = 315+i*44.5
                if self.match(gray, 'xbox', (145, cy-14, 175, cy+14), .85):
                    rows.append(i)
                if self.yellow(small[round((cy-12)/2):round((cy+12)/2), 62:169]) > .7:
                    obs['target_highlight'] = i
            if len(rows) == 1:
                obs['human_row'] = rows[0]
        # A court direction is evidence only for the calibrated camera/arena.
        # Unknown views stop setup rather than extrapolating from a shot clock.
        obs['possession'] = 'unknown'
        if self.auto_detection:
            if self.courts is None:
                from .possession import CourtViews
                self.courts = CourtViews(self.root)
            period = None
            if obs['hud']:
                text = self.fixed_text(21, now).lower().replace(' ', '')
                match = re.fullmatch(r'([1-4])(?:st|nd|rd|th)?', text)
                if match:
                    period = int(match[1])
                elif self.match(gray, 'period1', (890,1020,980,1080), .87):
                    period = 1
            self.period = period
            obs['period'] = period
            gameplay = obs['hud'] and not obs['pause'] and not obs['sliders']
            obs['possession'] = self.courts.scan(frame, now, gameplay, self.side, period)
            obs['possession_detail'] = self.courts.details
            if gameplay:
                obs['score_left'] = self.fixed_number(23, now, 999)
                obs['score_right'] = self.fixed_number(24, now, 999)
                obs['shot_clock'] = self.fixed_number(25, now, 24)
            automatic_phase = self.score_start.update(obs, now, self.side)
            self.score_start.message = 'Score-based possession learning is disabled after a live misclassification'
            obs['new_game'] = self.score_start.new_game
            # Live testing showed that a fast turnover after a basket can invert
            # the inferred label. Scores are diagnostics/new-game evidence only;
            # never train court direction from this assumption.
            if automatic_phase:
                self.score_notice = 'Score-based possession learning disabled after a live misclassification'
            automatic_phase = None
            if obs['new_game']:
                self.courts.online_refs.clear()
            if automatic_phase and obs['possession'] in ('unknown',automatic_phase):
                success, notice = self.courts.capture(self.side, period, automatic_phase, automatic=True)
                self.score_notice = notice
                if success:
                    self.courts.checked = -10
                    obs['possession'] = self.courts.scan(frame, now, gameplay, self.side, period)
                    obs['possession_detail'] = self.courts.details+' | '+notice
            elif automatic_phase:
                obs['possession_detail'] += ' | Score cue conflicted with the court; no new view learned'
            elif obs['possession'] == 'unknown':
                obs['possession_detail'] += ' | '+self.score_start.message
            patch = small[147:251, 61:169].astype(np.int16)
            b,g,r = patch[:,:,0],patch[:,:,1],patch[:,:,2]
            flat = (b >= r) & (b-r < 40) & (abs(b-g)<30) & (patch.min(axis=2)>20) & (patch.max(axis=2)<150)
            obs['menu_panel'] = float(np.mean(flat)) > .65
            label = self.fixed_text(22, now).lower()
            obs['defense_menu'] = obs['matchup'] or (obs['menu_panel'] and
                                  any(word in label for word in ('matchup','pressure')))
        self.obs = obs
        return obs
