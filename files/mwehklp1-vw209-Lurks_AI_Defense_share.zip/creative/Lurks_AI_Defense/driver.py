"""Closed-loop Smother, Deny and matchup driver (4.1).

From the Nov 4 21:13 recording (2K27, LB defensive menu, top-left panel):
  LB -> player button -> "<Name> Matchup" panel -> RT -> "Off-Ball Pressure"
  -> RT -> "On-Ball Pressure" -> X = SMOTHER (row 2 turns yellow with a tick)
  -> the panel closes about 0.45 s later.
With 150 ms after X ("Fast Smother" in 3.7/3.8) the next LB arrived while the
panel was still closing and was ignored: only every other player was set and
the matchup step was lost.

Now every player is driven by what is on screen:
  wait until no panel is showing (and 0.5 s after the last X)
  LB, player button, then WAIT until the panel is seen open
  RT, RT, X, then WAIT until row 2 shows SMOTHER selected (yellow)
  no panel within 1.3 s, or no SMOTHER confirmation -> that player is retried
  (up to 3 tries). X is never sent unless the panel was seen open, so a
  stray X (steal attempt) cannot go out on the court.
"""
from pathlib import Path

PANEL_TITLE_BOX = (110, 236, 350, 310)   # full-resolution (1920x1080) pixels
ROW2_BOX = (125, 342, 335, 380)          # second row: SMOTHER / DENY / 2nd name
# 3.9.1: the panel opens on YOUR team's side of the screen. Away (Oct 31 / Nov 4
# Thunder game): top-left. Home (Nov 4 Heat game): top-right, mirrored.
SIDES = {'left': (PANEL_TITLE_BOX, ROW2_BOX),
         'right': ((1920-350, 236, 1920-110, 310), (1920-335, 342, 1920-125, 380))}
PANEL_MIN = 0.62
PAGE_MARGIN = 0.02      # Off-Ball vs On-Ball title: 0.988 vs 0.936 (Nov 4 recording)
ICON_MIN = 0.70         # LB player icons: 0.76-0.93 shown, <= 0.64 otherwise
ICON_WAIT = 0.70
PAGE_WAIT = 0.60
X_WINDOW = 3.0          # 4.5: X (the shot button) only in the first 3 s of a defense
AFTER_X = 0.50          # the panel needs ~0.45 s to close after a selection
OPEN_TIMEOUT = 1.30
SELECT_TIMEOUT = 1.20
CLOSE_TIMEOUT = 2.00
MAX_TRIES = 4


class MenuReader:
    """Reads the LB defensive panel. About 0.3 ms per frame (two small crops)."""

    def __init__(self, root):
        self.root = Path(root)
        self.templates = None
        self.state = dict(panel=None, selected=None, at=-10.0, seq=0, side=None,
                          page=None, icons=False)
        self.error = ''
        self.want_icons = False   # set while a driver waits for the LB icons
        self.icon_templates = None
        self.side = None      # 'left' | 'right' once a panel has been seen
        self.seen = False

    def _load(self):
        import cv2
        self.templates = {}
        for key, name in (('matchup', 'lb_matchup'), ('pressure', 'lb_onball'),
                          ('pressure_off', 'lb_offball')):
            image = cv2.imread(str(self.root/(name+'.png')), cv2.IMREAD_GRAYSCALE)
            if image is None:
                raise RuntimeError('missing '+name+'.png')
            self.templates[key] = image

    def _panel(self, frame, side):
        import cv2
        h, w = frame.shape[:2]
        sx, sy = w/1920.0, h/1080.0
        (x1, y1, x2, y2), _ = SIDES[side]
        crop = frame[round(y1*sy):round(y2*sy), round(x1*sx):round(x2*sx), :3]
        gray = cv2.cvtColor(cv2.resize(crop, ((x2-x1)//2, (y2-y1)//2), interpolation=cv2.INTER_AREA),
                            cv2.COLOR_BGR2GRAY)
        scores = {}
        for key, template in self.templates.items():
            if gray.shape[0] >= template.shape[0] and gray.shape[1] >= template.shape[1]:
                scores[key] = float(cv2.minMaxLoc(cv2.matchTemplate(gray, template, cv2.TM_CCOEFF_NORMED))[1])
        best = max(scores, key=scores.get) if scores else None
        self._page = None
        if not best or scores[best] < PANEL_MIN:
            return None
        # "Matchup" scores 0.86-1.00 against 0.73-0.77 for the pressure titles;
        # the two pressure titles look alike (0.99 vs 0.94-0.96).
        if best == 'matchup' and scores['matchup']-max(scores['pressure'], scores['pressure_off']) >= .05:
            return 'matchup'
        if scores['pressure_off']-scores['pressure'] >= PAGE_MARGIN:
            self._page = 'offball'
        elif scores['pressure']-scores['pressure_off'] >= PAGE_MARGIN:
            self._page = 'onball'
        return 'pressure'

    def _icons(self, frame):
        """The LB player icons (black discs with A / X / Y over your teammates)."""
        import cv2
        if self.icon_templates is None:
            self.icon_templates = []
            for name in ('lb_icon_a', 'lb_icon_x', 'lb_icon_y'):
                image = cv2.imread(str(self.root/(name+'.png')), cv2.IMREAD_GRAYSCALE)
                if image is not None:
                    self.icon_templates.append(image)
        if len(self.icon_templates) < 2:
            return False
        small = cv2.resize(frame[:, :, :3], (960, 540), interpolation=cv2.INTER_AREA)
        gray = cv2.cvtColor(small[20:380], cv2.COLOR_BGR2GRAY)
        hits = sum(cv2.minMaxLoc(cv2.matchTemplate(gray, t, cv2.TM_CCOEFF_NORMED))[1] >= ICON_MIN
                   for t in self.icon_templates)
        return hits >= 2

    def _selected(self, frame, side):
        import numpy as np
        h, w = frame.shape[:2]
        sx, sy = w/1920.0, h/1080.0
        _, (x1, y1, x2, y2) = SIDES[side]
        row = frame[round(y1*sy):round(y2*sy), round(x1*sx):round(x2*sx), :3].astype(np.int16)
        yellow = ((row[:, :, 0] < 110) & (row[:, :, 1] > 180) & (row[:, :, 2] > 180)).mean()
        if yellow <= .5:
            return None
        # Selected text is dark on yellow: tick + glyph + SMOTHER spans ~90 px
        # at 1080p; DENY is far shorter.
        dark = (row.mean(axis=2) < 70).mean(axis=0) > .12
        columns = np.flatnonzero(dark)
        span = (columns[-1]-columns[0])/sx if len(columns) else 0
        return 'smother' if span >= 70 else 'other'

    def read(self, frame, now):
        if frame is None or not hasattr(frame, 'shape'):
            return self.state
        try:
            if self.templates is None:
                self._load()
            panel = side = None
            self._page = None
            # Check the side it was last seen on first, then the other one.
            order = [self.side] if self.side else []
            order += [name for name in ('left', 'right') if name not in order]
            for name in order:
                panel = self._panel(frame, name)
                if panel:
                    side = name
                    break
            selected = self._selected(frame, side) if panel else None
            page = self._page if panel == 'pressure' else None
            icons = bool(self.want_icons and not panel and self._icons(frame))
            if side:
                self.side = side
                self.seen = True
            self.state = dict(panel=panel, selected=selected, at=now, seq=self.state['seq']+1,
                              side=side, seen=self.seen, page=page, icons=icons)
        except Exception as exc:     # never break controller output
            self.error = str(exc)[:120]
        return self.state


class Taps:
    def __init__(self):
        self.queue = []
        self.until = None

    def add(self, button, seconds):
        self.queue.append((button, seconds))

    @property
    def busy(self):
        return bool(self.queue)

    def tick(self, now):
        while self.queue:
            if self.until is None:
                self.until = now+self.queue[0][1]
            if now < self.until:
                return self.queue[0][0]
            self.queue.pop(0)
            self.until = None
        return None

    def clear(self):
        self.queue = []
        self.until = None


class SmotherDriver:
    """4.1: every button that could act on the court waits for proof on screen.

    LB -> wait for the player icons -> player button -> wait for the panel ->
    RT (Off-Ball page) [-> RT (On-Ball page)] -> wait until a NEW frame shows
    that page still open -> X. If the panel closes on the way (missed shot,
    rebound, steal) nothing more is pressed, so X can no longer go out as a
    shot. Jobs: Smother (On-Ball, X) for every player; Deny (Off-Ball, X) runs as
    its own pass after the matchup switch.
    """

    def __init__(self, players, defender_trigger='LT', deny=False, only_deny=False, icon_mode='unknown'):
        self.jobs = [] if only_deny else [(p, 'smother') for p in players]
        if deny or only_deny:
            self.jobs += [(p, 'deny') for p in players]
        self.players = [p if kind == 'smother' else p+' deny' for p, kind in self.jobs]
        self.index = 0
        self.tries = 0
        self.phase = 'ready'
        self.taps = Taps()
        self.last_x = -10.0
        self.phase_at = None
        self.deadline = 0.0
        self.sent_at = 0.0
        self.message = ''
        self.failed = []
        self.trigger = defender_trigger
        self._now = 0.0
        self.lb_at = 0.0
        self.events = []
        self.icon_mode = icon_mode   # 'works' once icons were seen before a panel
        self.icons_seen = False
        self.extra_rt = False
        self.gone = 0

    @property
    def complete(self):
        return self.index >= len(self.jobs)

    @property
    def in_menu(self):
        return self.phase not in ('ready',)

    @property
    def wants_icons(self):
        return self.phase == 'icons'

    def _job(self):
        player, kind = self.jobs[self.index]
        return player, kind, ('Smother' if kind == 'smother' else 'Deny')

    def _reset_phase(self):
        self.taps.clear()
        self.phase = 'ready'
        self.phase_at = None

    def restart_player(self):
        # Interrupted mid-player: the LB player icons may still be up, and a
        # second LB would close them so the player button lands on the court.
        # Give them time to clear first.
        if self.phase != 'ready' or self.taps.busy:
            self.last_x = max(self.last_x, self._now+1.0)
        self.taps.clear()
        self.phase = 'ready'
        self.phase_at = None

    def _next(self, ok):
        if not ok:
            self.failed.append(self.players[self.index])
        self.index += 1
        self.tries = 0
        self._reset_phase()

    def _retry(self, reason):
        self.tries += 1
        self.message = '%s (try %d/%d)' % (reason, self.tries, MAX_TRIES)
        if self.tries >= MAX_TRIES:
            self._next(False)
        else:
            self._reset_phase()

    def _lost(self, why):
        """The menu went away before X: probably a change of possession."""
        self.events.append(('no_open', self.lb_at))
        self.message = 'Player %d: %s - nothing else pressed' % (self.index+1, why)
        self.last_x = max(self.last_x, self._now+.6)
        self._reset_phase()

    def tick(self, menu, now):
        self._now = now
        button = self.taps.tick(now)
        if button is not None or self.taps.busy or self.complete:
            return button
        player, kind, label = self._job()
        fresh = menu['at'] > self.sent_at+0.02
        trigger = player == self.trigger
        risk = menu.get('shot_risk', False)     # 4.2: ball near the rim
        if self.phase == 'ready':
            if self.phase_at is None:
                self.phase_at = now
            if now-self.last_x < AFTER_X:
                return None
            if risk:
                self.message = 'Player %d/%d: waiting - ball near the rim' % (self.index+1, len(self.jobs))
                return None
            if player == 'X' and menu.get('window_age', 0) > X_WINDOW:
                # Too late in this possession for the X button (a rebound now
                # would turn it into a shot): do another player first.
                later = next((j for j in range(self.index+1, len(self.jobs)) if self.jobs[j][0] != 'X'), None)
                if later is None:
                    self.message = 'X player waits for the start of the next defense'
                    return None
                self.jobs[self.index], self.jobs[later] = self.jobs[later], self.jobs[self.index]
                self.players[self.index], self.players[later] = self.players[later], self.players[self.index]
                return None
            if menu['panel'] and menu['at'] > now-.3:
                if now-self.phase_at > CLOSE_TIMEOUT:
                    # A panel has been open for 2 s: close it with B (menus
                    # consume B, so this is not a court action).
                    self.taps.add('B', .08)
                    self.taps.add(None, .30)
                    self.phase_at = now
                return None
            self.lb_at = now
            self.taps.add('LB', .08)
            self.phase = 'icons'
            self.icons_seen = False
            self.sent_at = now+.08
            self.deadline = self.sent_at+ICON_WAIT
            self.message = 'Player %d/%d: %s - opening menu' % (self.index+1, len(self.jobs), label)
            return self.taps.tick(now)
        if self.phase == 'icons':
            # 4.1.1: the icon check never blocks (live, it missed icons that
            # were there and Smother stalled at 2/5). The player button goes
            # out on the old timing; for X (the shot button) it waits up to
            # 0.6 s for the icons first.
            seen = fresh and menu.get('icons')
            if seen:
                self.icons_seen = True
            if risk:
                # A shot went up after LB: do not send the player button.
                # Let the icons close by themselves, then start this player again.
                self.message = 'Player %d: shot in the air - player button not sent' % (self.index+1)
                self.last_x = max(self.last_x, now+1.6)
                self._reset_phase()
                return None
            # 4.2.1: back to the 4.0 timing for every button. Waiting longer
            # for X (4.1.1) let the LB icons close first, so X became a shot.
            wait = .35 if trigger else .20
            if now >= self.lb_at+.08+wait:
                self.taps.add(player, .20 if trigger else .08)
                self.phase = 'open'
                self.sent_at = now+(.20 if trigger else .08)
                self.deadline = self.sent_at+OPEN_TIMEOUT
                return self.taps.tick(now)
            return None
        if self.phase == 'open':
            if fresh and menu['panel'] in ('matchup', 'pressure'):
                self.events.append(('opened', self.lb_at))
                if self.icons_seen:
                    self.icon_mode = 'works'
                elif self.icon_mode == 'unknown':
                    self.icon_mode = 'off'      # icons not readable here: old timing
                self.taps.add('RT', .06)
                if kind == 'smother':
                    self.taps.add(None, .11)
                    self.taps.add('RT', .06)
                self.phase = 'page'
                self.extra_rt = False
                self.gone = 0
                self.sent_at = now+(.23 if kind == 'smother' else .06)
                self.deadline = self.sent_at+PAGE_WAIT
                self.message = 'Player %d/%d: %s - checking the page' % (self.index+1, len(self.jobs), label)
                return self.taps.tick(now)
            if now > self.deadline:
                # On offense LB shows play-call icons and no matchup panel
                # opens (Nov 4 Heat game, 6.3 s). The caller treats this as
                # "probably offense" and waits for the next defense.
                self.events.append(('no_open', self.lb_at))
                if menu.get('seen'):
                    # The reader works in this game, so this was offense, not
                    # a failed try: do not use up this player's tries.
                    self.message = 'Player %d: menu did not open (offense?)' % (self.index+1)
                    self._reset_phase()
                else:
                    self._retry('Player %d menu did not open' % (self.index+1))
            return None
        if self.phase == 'page':
            if not fresh:
                return None
            if not menu['panel']:
                # Two new frames in a row without the panel: it closed.
                self.gone += 1
                if self.gone >= 2:
                    self._lost('menu closed before X')
                return None
            self.gone = 0
            if risk:
                # Ball near the rim: X waits (capped by the guard) while the
                # panel stays open; if it closes, nothing is pressed.
                self.deadline = max(self.deadline, now+.3)
                self.message = 'Player %d: X waits - ball near the rim' % (self.index+1)
                return None
            want = 'onball' if kind == 'smother' else 'offball'
            page = menu.get('page')
            ok = menu['panel'] == 'pressure' and (page == want or (page is None and now > self.deadline-.3))
            if ok:
                # A NEW frame shows the right page open right now: X is safe.
                self.taps.add('X', .06)
                self.phase = 'select'
                self.last_x = now+.06
                self.sent_at = now+.06
                self.deadline = self.sent_at+SELECT_TIMEOUT
                self.message = 'Player %d/%d: selecting %s' % (self.index+1, len(self.jobs), label)
                return self.taps.tick(now)
            if kind == 'smother' and page == 'offball' and not self.extra_rt and now > self.sent_at+.25:
                self.extra_rt = True            # the second RT was dropped
                self.taps.add('RT', .06)
                self.sent_at = now+.06
                return self.taps.tick(now)
            if now > self.deadline:
                self.taps.add('B', .08)         # close the panel, try again later
                self.taps.add(None, .30)
                self._retry('Player %d: %s page not reached' % (self.index+1, label))
            return None
        if self.phase == 'select':
            # Row 2 on the Off-Ball page is only ever DENY, so any yellow row-2
            # highlight there confirms it (its text width was never measured).
            want = 'smother' if kind == 'smother' else menu['selected']
            if fresh and menu['selected'] and menu['selected'] == want:
                self.message = 'Player %d/%d: %s confirmed' % (self.index+1, len(self.jobs), label)
                self._next(True)
                return None
            if fresh and menu['selected'] and menu['selected'] != want:
                self._retry('Player %d: a different option was selected' % (self.index+1))
                return None
            if now > self.deadline:
                self._retry('Player %d: %s not confirmed' % (self.index+1, label))
            return None
        return None


class MatchupDriver:
    """LB -> your defender -> (panel seen) -> opponent row button -> closed."""

    def __init__(self, defender, target, trigger='LT', icon_mode='unknown'):
        self.defender, self.target, self.trigger = defender, target, trigger
        self.icon_mode = icon_mode
        self.icons_seen = False
        self.phase = 'ready'
        self.taps = Taps()
        self.tries = 0
        self.phase_at = None
        self.sent_at = 0.0
        self.deadline = 0.0
        self.result = None       # 'ok' | 'failed'
        self.message = ''
        self.hold_until = 0.0
        self._now = 0.0
        self.lb_at = 0.0
        self.events = []

    @property
    def complete(self):
        return self.result is not None

    @property
    def wants_icons(self):
        return self.phase == 'icons'

    def restart(self):
        if self.phase != 'ready' or self.taps.busy:
            self.hold_until = self._now+1.6
        self.taps.clear()
        self.phase = 'ready'
        self.phase_at = None

    def _retry(self, reason):
        self.tries += 1
        self.message = '%s (try %d/%d)' % (reason, self.tries, MAX_TRIES)
        if self.tries >= MAX_TRIES:
            self.result = 'failed'
        else:
            self.taps.clear()
            self.phase = 'ready'
            self.phase_at = None

    def tick(self, menu, now):
        self._now = now
        button = self.taps.tick(now)
        if button is not None or self.taps.busy or self.complete:
            return button
        fresh = menu['at'] > self.sent_at+0.02
        risk = menu.get('shot_risk', False)
        if self.phase == 'ready':
            if self.phase_at is None:
                self.phase_at = now
            if now < self.hold_until:
                return None
            if risk:
                self.message = 'Matchup: waiting - ball near the rim'
                return None
            if self.defender == 'X' and menu.get('window_age', 0) > X_WINDOW:
                self.message = 'Matchup (X button) waits for the start of the next defense'
                return None
            if menu['panel'] and menu['at'] > now-.3:
                if now-self.phase_at > CLOSE_TIMEOUT:
                    self.taps.add('B', .08)
                    self.taps.add(None, .30)
                    self.phase_at = now
                return None
            self.lb_at = now
            self.taps.add('LB', .08)
            self.phase = 'icons'
            self.icons_seen = False
            self.sent_at = now+.08
            self.deadline = self.sent_at+ICON_WAIT
            self.message = 'Matchup: opening your defender'
            return self.taps.tick(now)
        if self.phase == 'icons':
            # 4.1.1: never blocks; old timing, up to 0.6 s extra for X.
            trigger = self.defender == self.trigger
            seen = fresh and menu.get('icons')
            if seen:
                self.icons_seen = True
            if risk:
                self.message = 'Matchup: shot in the air - defender button not sent'
                self.hold_until = now+1.6
                self.taps.clear()
                self.phase = 'ready'
                self.phase_at = None
                return None
            wait = .35 if trigger else .20          # 4.2.1: 4.0 timing
            if now >= self.lb_at+.08+wait:
                self.taps.add(self.defender, .20 if trigger else .08)
                self.phase = 'open'
                self.sent_at = now+(.20 if trigger else .08)
                self.deadline = self.sent_at+OPEN_TIMEOUT
                return self.taps.tick(now)
            return None
        if self.phase == 'open':
            if fresh and menu['panel'] == 'matchup' and risk:
                self.deadline = max(self.deadline, now+.3)   # pick waits for the ball
                return None
            if fresh and menu['panel'] == 'matchup':
                self.events.append(('opened', self.lb_at))
                if self.icons_seen:
                    self.icon_mode = 'works'
                self.taps.add(self.target, .06)
                self.phase = 'close'
                self.sent_at = now+.06
                self.deadline = self.sent_at+CLOSE_TIMEOUT
                self.message = 'Matchup: picking the opponent'
                return self.taps.tick(now)
            if now > self.deadline:
                self.events.append(('no_open', self.lb_at))
                if menu.get('seen'):
                    self.message = 'Matchup menu did not open (offense?)'
                    self.taps.clear()
                    self.phase = 'ready'
                    self.phase_at = None
                else:
                    self._retry('Matchup menu did not open')
            return None
        if self.phase == 'close':
            if fresh and menu['panel'] is None:
                self.result = 'ok'
                self.message = 'Matchup set (menu closed after the pick)'
            elif now > self.deadline:
                self._retry('Matchup menu did not close after the pick')
            return None
        return None
