"""Recipient sign-in window. Requests identity only; never asks for a Discord password."""
import json
from pathlib import Path
import queue
import threading
import tkinter as tk
from tkinter import messagebox
import discord_identity

root_path = Path(__file__).resolve().parent
root = tk.Tk()
root.title('Lurks AI Defense | Sign in with Discord')
root.geometry('530x310')
root.resizable(False, False)
root.configure(bg='#101116')
tk.Label(root, text='Lurks AI Defense', bg='#101116', fg='#f1f1f6',
         font=('Segoe UI', 21, 'bold')).pack(anchor='w', padx=28, pady=(28, 8))
tk.Label(root, text='Use your Discord account to verify lifetime access.\nNo PC IDs. No license keys.',
         bg='#101116', fg='#9da2b4', justify='left', font=('Segoe UI', 11)).pack(anchor='w', padx=28)
status = tk.StringVar(value='Your browser opens for Discord’s own sign-in page.')
tk.Label(root, textvariable=status, wraplength=470, justify='left', bg='#101116',
         fg='#b8a0ff', font=('Segoe UI', 10)).pack(anchor='w', padx=28, pady=20)
events = queue.Queue()
busy = False

def start():
    global busy
    if busy: return
    busy = True
    button.configure(state='disabled')
    status.set('Finish authorizing Lurks AI Defense in your browser…')
    def worker():
        try:
            config = json.loads((root_path / 'access_config.json').read_text(encoding='utf-8'))
            events.put((True, discord_identity.login(config.get('discord_client_id', ''))))
        except Exception as exc:
            events.put((False, str(exc)))
    threading.Thread(target=worker, daemon=True).start()

def poll():
    global busy
    try:
        ok, result = events.get_nowait()
        busy = False
        button.configure(state='normal')
        status.set(('Signed in as @' + result['username'] + '.\nYour Discord ID: ' + result['id'] +
                    '\nSend that Discord ID to Lurk for approval, then load the script.') if ok else result)
    except queue.Empty:
        pass
    root.after(100, poll)

def close():
    if busy:
        messagebox.showinfo('Sign-in in progress', 'Finish or cancel sign-in in your browser, or wait for it to time out.', parent=root)
    else:
        root.destroy()

button = tk.Button(root, text='Sign in with Discord', command=start, bg='#b8a0ff', fg='#211a33',
                   activebackground='#c9b6ff', font=('Segoe UI', 11, 'bold'), relief='flat', padx=18, pady=10)
button.pack(anchor='w', padx=28)
root.protocol('WM_DELETE_WINDOW', close)
root.after(100, poll)
root.mainloop()
