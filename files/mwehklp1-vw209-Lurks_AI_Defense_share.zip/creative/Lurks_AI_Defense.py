"""Lurks AI Defense 4.0 - Confirmed Smother, every game (simple panel, access list).

Per game, automatically:
  1. Coach sliders + System Proficiency as soon as the "Ready!" lineup screen
     is gone (before the tip-off).
  2. Smother for all five on your first confirmed defense. Each player's LB
     menu is watched on screen: the panel must open before RT/RT/X are sent,
     and SMOTHER must show as selected, otherwise that player is retried.
  3. Your AI defender -> opponent matchup, confirmed the same way.
  4. Waits for the next game's lineup screen and starts over by itself
     (no Creative reload needed).
Offense/defense: learned from the first basket (or your L3+R3 on defense);
inputs stop on offense and continue on defense from the same player.

Controls (hold L3 as the modifier):
  L3+R3    start now (you are defending) / pause / resume
  L3+Up    centre (LT) only          L3+Down  cancel this game's run
  L3+Left  matchup only              L3+Right retry coaching
Access: verified Discord account approval (see START HERE.txt).
Keep the matching Lurks_AI_Defense folder beside this file.
"""

from time import monotonic
import importlib.util
import json
import sys
import weakref
from pathlib import Path

from creative_helper import Combo
from helios import controls

NAME = "Lurks AI Defense"
VERSION = "4.8 Shot clock"
ROOT = Path(__file__).resolve().with_suffix('')

LB = controls.BUTTON_7       # PS5 L1
RB = controls.BUTTON_4       # PS5 R1
RT = controls.BUTTON_5       # PS5 R2
LT = controls.BUTTON_8       # PS5 L2
A = controls.BUTTON_16       # PS5 Cross
X = controls.BUTTON_17       # PS5 Square
B = controls.BUTTON_15       # PS5 Circle
Y = controls.BUTTON_14       # PS5 Triangle
L3 = controls.BUTTON_9
R3 = controls.BUTTON_6
DOWN = controls.BUTTON_11
UP = controls.BUTTON_10
LEFT = controls.BUTTON_12
RIGHT = controls.BUTTON_13
START = controls.BUTTON_3

BUTTONS = dict(LB=LB, RB=RB, RT=RT, LT=LT, A=A, X=X, B=B, Y=Y)
MENU_BUTTONS = tuple(BUTTONS.values())
PLAYERS = ('LT', 'A', 'X', 'B', 'Y')             # C, PG, SF, SG, PF icon buttons
DEFENDER_KEYS = dict(PG='A', SG='B', SF='X', PF='Y', C='LT')
# Matchup panel rows (2K27 recording): A, X, Y, LB, RB from top to bottom.
TARGET_KEYS = dict(PG='A', SG='X', SF='Y', PF='LB', C='RB')
COACH_KEYS = dict(START=START, RB=RB, RT=RT, LB=LB, LT=LT, UP=UP, DOWN=DOWN, LEFT=LEFT,
                  RIGHT=RIGHT, Y=Y, B=B, A=A, X=X,
                  SLIDER_LEFT=controls.STICK_2_X, SLIDER_RIGHT=controls.STICK_2_X)
RESUME_DELAY = 0.5      # seconds of confirmed defense before inputs continue
NEW_GAME_CHECK = 1.0    # seconds between lineup-screen checks once finished

combo = Combo()
_settings = dict(smother_enabled=True, matchup_enabled=True,
                 opponent_position='Choose opponent position', defender='SF',
                 team='Chicago Bulls', team_type='All-Time', preview=True,
                 coach_enabled=False, coach_auto=True, coach_fast=True,
                 defense_auto=True, coach_system='Off', smother_fast=False, own_side='Away',
                 deny_enabled=True)
_settings_at = -10.0
_stamp = None


def _load(name, filename):
    spec = importlib.util.spec_from_file_location(name, ROOT/filename)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


_driver_module = _load('_lurks_ai_defense_driver_400', 'driver.py')
# 4.8: the 24 s shot clock on the scoreboard. It jumps back to 24 the moment
# the ball hits the rim or changes hands -> Smother/Deny stop right there.
# (Replaces the Helios ball detection and the name-tag icons.)
_clock = _load('_lurks_ai_defense_shotclock_480', 'shotclock.py').ShotClock(ROOT)
_access = _load('_lurks_ai_defense_access_400', 'access.py').Access(ROOT)
_access_was = None          # last state reported, so the message prints once


def _show_access_id():
    """Discord sign-in replaces the former PC ID display."""
    pass


_show_access_id()


def _access_gate():
    """True when this PC may use the script. Otherwise nothing is pressed."""
    global _access_was, _mode, _driver, _matchup
    ok = _access.allowed()
    if _access.state != _access_was:
        _access_was = _access.state
        if not ok and _mode != 'idle':
            _release()
            if _coach and _coach.busy:
                _coach.emergency()
                _close_coach()
            _driver = _matchup = None
            _mode = 'idle'
        if _access.state != 'checking' or not ok:
            _report(_access.message(), force=True)
    return ok


def _new_game_state():
    """Everything that belongs to one game. Replaced at every lineup screen."""
    global _mode, _driver, _matchup, _side, _menu, _coach, _cv, _coach_done
    global _coach_was_busy, _coach_finalizer, _manual_coach_requested, _auto_blocked
    global _coach_report_state, _last_report, _finished_at, _game_no
    _mode = 'idle'            # idle | running | paused | auto_paused | matchup | done
    _driver = None
    _matchup = None
    _side = None
    _menu = _driver_module.MenuReader(ROOT)
    if '_cv' in globals() and _cv is not None:
        _cv.close()
    _coach = _cv = None
    _coach_done = False
    _coach_was_busy = False
    _coach_finalizer = None
    _manual_coach_requested = False
    _auto_blocked = False
    _coach_report_state = None
    if '_miss_hold' in globals():
        _miss_hold[0] = None
    if '_detected_side' in globals():
        _detected_side[0] = None
    if '_deny_after' in globals():
        _deny_after[0] = None
    if '_window_start' in globals():
        _window_start[0] = None
    _last_report = None
    _finished_at = None
    if '_clock' in globals():
        _clock.new_game()
    _game_no = globals().get('_game_no', 0)+1


_last_message = None
_previous = dict(toggle=False, center=False, left=False, right=False, reset=False)
_pregame_template = None
_pregame_checked = -10.0
_pregame_seen = False
_new_game_state()


# --------------------------------------------------------------- reporting
def _report(message, force=False):
    global _last_message
    if message == _last_message and not force:
        return
    _last_message = message
    print('[Lurks AI Defense] '+message)
    try:
        path = ROOT/'status.json'
        temp = ROOT/'status.tmp'
        temp.write_text(json.dumps(dict(
            version=VERSION, game=_game_no, mode=_mode, message=message,
            smother=None if _driver is None else dict(
                players_done=_driver.index, total=len(_driver.players),
                failed=_driver.failed, step=_driver.message),
            matchup=None if _matchup is None else dict(result=_matchup.result, step=_matchup.message),
            menu_reader=dict(panel=_menu.state.get('panel'), selected=_menu.state.get('selected'),
                             error=_menu.error),
            possession_detection=_side.summary() if _side else 'not started',
            shot_clock=_clock.summary(monotonic()),
            coach_state=_coach.state if _coach else 'not_started',
            coach_message=_coach.message if _coach else None,
            coach_done=_coach_done,
            coach_timeline=list(getattr(_coach, 'timeline', []) or []), coach_verified=sorted(_coach.verified) if _coach else []), indent=2), encoding='utf-8')
        temp.replace(path)
    except OSError:
        pass


def _refresh_settings(now):
    global _stamp, _settings_at
    if now-_settings_at < 1 or _mode in ('running', 'matchup') or (_coach and _coach.busy):
        return
    _settings_at = now
    try:
        path = ROOT/'module.json'
        stamp = path.stat().st_mtime_ns
        if stamp == _stamp:
            return
        raw = json.loads(path.read_text(encoding='utf-8'))
        for key, default in tuple(_settings.items()):
            if type(raw.get(key)) is type(default):
                _settings[key] = raw[key]
        # 4.0 panel: "Set system + coaching sliders" means at every game, fast.
        _settings['coach_auto'] = _settings['coach_fast'] = True
        _stamp = stamp
    except (OSError, ValueError):
        pass


# ------------------------------------------------------------------ helpers
def _ensure_side():
    global _side
    if _side is None:
        _side = _load('_lurks_ai_defense_side_400', 'side.py').SideTracker(ROOT)
    return _side


def _calibrate(now):
    if _settings['defense_auto']:
        _ensure_side().request_calibration(now)


def _ensure_coach():
    global _coach, _cv
    if _coach is not None:
        return
    name = '_lurks_ai_defense_coach_400'   # new name: never reuse cached older modules
    spec = importlib.util.spec_from_file_location(name, ROOT/'__init__.py',
                                                  submodule_search_locations=[str(ROOT)])
    package = importlib.util.module_from_spec(spec)
    sys.modules[name] = package
    _miss_hold[0] = None            # you said "defense now": no waiting
    spec.loader.exec_module(package)
    _coach = package.Setup(ROOT)
    _cv = package.Vision(ROOT)
    _cv.auto_detection = False
    _cv.coach_active = True
    _cv.coach_fast = True


def _close_coach():
    global _coach_done, _coach_finalizer
    if _cv is not None:
        _cv.close()
    if _coach_finalizer is not None and _coach_finalizer.alive:
        _coach_finalizer.detach()
    _coach_finalizer = None
    _coach_done = True


def _release():
    for button in MENU_BUTTONS:
        combo.set_val(button, 0)


# 4.4.1: every button the script sends is written to press_log.json with what
# the script believed at that moment, so a stray shot can be traced exactly.
CAPTURE_LIMIT = 0           # 4.5.1: off (saving pictures slowed the frame loop)
_capture = [0, [], '']      # [sequences saved, pending times, name]
_press_log = []
_press_prev = [None]
_press_saved = [0.0, False]


def _log_press(name):
    try:
        import time as _t
        now, wall = monotonic(), _t.time()
        drv = _driver if _mode == 'running' else (_matchup if _mode == 'matchup' else None)
        job = None
        if _mode == 'running' and drv is not None and not drv.complete:
            job = drv.players[drv.index]
        elif _mode == 'matchup':
            job = 'matchup'
        _press_log.append(dict(
            t=_t.strftime('%H:%M:%S', _t.localtime(wall))+'.%02d' % int((wall % 1)*100),
            button=name, mode=_mode, job=job, step=getattr(drv, 'phase', None),
            court=_side.state if _side else None,
            defense_s=round(_side.defense_for(now), 1) if _side else None,
            panel=_menu.state.get('panel'), page=_menu.state.get('page'),
            shot_clock=_clock.value))
        del _press_log[:-400]
        _press_saved[1] = True
        if name == 'LB' and _capture[0] < CAPTURE_LIMIT:
            _capture[1] = [now+.15, now+.30]
            _capture[2] = _press_log[-1]['t'].replace(':', '').replace('.', '_')
    except Exception:
        pass


def _save_press_log(now, force=False):
    if not _press_saved[1] or (not force and now-_press_saved[0] < 1.0):
        return
    _press_saved[0], _press_saved[1] = now, False
    try:
        temp = ROOT/'press_log.tmp'
        temp.write_text('[\n'+',\n'.join(json.dumps(r) for r in _press_log)+'\n]\n', encoding='utf-8')
        temp.replace(ROOT/'press_log.json')
    except OSError:
        pass


def _press(name):
    _release()
    if name != _press_prev[0]:
        _press_prev[0] = name
        if name is not None:
            _log_press(name)
    if name is not None:
        combo.set_val(BUTTONS[name], 100)


def _matchup_targets():
    target = _settings['opponent_position']
    defender = _settings['defender']
    if defender == 'Team preference':
        try:
            profiles = json.loads((ROOT/'profiles.json').read_text(encoding='utf-8'))
            defender = profiles.get(_settings['team_type']+'|'+_settings['team'])
        except (OSError, ValueError):
            defender = None
    if defender not in DEFENDER_KEYS or target not in TARGET_KEYS:
        return None
    return DEFENDER_KEYS[defender], TARGET_KEYS[target], defender, target


_deny_after = [None]      # players still to get Deny (after the matchup switch)


def _start_smother(now, players=PLAYERS, why=''):
    global _driver, _mode
    _driver = _driver_module.SmotherDriver(players)
    _deny_after[0] = tuple(players) if _settings['deny_enabled'] else None
    _mode = 'running'
    _report('Smother started%s: player 1/%d' % (why, len(players)), force=True)


def _start_matchup(now):
    global _matchup, _mode
    picked = _matchup_targets()
    if picked is None:
        _deny_or_finish('Smother done; matchup skipped (choose both positions in the panel)')
        return
    _matchup = _driver_module.MatchupDriver(picked[0], picked[1],
                                            icon_mode=getattr(_driver, 'icon_mode', 'unknown'))
    _mode = 'matchup'
    _report('Matchup: your %s -> opponent %s' % (picked[2], picked[3]), force=True)


def _deny_or_finish(message):
    """4.1: after Smother and the matchup switch, set Off-Ball Deny on everyone."""
    global _driver, _mode
    players, _deny_after[0] = _deny_after[0], None
    if players and _settings['deny_enabled']:
        _driver = _driver_module.SmotherDriver(players, only_deny=True,
                                               icon_mode=getattr(_driver, 'icon_mode', 'unknown'))
        _release()
        _mode = 'running'
        _report(message+' | now setting Deny on %d players' % len(players), force=True)
        return
    _finish(message)


def _finish(message):
    global _mode, _finished_at
    _release()
    _close_coach()
    _mode = 'done'
    _finished_at = monotonic()
    _report(message+' | Done for this game; starts again by itself at the next lineup screen.',
            force=True)


# ------------------------------------------------------------- new game
def _lineup_screen(frame):
    """True on 2K's "Ready!" lineup screen (same reference the coach uses)."""
    global _pregame_template
    try:
        import cv2
        if _pregame_template is None:
            _pregame_template = cv2.imread(str(ROOT/'pregame.png'), cv2.IMREAD_GRAYSCALE)
        h, w = frame.shape[:2]
        # vision.py: pregame.png inside (815,15)-(935,80) of 1080p, at half size
        crop = frame[15*h//1080:80*h//1080, 815*w//1920:935*w//1920, :3]
        gray = cv2.cvtColor(cv2.resize(crop, (60, 33), interpolation=cv2.INTER_AREA), cv2.COLOR_BGR2GRAY)
        return cv2.minMaxLoc(cv2.matchTemplate(gray, _pregame_template, cv2.TM_CCOEFF_NORMED))[1] >= .85
    except Exception:
        return False


def _watch_for_new_game(frame, now):
    global _pregame_checked, _pregame_seen
    if frame is None or not hasattr(frame, 'shape') or now-_pregame_checked < NEW_GAME_CHECK:
        return
    _pregame_checked = now
    seen = _lineup_screen(frame)
    fresh = (_mode == 'idle' and _driver is None and not _coach_done
             and not (_coach and _coach.busy) and not (_side and _side.calibrated))
    if seen and not _pregame_seen and not fresh:
        _new_game_state()
        _report('New game (lineup screen): coaching, Smother and matchup will run again', force=True)
    _pregame_seen = seen


# ------------------------------------------------------------------- scan
def scan(button_bytes, stick_bytes, **kwargs):
    global _coach_finalizer
    frame = kwargs.get('frame')
    now = monotonic()
    if _access.state != 'approved' and _access.state != 'open':
        return                      # not activated: no vision work at all
    _watch_for_new_game(frame, now)
    if _mode == 'done':
        return                      # only the 1 s lineup check runs
    _save_press_log(now)
    if _capture[1] and now >= _capture[1][0] and frame is not None:
        _capture[1].pop(0)
        try:
            import cv2
            folder = ROOT/'captures'
            folder.mkdir(exist_ok=True)
            small = cv2.resize(frame[:, :, :3], (1280, 720), interpolation=cv2.INTER_AREA)
            cv2.imwrite(str(folder/('lb_%s_%d.jpg' % (_capture[2], 2-len(_capture[1])))), small,
                        [cv2.IMWRITE_JPEG_QUALITY, 88])
        except Exception:
            _capture[1] = []
        if not _capture[1]:
            _capture[0] += 1
    if _settings['defense_auto'] and _settings['smother_enabled']:
        # 4.0.3: set your side before every scan. It used to be set only by
        # _auto(), which does not run while coaching waits for a pause, so
        # baskets scored meanwhile were read as "Away" even for Home games.
        _ensure_side().own_side = _own_side()
        _side.scan(frame, now)
        _clock.scan(frame, now)      # 4.8: shot clock (tiny box, ~0.05 ms)
    if _mode in ('running', 'matchup', 'auto_paused', 'paused'):
        # 4.1: look for the LB player icons only while a driver is waiting for them
        _menu.want_icons = False     # 4.5.1: icon search removed (cost ~19 ms per frame)
        _menu.read(frame, now)
    if not _settings['coach_enabled']:
        return
    pending = ((_settings['coach_auto'] and not _coach_done and _mode not in ('running', 'matchup'))
               or _manual_coach_requested)
    if not pending and not (_coach and _coach.busy):
        return
    _ensure_coach()
    _cv.scan(frame, now)
    if _cv.engine is not None and _coach_finalizer is None:
        _coach_finalizer = weakref.finalize(_cv, _cv.engine.destroy)


# ---------------------------------------------------------------- iterate
def _edges():
    modifier = controls.get_actual(L3) > 0
    held = dict(toggle=modifier and controls.get_actual(R3) > 0,
                center=modifier and controls.get_actual(UP) > 0,
                reset=modifier and controls.get_actual(DOWN) > 0,
                left=modifier and controls.get_actual(LEFT) > 0,
                right=modifier and controls.get_actual(RIGHT) > 0)
    edges = {key: value and not _previous[key] for key, value in held.items()}
    _previous.update(held)
    if modifier:   # L3 is reserved as the modifier: never pass the chords on
        for button in (L3, R3, UP, DOWN, LEFT, RIGHT):
            combo.set_val(button, 0)
    return modifier, edges


def _coach_step(now, modifier, edges):
    """Returns True while coaching owns the controller."""
    global _manual_coach_requested, _coach_was_busy, _coach_report_state, _coach_done
    priority = (_settings['coach_enabled'] and
                ((_settings['coach_auto'] and not _coach_done) or _manual_coach_requested
                 or (_coach and _coach.busy)))
    if not priority or _mode in ('running', 'matchup'):
        return False
    _ensure_coach()
    if edges['toggle'] or edges['center']:
        _report('Coaching first; Smother starts by itself on defense afterwards '
                '(or press L3+R3 on defense once coaching is done)', force=True)
    if modifier:
        return True
    if _manual_coach_requested and _cv.ready and _cv.obs.get('video'):
        _coach.coach(now, on_sliders=_cv.obs.get('sliders', False),
                     on_pause=bool(_cv.obs.get('coach_settings') or
                                   (_cv.obs.get('pause') and _cv.obs.get('selected_menu'))))
        _manual_coach_requested = False
    obs = _cv.obs
    if (not obs.get('hud') and _side is not None and _side.view and not obs.get('pause')
            and not obs.get('sliders') and not obs.get('pregame')):
        # 4.5.1: the old "gameplay" cue was the 2K27 logo, which only shows in
        # some scenes, so a retry after an ignored Start could wait for ages.
        obs = dict(obs, hud=True)
    command = _coach.tick(obs, now)
    busy = _coach.busy
    # 3.9.2: only take the controller over once coaching is inside the pause
    # menus. While it is still asking for the pause menu (coach_pause) your
    # buttons pass through - e.g. A on "Your opponent has left the match".
    in_menus = busy and _coach.state != 'coach_pause'
    if in_menus or (_coach_was_busy and not busy):
        for key in set(COACH_KEYS.values()):
            combo.set_val(key, 0)
    if command:
        if command.endswith('_FAST'):
            # 4.6: stick and D-pad held together (kept only if 2K moves faster)
            left = command.startswith('SLIDER_LEFT')
            combo.set_val(controls.STICK_2_X, -100 if left else 100)
            combo.set_val(LEFT if left else RIGHT, 100)
        else:
            combo.set_val(COACH_KEYS[command], -100 if command == 'SLIDER_LEFT' else 100)
    was_busy, _coach_was_busy = _coach_was_busy, busy
    if not busy and was_busy and getattr(_coach, 'rearm', False):
        # Start was ignored during the intro: stay ready and retry when normal
        # gameplay shows, instead of giving up for this game.
        _coach.rearm = False
        _report(_coach.message, force=True)
    elif not busy and was_busy:
        _close_coach()
        _report(_coach.message+' | Smother starts on your first confirmed defense (after the first '
                'basket, or press L3+R3 while defending)', force=True)
    else:
        state = (_coach.state, _coach.row, _cv.error, _cv.ready, _cv.obs.get('pause'),
                 _cv.obs.get('sliders'), _cv.obs.get('submenu_text'))
        if state != _coach_report_state:
            _coach_report_state = state
            _report(_coach.message if busy else ('Coaching OCR unavailable: '+_cv.error if _cv.error
                                                 else 'Waiting for the game to load to apply coaching'),
                    force=True)
    return True


def _game_feedback(now):
    """LB menu opened -> that was defense. LB + player opened nothing (with a
    reader that has already seen this game's panel) -> that was offense."""
    global _mode
    for owner in (_driver, _matchup):
        if owner is None:
            continue
        while owner.events:
            kind, at = owner.events.pop(0)
            if not (_settings['defense_auto'] and _side is not None):
                continue
            if kind == 'opened':
                _no_open[0] = 0
                _learn_side_from_panel(now)
                _side.label(at-.05, 'defense', now, 'LB menu opened')
                continue
            _no_open[0] += 1
            # Before any panel was seen this game, one miss could also be a
            # timing problem; two in a row means offense.
            if _menu.seen or _no_open[0] >= 2:
                result = _side.label(at-.05, 'offense', now, 'LB menu did not open')
                if result == 'kept':
                    # Probably a steal/rebound or a dead ball: wait for the
                    # camera to turn (or 8 s of steady defense), then continue.
                    # A second miss soon after waits for the camera to turn
                    # (next possession) instead of retrying every 8 s.
                    _miss_hold[0] = dict(at=now, turned=False, need_turn=_side.misses >= 2)
                if _mode in ('running', 'matchup'):
                    _resume_to[0] = _mode
                    _mode = 'auto_paused'
                    _release()
                    _report('LB menu did not open: treating this as offense; waits for the next defense',
                            force=True)


_no_open = [0]
_detected_side = [None]     # 'Away'/'Home' seen from the LB panel this game


def _own_side():
    if _detected_side[0]:
        return _detected_side[0]
    return _settings['own_side'] if _settings['own_side'] in ('Away', 'Home') else 'Away'


def _learn_side_from_panel(now):
    """The matchup panel opens top-left for the Away team and top-right for
    the Home team, so the first panel of a game tells us your side for sure."""
    side = {'left': 'Away', 'right': 'Home'}.get(_menu.state.get('side'))
    if side is None or side == _detected_side[0]:
        return
    before = _own_side()
    _detected_side[0] = side
    if _side is not None:
        _side.own_side = side
    if side != before:
        _report('You are %s this game (seen from the LB menu), not %s - using %s'
                % (side, before, side), force=True)
_miss_hold = [None]
# 4.4: without Helios' ball detection (Skele off) a shot cannot be seen, so
# presses only happen in the first SAFE_WINDOW s of each defensive possession
# (the ball is being brought up; shots and rebounds come later). Then Smother
# waits for the camera to turn and your next defense, and carries on.
SAFE_WINDOW = 7.0
_window_start = [None]


def _window_age(now):
    """Seconds into this defensive possession (0 when Helios sees the ball)."""
    if _window_start[0] is None or _ball_detection_working():
        return 0.0
    return now-_window_start[0]


def _shot_risk(now):
    """4.8: the shot clock pauses Smother itself (see _auto), so the
    drivers have nothing extra to wait for."""
    return False


def _ball_detection_working():
    """The shot clock is being read: rim hits are seen, no 7 s window needed."""
    return _clock.on_screen(monotonic())
MISS_RETRY = 8.0     # s of steady defense after a miss before trying again


def _auto(now):
    """Offense/defense: auto start, pause on offense, continue on defense."""
    global _mode
    if not _settings['defense_auto'] or _side is None:
        return
    _side.own_side = _own_side()
    _side.strict = bool(_menu.state.get('panel')) or bool(
        (_mode == 'running' and _driver and _driver.in_menu) or
        (_mode == 'matchup' and _matchup and _matchup.phase != 'ready'))
    clock_events = _clock.take_events()
    if not (_side.calibrated and _side.validated):
        return
    state, turning = _side.state, _side.turning(now)
    # 4.8: shot clock back to 24 while you defend = the ball hit the rim or
    # changed hands. Stop at once and wait for your next defense - unless the
    # clock then shows 14 (their offensive rebound): then carry on.
    shot = False
    for event in clock_events:
        if event == 'reset' and state == 'defense':
            shot = True
            _miss_hold[0] = dict(at=now, turned=False, need_turn=True, clock=True)
        elif (event == 'offensive_rebound' and _miss_hold[0] is not None
              and _miss_hold[0].get('clock') and not _miss_hold[0]['turned']):
            _miss_hold[0] = None
            _report('Shot clock 14: their offensive rebound - still defense', force=True)
    defense_ok = (state == 'defense' and _side.view and not turning and not shot
                  and _side.defense_for(now) >= RESUME_DELAY)
    hold = _miss_hold[0]
    if hold is not None:
        if turning or state == 'offense':
            hold['turned'] = True
        if defense_ok and (hold['turned'] or (not hold.get('need_turn') and now-hold['at'] >= MISS_RETRY
                                             and _side.defense_for(now) >= MISS_RETRY/2)):
            _miss_hold[0] = None
        else:
            defense_ok = False
    if _mode == 'idle' and _driver is None and not _auto_blocked and _settings['smother_enabled']:
        if defense_ok:
            _start_smother(now, why=' automatically on defense (%s)' %
                           ('ends learned from the score' if _side.source == 'score' else 'your L3+R3'))
        return
    if _mode in ('running', 'matchup'):
        if _window_start[0] is None:
            _window_start[0] = now
        between = ((_mode == 'running' and _driver is not None and not _driver.in_menu) or
                   (_mode == 'matchup' and _matchup is not None and _matchup.phase == 'ready'))
        used = now-_window_start[0]
        # never start a new player (about 1.9 s) that would run past the window
        if ((used > SAFE_WINDOW or (between and used > SAFE_WINDOW-1.6))
                and not _ball_detection_working() and not (state == 'offense' or turning or shot)):
            _resume_to[0] = _mode
            _mode = 'auto_paused'
            _release()
            if _driver:
                _driver.restart_player()
            if _matchup:
                _matchup.restart()
            _miss_hold[0] = dict(at=now, turned=False, need_turn=True)
            _window_start[0] = None
            _report('Shot/rebound time coming: paused after %d s of this defense; continues next defense'
                    % SAFE_WINDOW, force=True)
            return
    else:
        _window_start[0] = None
    if _mode in ('running', 'matchup') and (state == 'offense' or turning or shot):
        _resume_to[0] = _mode
        _mode = 'auto_paused'
        _release()
        if _driver:
            _driver.restart_player()
        if _matchup:
            _matchup.restart()
        _report(('Offense detected' if state == 'offense' else 'Camera turning' if turning
                 else 'Shot clock reset to 24 (rim hit or ball changed hands)')
                + ': paused; continues on defense', force=True)
    elif _mode == 'auto_paused' and defense_ok:
        _mode = _resume_to[0]
        _report('Defense: continuing', force=True)


_resume_to = ['running']


def iterate(button_bytes, stick_bytes, **kwargs):
    global _mode, _driver, _matchup, _manual_coach_requested, _coach_done, _auto_blocked
    combo.buttons, combo.sticks = button_bytes, stick_bytes
    if not _access_gate():
        return                      # your controller passes straight through
    now = monotonic()
    _refresh_settings(now)
    modifier, edges = _edges()

    if _mode == 'done':
        # Finished for this game. L3+R3 / L3+Up / L3+Left still work manually.
        if edges['toggle'] or edges['center']:
            _calibrate(now)
            _start_smother(now, ('LT',) if edges['center'] else PLAYERS, ' again (manual)')
        elif edges['left']:
            _start_matchup(now)
        return

    if edges['reset']:
        _release()
        if _coach and _coach.busy:
            _coach.emergency()
            _close_coach()
        _driver = _matchup = None
        _mode = 'idle'
        _auto_blocked = True
        _report('Cancelled. Auto-start is off until your next L3+R3 (or the next game)', force=True)
        return
    if edges['right']:
        if _settings['coach_enabled']:
            _ensure_coach()
            _coach.refresh(now)
            _manual_coach_requested = True
            _coach_done = False
            if _mode in ('running', 'matchup'):
                _mode = 'paused'
                _release()
        else:
            _report('Coach sliders are disabled in the panel', force=True)

    if _coach_step(now, modifier, edges):
        return

    if edges['toggle']:
        _auto_blocked = False
        if _mode in ('running', 'matchup'):
            _resume_to[0] = _mode
            _mode = 'paused'
            _release()
            if _driver:
                _driver.restart_player()
            if _matchup:
                _matchup.restart()
            _report('Paused by you; L3+R3 on defense resumes', force=True)
            return
        _calibrate(now)
        if _mode in ('paused', 'auto_paused'):
            _mode = _resume_to[0]
            _report('Resumed by you', force=True)
        elif _settings['smother_enabled']:
            _start_smother(now, why=' by L3+R3')
    elif edges['center']:
        _auto_blocked = False
        _calibrate(now)
        _start_smother(now, ('LT',), ' (centre only)')
    elif edges['left'] and _mode in ('idle', 'paused'):
        _start_matchup(now)

    _game_feedback(now)
    _auto(now)

    if _mode == 'running' and _driver:
        button = _driver.tick(dict(_menu.state, shot_risk=_shot_risk(now), window_age=_window_age(now)), now)
        # Your own buttons pass through while it is only waiting between
        # players; they are held at 0 only while it works inside the LB menu.
        if button is not None or _driver.in_menu:
            _press(button)
        if _driver.complete:
            _release()
            done = len(_driver.players)-len(_driver.failed)
            _report('Smother/Deny set: %d/%d%s' % (
                done, len(_driver.players),
                (' (not confirmed: %s)' % ', '.join(_driver.failed)) if _driver.failed else ''), force=True)
            if all(kind == 'deny' for _, kind in _driver.jobs):
                _finish('Smother, matchup and Deny done')
            elif _settings['matchup_enabled'] and sum(kind == 'smother' for _, kind in _driver.jobs) > 1:
                _start_matchup(now)
            else:
                _deny_or_finish('Smother finished')
        else:
            state = (_mode, _driver.index, _driver.phase, _driver.tries)
            if state != _last_state[0]:
                _last_state[0] = state
                _report('Smother player %d/%d: %s' % (_driver.index+1, len(_driver.players),
                                                      _driver.message), force=True)
    elif _mode == 'matchup' and _matchup:
        button = _matchup.tick(dict(_menu.state, shot_risk=_shot_risk(now), window_age=_window_age(now)), now)
        if button is not None or _matchup.phase != 'ready':
            _press(button)
        if _matchup.complete:
            _release()
            _deny_or_finish('Smother done; matchup %s' % ('confirmed' if _matchup.result == 'ok'
                                                  else 'NOT confirmed (menu did not open/close)'))
        elif _matchup.message and _matchup.message != _last_state[1]:
            _last_state[1] = _matchup.message
            _report(_matchup.message, force=True)


_last_state = [None, None]
_report('Ready (%s): coaching at game load, Smother on your first confirmed defense, '
        'then the matchup; repeats every game by itself.' % VERSION)
