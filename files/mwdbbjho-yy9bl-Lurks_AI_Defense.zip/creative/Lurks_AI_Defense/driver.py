"""Closed-loop Smother and matchup driver (3.9).

From the Nov 4 21:13 recording (2K27, LB defensive menu, top-left panel):
  LB -> player button -> "<Name> Matchup" panel -> RT -> "Off-Ball Pressure"
  -> RT -> "On-Ball Pressure" -> X = SMOTHER (row 2 turns yellow with a tick)
  -> the panel closes about 0.45 s later.
With 150 ms after X ("Fast Smother" in 3.7/3.8) the next LB arrived while the
panel was still closing and was ignored: only every other player was set and
the matchup step was lost.

Now every player is driven by what is on screen:
  wait until no panel is showing (and 0.5 s after the last X)
  LB, player button, then WAIT until the panel is seen open
  RT, RT, X, then WAIT until row 2 shows SMOTHER selected (yellow)
  no panel within 1.3 s, or no SMOTHER confirmation -> that player is retried
  (up to 3 tries). X is never sent unless the panel was seen open, so a
  stray X (steal attempt) cannot go out on the court.
"""
from pathlib import Path

PANEL_TITLE_BOX = (110, 236, 350, 310)   # full-resolution (1920x1080) pixels
ROW2_BOX = (125, 342, 335, 380)          # second row: SMOTHER / DENY / 2nd name
# 3.9.1: the panel opens on YOUR team's side of the screen. Away (Oct 31 / Nov 4
# Thunder game): top-left. Home (Nov 4 Heat game): top-right, mirrored.
SIDES = {'left': (PANEL_TITLE_BOX, ROW2_BOX),
         'right': ((1920-350, 236, 1920-110, 310), (1920-335, 342, 1920-125, 380))}
PANEL_MIN = 0.62
AFTER_X = 0.50          # the panel needs ~0.45 s to close after a selection
OPEN_TIMEOUT = 1.30
SELECT_TIMEOUT = 1.20
CLOSE_TIMEOUT = 2.00
MAX_TRIES = 4


class MenuReader:
    """Reads the LB defensive panel. About 0.3 ms per frame (two small crops)."""

    def __init__(self, root):
        self.root = Path(root)
        self.templates = None
        self.state = dict(panel=None, selected=None, at=-10.0, seq=0, side=None)
        self.error = ''
        self.side = None      # 'left' | 'right' once a panel has been seen
        self.seen = False

    def _load(self):
        import cv2
        self.templates = {}
        for key, name in (('matchup', 'lb_matchup'), ('pressure', 'lb_onball'),
                          ('pressure_off', 'lb_offball')):
            image = cv2.imread(str(self.root/(name+'.png')), cv2.IMREAD_GRAYSCALE)
            if image is None:
                raise RuntimeError('missing '+name+'.png')
            self.templates[key] = image

    def _panel(self, frame, side):
        import cv2
        h, w = frame.shape[:2]
        sx, sy = w/1920.0, h/1080.0
        (x1, y1, x2, y2), _ = SIDES[side]
        crop = frame[round(y1*sy):round(y2*sy), round(x1*sx):round(x2*sx), :3]
        gray = cv2.cvtColor(cv2.resize(crop, ((x2-x1)//2, (y2-y1)//2), interpolation=cv2.INTER_AREA),
                            cv2.COLOR_BGR2GRAY)
        scores = {}
        for key, template in self.templates.items():
            if gray.shape[0] >= template.shape[0] and gray.shape[1] >= template.shape[1]:
                scores[key] = float(cv2.minMaxLoc(cv2.matchTemplate(gray, template, cv2.TM_CCOEFF_NORMED))[1])
        best = max(scores, key=scores.get) if scores else None
        if not best or scores[best] < PANEL_MIN:
            return None
        # "Matchup" scores 0.86-1.00 against 0.73-0.77 for the pressure titles;
        # the two pressure titles look alike (0.95).
        if best == 'matchup' and scores['matchup']-max(scores['pressure'], scores['pressure_off']) >= .05:
            return 'matchup'
        return 'pressure'

    def _selected(self, frame, side):
        import numpy as np
        h, w = frame.shape[:2]
        sx, sy = w/1920.0, h/1080.0
        _, (x1, y1, x2, y2) = SIDES[side]
        row = frame[round(y1*sy):round(y2*sy), round(x1*sx):round(x2*sx), :3].astype(np.int16)
        yellow = ((row[:, :, 0] < 110) & (row[:, :, 1] > 180) & (row[:, :, 2] > 180)).mean()
        if yellow <= .5:
            return None
        # Selected text is dark on yellow: tick + glyph + SMOTHER spans ~90 px
        # at 1080p; DENY is far shorter.
        dark = (row.mean(axis=2) < 70).mean(axis=0) > .12
        columns = np.flatnonzero(dark)
        span = (columns[-1]-columns[0])/sx if len(columns) else 0
        return 'smother' if span >= 70 else 'other'

    def read(self, frame, now):
        if frame is None or not hasattr(frame, 'shape'):
            return self.state
        try:
            if self.templates is None:
                self._load()
            panel = side = None
            # Check the side it was last seen on first, then the other one.
            order = [self.side] if self.side else []
            order += [name for name in ('left', 'right') if name not in order]
            for name in order:
                panel = self._panel(frame, name)
                if panel:
                    side = name
                    break
            selected = self._selected(frame, side) if panel else None
            if side:
                self.side = side
                self.seen = True
            self.state = dict(panel=panel, selected=selected, at=now, seq=self.state['seq']+1,
                              side=side, seen=self.seen)
        except Exception as exc:     # never break controller output
            self.error = str(exc)[:120]
        return self.state


class Taps:
    def __init__(self):
        self.queue = []
        self.until = None

    def add(self, button, seconds):
        self.queue.append((button, seconds))

    @property
    def busy(self):
        return bool(self.queue)

    def tick(self, now):
        while self.queue:
            if self.until is None:
                self.until = now+self.queue[0][1]
            if now < self.until:
                return self.queue[0][0]
            self.queue.pop(0)
            self.until = None
        return None

    def clear(self):
        self.queue = []
        self.until = None


class SmotherDriver:
    def __init__(self, players, defender_trigger='LT'):
        self.players = list(players)
        self.index = 0
        self.tries = 0
        self.phase = 'ready'
        self.taps = Taps()
        self.last_x = -10.0
        self.phase_at = None
        self.deadline = 0.0
        self.sent_at = 0.0
        self.message = ''
        self.failed = []
        self.trigger = defender_trigger
        self._now = 0.0
        self.lb_at = 0.0
        self.events = []

    @property
    def complete(self):
        return self.index >= len(self.players)

    @property
    def in_menu(self):
        return self.phase not in ('ready',)

    def _reset_phase(self):
        self.taps.clear()
        self.phase = 'ready'
        self.phase_at = None

    def restart_player(self):
        # Interrupted mid-player: the LB player icons may still be up, and a
        # second LB would close them so the player button lands on the court.
        # Give them time to clear first.
        if self.phase != 'ready' or self.taps.busy:
            self.last_x = max(self.last_x, self._now+1.0)
        self.taps.clear()
        self.phase = 'ready'
        self.phase_at = None

    def _next(self, ok):
        name = self.players[self.index]
        if not ok:
            self.failed.append(name)
        self.index += 1
        self.tries = 0
        self._reset_phase()

    def _retry(self, reason):
        self.tries += 1
        self.message = '%s (try %d/%d)' % (reason, self.tries, MAX_TRIES)
        if self.tries >= MAX_TRIES:
            self._next(False)
        else:
            self._reset_phase()

    def tick(self, menu, now):
        self._now = now
        button = self.taps.tick(now)
        if button is not None or self.taps.busy or self.complete:
            return button
        player = self.players[self.index]
        fresh = menu['at'] > self.sent_at+0.02
        if self.phase == 'ready':
            if self.phase_at is None:
                self.phase_at = now
            if now-self.last_x < AFTER_X:
                return None
            if menu['panel'] and menu['at'] > now-.3:
                if now-self.phase_at > CLOSE_TIMEOUT:
                    # A panel has been open for 2 s: close it with B (menus
                    # consume B, so this is not a court action).
                    self.taps.add('B', .08)
                    self.taps.add(None, .30)
                    self.phase_at = now
                return None
            trigger = player == self.trigger
            self.lb_at = now
            self.taps.add('LB', .08)
            self.taps.add(None, .35 if trigger else .20)
            self.taps.add(player, .20 if trigger else .08)
            self.phase = 'open'
            self.sent_at = now+(.63 if trigger else .36)
            self.deadline = self.sent_at+OPEN_TIMEOUT
            self.message = 'Player %d/%d: opening menu' % (self.index+1, len(self.players))
            return self.taps.tick(now)
        if self.phase == 'open':
            if fresh and menu['panel'] in ('matchup', 'pressure'):
                self.events.append(('opened', self.lb_at))
                self.taps.add('RT', .06)
                self.taps.add(None, .11)
                self.taps.add('RT', .06)
                self.taps.add(None, .11)
                self.taps.add('X', .06)
                self.phase = 'select'
                self.last_x = now+.40
                self.sent_at = now+.40
                self.deadline = self.sent_at+SELECT_TIMEOUT
                self.message = 'Player %d/%d: selecting Smother' % (self.index+1, len(self.players))
                return self.taps.tick(now)
            if now > self.deadline:
                # On offense LB shows play-call icons and no matchup panel
                # opens (Nov 4 Heat game, 6.3 s). The caller treats this as
                # "probably offense" and waits for the next defense.
                self.events.append(('no_open', self.lb_at))
                if menu.get('seen'):
                    # The reader works in this game, so this was offense, not
                    # a failed try: do not use up this player's tries.
                    self.message = 'Player %d: menu did not open (offense?)' % (self.index+1)
                    self._reset_phase()
                else:
                    self._retry('Player %d menu did not open' % (self.index+1))
            return None
        if self.phase == 'select':
            if fresh and menu['selected'] == 'smother':
                self.message = 'Player %d/%d: Smother confirmed' % (self.index+1, len(self.players))
                self._next(True)
                return None
            if fresh and menu['selected'] == 'other':
                self._retry('Player %d: a different option was selected' % (self.index+1))
                return None
            if now > self.deadline:
                self._retry('Player %d: Smother not confirmed' % (self.index+1))
            return None
        return None


class MatchupDriver:
    """LB -> your defender -> (panel seen) -> opponent row button -> closed."""

    def __init__(self, defender, target, trigger='LT'):
        self.defender, self.target, self.trigger = defender, target, trigger
        self.phase = 'ready'
        self.taps = Taps()
        self.tries = 0
        self.phase_at = None
        self.sent_at = 0.0
        self.deadline = 0.0
        self.result = None       # 'ok' | 'failed'
        self.message = ''
        self.hold_until = 0.0
        self._now = 0.0
        self.lb_at = 0.0
        self.events = []

    @property
    def complete(self):
        return self.result is not None

    def restart(self):
        if self.phase != 'ready' or self.taps.busy:
            self.hold_until = self._now+1.6
        self.taps.clear()
        self.phase = 'ready'
        self.phase_at = None

    def _retry(self, reason):
        self.tries += 1
        self.message = '%s (try %d/%d)' % (reason, self.tries, MAX_TRIES)
        if self.tries >= MAX_TRIES:
            self.result = 'failed'
        else:
            self.taps.clear()
            self.phase = 'ready'
            self.phase_at = None

    def tick(self, menu, now):
        self._now = now
        button = self.taps.tick(now)
        if button is not None or self.taps.busy or self.complete:
            return button
        fresh = menu['at'] > self.sent_at+0.02
        if self.phase == 'ready':
            if self.phase_at is None:
                self.phase_at = now
            if now < self.hold_until:
                return None
            if menu['panel'] and menu['at'] > now-.3:
                if now-self.phase_at > CLOSE_TIMEOUT:
                    self.taps.add('B', .08)
                    self.taps.add(None, .30)
                    self.phase_at = now
                return None
            trigger = self.defender == self.trigger
            self.lb_at = now
            self.taps.add('LB', .08)
            self.taps.add(None, .35 if trigger else .20)
            self.taps.add(self.defender, .20 if trigger else .08)
            self.phase = 'open'
            self.sent_at = now+(.63 if trigger else .36)
            self.deadline = self.sent_at+OPEN_TIMEOUT
            self.message = 'Matchup: opening your defender'
            return self.taps.tick(now)
        if self.phase == 'open':
            if fresh and menu['panel'] == 'matchup':
                self.events.append(('opened', self.lb_at))
                self.taps.add(self.target, .06)
                self.phase = 'close'
                self.sent_at = now+.06
                self.deadline = self.sent_at+CLOSE_TIMEOUT
                self.message = 'Matchup: picking the opponent'
                return self.taps.tick(now)
            if now > self.deadline:
                self.events.append(('no_open', self.lb_at))
                if menu.get('seen'):
                    self.message = 'Matchup menu did not open (offense?)'
                    self.taps.clear()
                    self.phase = 'ready'
                    self.phase_at = None
                else:
                    self._retry('Matchup menu did not open')
            return None
        if self.phase == 'close':
            if fresh and menu['panel'] is None:
                self.result = 'ok'
                self.message = 'Matchup set (menu closed after the pick)'
            elif now > self.deadline:
                self._retry('Matchup menu did not close after the pick')
            return None
        return None
